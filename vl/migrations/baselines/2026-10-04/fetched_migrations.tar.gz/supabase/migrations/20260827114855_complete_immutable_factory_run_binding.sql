create or replace function private.ensure_release_candidate(p_factory_run_id uuid, p_actor uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_run public.factory_runs%rowtype;
  v_env public.environments%rowtype;
  v_sha text; v_dep_id uuid; v_approval_id uuid; v_version text; v_required jsonb; g jsonb;
begin
  if p_actor is null then raise exception 'release candidate actor required'; end if;
  select * into v_run from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'factory run not found'; end if;
  if not exists(select 1 from public.project_members pm where pm.project_id=v_run.project_id and pm.user_id=p_actor and pm.role in ('owner','admin','builder')) then raise exception 'actor is not authorized project member'; end if;
  if v_run.state<>'validating' or v_run.target_environment<>'staging' or v_run.production_locked is not true then raise exception 'release candidate requires locked staging run in validating state'; end if;
  if coalesce(v_run.result->>'runner_status','')<>'PASS' then raise exception 'runner QA PASS required'; end if;
  v_sha:=coalesce(v_run.result#>>'{runner,artifact_sha256}',v_run.result->>'artifact_sha256');
  if v_sha is null or v_sha !~ '^[0-9a-fA-F]{64}$' then raise exception 'valid runner artifact SHA-256 required'; end if;
  if v_run.workflow_id is null then raise exception 'workflow_id required'; end if;

  select * into v_env from public.environments where project_id=v_run.project_id and kind='production' and status='ready' order by created_at desc limit 1;
  if not found then return jsonb_build_object('decision','blocked','reason','ready_production_environment_required','factory_run_id',v_run.id); end if;

  v_required:=private.get_required_release_gates(v_run.id);
  for g in select value from jsonb_array_elements(v_required) loop
    insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence,score,checked_at)
    values(v_run.project_id,v_run.id,g->>'key',g->>'type',case when g->>'key'='qa_regression' then 'pass' else 'pending' end,
      case when g->>'key'='qa_regression' then jsonb_build_object('runner','github-actions-oidc','runner_status','PASS','artifact_sha256',v_sha,'github_run_id',v_run.result#>>'{runner,github_run_id}') else '{}'::jsonb end,
      case when g->>'key'='qa_regression' then 1 else null end,case when g->>'key'='qa_regression' then now() else null end)
    on conflict(factory_run_id,gate_key) do update set
      status=case when excluded.gate_key='qa_regression' then 'pass' else public.release_gates.status end,
      evidence=case when excluded.gate_key='qa_regression' then excluded.evidence else public.release_gates.evidence end,
      score=case when excluded.gate_key='qa_regression' then 1 else public.release_gates.score end,
      checked_at=case when excluded.gate_key='qa_regression' then now() else public.release_gates.checked_at end;
  end loop;
  insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence)
  values(v_run.project_id,v_run.id,'human_production_approval','human_approval','pending','{}'::jsonb),(v_run.project_id,v_run.id,'production_lock','production_lock','pending','{}'::jsonb)
  on conflict(factory_run_id,gate_key) do nothing;

  select id into v_dep_id from public.deployments
   where factory_run_id=v_run.id and project_id=v_run.project_id and artifact_sha256=v_sha
     and status in ('planned','certified','approved','deploying','deployed')
   limit 1;
  if v_dep_id is null then
    v_version:='vl-'||to_char(clock_timestamp(),'YYYYMMDDHH24MISS')||'-'||left(v_sha,8);
    insert into public.deployments(project_id,environment_id,workflow_id,factory_run_id,release_version,status,artifact_sha256,certificate,created_by)
    values(v_run.project_id,v_env.id,v_run.workflow_id,v_run.id,v_version,'planned',v_sha,jsonb_build_object('schema','vrs.release-certificate/2','factory_run_id',v_run.id,'artifact_sha256',v_sha,'builder_key',coalesce(v_run.result#>>'{runner,builder_key}',private.resolve_factory_builder(v_run.id)),'runner_qa','PASS','production_locked',true,'required_gates',v_required),p_actor)
    returning id into v_dep_id;
  end if;

  select id into v_approval_id from public.approvals
   where factory_run_id=v_run.id and project_id=v_run.project_id and workflow_id=v_run.workflow_id
     and approval_type='production_release' and status='pending'
   limit 1 for update;
  if v_approval_id is null then
    insert into public.approvals(project_id,workflow_id,factory_run_id,approval_type,status,requested_by,rationale)
    values(v_run.project_id,v_run.workflow_id,v_run.id,'production_release','pending',p_actor,'Autonomous staging build passed runner QA. Technical release gates must pass before explicit production approval.') returning id into v_approval_id;
  end if;
  return jsonb_build_object('decision','release_candidate_prepared','factory_run_id',v_run.id,'deployment_id',v_dep_id,'approval_id',v_approval_id,'artifact_sha256',v_sha,'required_gates',v_required,'deployment_status','planned','human_approval','pending','production_locked',true);
end $function$;

create or replace function public.evaluate_vrs_release_server_gates(p_factory_run_id uuid)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_required jsonb;
  v_run public.factory_runs%rowtype;
  v_dep public.deployments%rowtype;
  v_rls_off int;
  v_bad_definer int;
  v_artifact_match boolean;
  v_results jsonb:='[]'::jsonb;
  v_sw text;
  v_manifest text;
  v_pwa_offline_ok boolean;
begin
  select * into v_run from public.factory_runs where id=p_factory_run_id;
  if not found then raise exception 'factory run not found'; end if;
  select * into v_dep from public.deployments
   where factory_run_id=v_run.id and project_id=v_run.project_id
     and artifact_sha256=coalesce(v_run.result#>>'{runner,artifact_sha256}',v_run.result->>'artifact_sha256')
   limit 1;
  if not found then raise exception 'release deployment not found for factory run'; end if;
  if v_dep.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow mismatch'; end if;
  v_required:=private.get_required_release_gates(v_run.id);

  if exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'='database_security') then
    select count(*) into v_rls_off from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and c.relrowsecurity=false;
    select count(*) into v_bad_definer from pg_proc p join pg_namespace n on n.oid=p.pronamespace
     where n.nspname='public' and p.prokind='f' and p.prosecdef
       and (has_function_privilege('public',p.oid,'EXECUTE') or has_function_privilege('anon',p.oid,'EXECUTE') or has_function_privilege('authenticated',p.oid,'EXECUTE'));
    update public.release_gates set status=case when v_rls_off=0 and v_bad_definer=0 then 'pass' else 'fail' end,
      score=case when v_rls_off=0 and v_bad_definer=0 then 1 else 0 end,
      evidence=jsonb_build_object('scope','vrs_control_plane_database','public_tables_without_rls',v_rls_off,'public_security_definer_exposed_to_client_roles',v_bad_definer,'checked_by','server_gate_evaluator'),checked_at=now(),checked_by=null
      where factory_run_id=v_run.id and gate_key='database_security';
    v_results:=v_results||jsonb_build_array(jsonb_build_object('key','database_security','status',case when v_rls_off=0 and v_bad_definer=0 then 'pass' else 'fail' end));
  end if;

  if exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'='rollback_contract') then
    select exists(select 1 from public.factory_artifacts fa where fa.factory_run_id=v_run.id and lower(fa.sha256)=lower(v_dep.artifact_sha256)) into v_artifact_match;
    update public.release_gates set status=case when v_run.production_locked=true and v_dep.status in ('planned','certified') and v_artifact_match then 'pass' else 'fail' end,
      score=case when v_run.production_locked=true and v_dep.status in ('planned','certified') and v_artifact_match then 1 else 0 end,
      evidence=jsonb_build_object('scope','control_plane_rollback_contract','immutable_artifact_hash_match',v_artifact_match,'production_lock_preserved',v_run.production_locked,'deployment_status',v_dep.status,'rollback_status_supported',true,'note','External target rollback remains adapter-specific and is required before deployed state.'),checked_at=now(),checked_by=null
      where factory_run_id=v_run.id and gate_key='rollback_contract';
    v_results:=v_results||jsonb_build_array(jsonb_build_object('key','rollback_contract','status',case when v_run.production_locked=true and v_dep.status in ('planned','certified') and v_artifact_match then 'pass' else 'fail' end));
  end if;

  if exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'='offline_pwa_contract') then
    select content into v_sw from public.generated_artifacts where factory_run_id=v_run.id and path='web/public/sw.js' order by created_at desc limit 1;
    select content into v_manifest from public.generated_artifacts where factory_run_id=v_run.id and path='web/public/manifest.webmanifest' order by created_at desc limit 1;
    v_pwa_offline_ok := coalesce(v_sw,'') like '%caches.open%' and coalesce(v_sw,'') like '%cache.put%' and coalesce(v_sw,'') like '%caches.match%' and coalesce(v_manifest,'') <> '';
    update public.release_gates set status=case when v_pwa_offline_ok then 'pass' else 'fail' end,
      score=case when v_pwa_offline_ok then 1 else 0 end,
      evidence=jsonb_build_object('scope','generated_pwa_offline_contract','manifest_present',coalesce(v_manifest,'')<>'','cache_open',coalesce(v_sw,'') like '%caches.open%','cache_put',coalesce(v_sw,'') like '%cache.put%','cache_match',coalesce(v_sw,'') like '%caches.match%','checked_by','server_gate_evaluator'),checked_at=now(),checked_by=null
      where factory_run_id=v_run.id and gate_key='offline_pwa_contract';
    v_results:=v_results||jsonb_build_array(jsonb_build_object('key','offline_pwa_contract','status',case when v_pwa_offline_ok then 'pass' else 'fail' end));
  end if;

  return jsonb_build_object('factory_run_id',v_run.id,'deployment_id',v_dep.id,'server_gate_results',v_results);
end $function$;

create or replace function public.claim_vrs_production_promotion_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
 j private.production_promotion_jobs%rowtype;
 v_dep public.deployments%rowtype;
 v_art public.factory_artifacts%rowtype;
 v_lease uuid:=gen_random_uuid();
 v_adapter_status text;
 v_adapter_configuration jsonb;
 v_required_credentials jsonb;
begin
 select pj.* into j
 from private.production_promotion_jobs pj
 join private.production_adapter_registry ar on ar.adapter_key=pj.target_adapter and ar.status='active' and ar.configured=true
 where (pj.state='queued' or (pj.state='leased' and pj.lease_expires_at<now())) and pj.attempts<pj.max_attempts
 order by pj.created_at for update of pj skip locked limit 1;
 if not found then return jsonb_build_object('status','idle'); end if;

 select * into v_dep from public.deployments where id=j.deployment_id and factory_run_id=j.factory_run_id and project_id=j.project_id;
 if not found then return jsonb_build_object('status','rejected','reason','deployment_factory_run_binding_mismatch'); end if;
 if v_dep.status<>'approved' or v_dep.approved_by is null then return jsonb_build_object('status','rejected','reason','deployment_not_approved'); end if;

 select * into v_art from public.factory_artifacts
 where factory_run_id=j.factory_run_id and artifact_type='bundle' and lower(sha256)=lower(j.artifact_sha256)
 order by created_at desc limit 1;
 if not found then return jsonb_build_object('status','rejected','reason','immutable_source_artifact_not_found'); end if;

 select status,configuration,required_credentials into v_adapter_status,v_adapter_configuration,v_required_credentials
 from private.production_adapter_registry where adapter_key=j.target_adapter;
 if v_adapter_status<>'active' then return jsonb_build_object('status','rejected','reason','adapter_not_active'); end if;

 update private.production_promotion_jobs
 set state='leased',attempts=attempts+1,lease_token=v_lease,leased_at=now(),lease_expires_at=now()+interval '20 minutes',updated_at=now()
 where id=j.id returning * into j;
 update public.deployments set status='deploying',certificate=certificate||jsonb_build_object('promotion_started_at',now(),'promotion_adapter',j.target_adapter)
 where id=j.deployment_id and factory_run_id=j.factory_run_id;

 return jsonb_build_object('status','leased','job_id',j.id,'lease_token',v_lease,'deployment_id',j.deployment_id,'factory_run_id',j.factory_run_id,'builder_key',j.builder_key,'target_adapter',j.target_adapter,'expected_sha256',j.artifact_sha256,'source_artifact_name',v_art.name,'source_storage_path',v_art.storage_path,'source_github_run_id',v_art.metadata->>'github_run_id','attempt',j.attempts,'max_attempts',j.max_attempts,'adapter_configuration',coalesce(v_adapter_configuration,'{}'::jsonb),'required_credentials',coalesce(v_required_credentials,'[]'::jsonb));
end $function$;;
