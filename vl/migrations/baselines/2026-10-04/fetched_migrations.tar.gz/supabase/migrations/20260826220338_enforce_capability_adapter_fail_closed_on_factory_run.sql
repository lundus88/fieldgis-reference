create or replace function private.enrich_factory_run_capability_plan()
returns trigger
language plpgsql
security definer
set search_path = private, public, pg_temp
as $$
declare
  v_compilation_id uuid;
  v_adapters jsonb;
  v_blockers jsonb;
begin
  begin
    v_compilation_id := nullif(new.input->>'compilation_id','')::uuid;
  exception when others then
    v_compilation_id := null;
  end;

  if v_compilation_id is not null then
    select capability_adapter_plan
      into v_adapters
      from public.spec_compilations
     where id = v_compilation_id;

    if v_adapters is not null then
      select coalesce(jsonb_agg(x), '[]'::jsonb)
        into v_blockers
        from jsonb_array_elements(v_adapters) x
       where coalesce((x->>'blocking')::boolean, false) = true;

      if jsonb_array_length(v_blockers) > 0 then
        raise exception using
          errcode = 'P0001',
          message = 'CAPABILITY_ADAPTER_BLOCKED: one or more required capability adapters are unavailable',
          detail = v_blockers::text,
          hint = 'Configure and certify the missing capability adapter before planning a factory run.';
      end if;

      new.plan := coalesce(new.plan,'{}'::jsonb)
        || jsonb_build_object('capability_adapters', v_adapters);
    end if;
  end if;

  return new;
end;
$$;

revoke all on function private.enrich_factory_run_capability_plan() from public, anon, authenticated;
grant execute on function private.enrich_factory_run_capability_plan() to service_role, postgres;;
