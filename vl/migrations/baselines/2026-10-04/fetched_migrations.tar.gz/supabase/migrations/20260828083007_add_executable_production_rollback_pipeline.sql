alter table private.production_rollback_audits
  add column if not exists attempts integer not null default 0,
  add column if not exists max_attempts integer not null default 3,
  add column if not exists lease_token uuid,
  add column if not exists leased_at timestamptz,
  add column if not exists lease_expires_at timestamptz,
  add column if not exists result jsonb not null default '{}'::jsonb,
  add column if not exists error_text text,
  add column if not exists updated_at timestamptz not null default now();

create or replace function public.claim_vrs_production_rollback_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  r private.production_rollback_audits%rowtype;
  cur public.deployments%rowtype;
  prev public.deployments%rowtype;
  art public.factory_artifacts%rowtype;
  v_lease uuid:=gen_random_uuid();
  v_adapter private.production_adapter_registry%rowtype;
begin
  select * into r
  from private.production_rollback_audits
  where (state='pending' or (state='leased' and lease_expires_at<now()))
    and attempts<max_attempts
  order by requested_at
  for update skip locked
  limit 1;
  if not found then return jsonb_build_object('status','idle'); end if;

  select * into cur from public.deployments where id=r.deployment_id for update;
  if not found then
    update private.production_rollback_audits set state='failed',error_text='current deployment not found',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','current_deployment_not_found');
  end if;
  if cur.status not in ('deployed','failed') then
    update private.production_rollback_audits set state='failed',error_text='current deployment not rollback-eligible',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','current_deployment_not_rollback_eligible');
  end if;

  select * into prev from public.deployments where id=r.previous_deployment_id and project_id=cur.project_id;
  if not found or prev.status not in ('deployed','rolled_back') then
    update private.production_rollback_audits set state='failed',error_text='previous deployment invalid',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','previous_deployment_invalid');
  end if;
  if prev.artifact_sha256 is null or lower(prev.artifact_sha256)<>lower(coalesce(r.artifact_sha256,'')) then
    update private.production_rollback_audits set state='failed',error_text='rollback artifact hash binding mismatch',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','rollback_artifact_hash_binding_mismatch');
  end if;

  select * into art from public.factory_artifacts
  where factory_run_id=prev.factory_run_id and artifact_type='bundle' and lower(sha256)=lower(prev.artifact_sha256)
  order by created_at desc limit 1;
  if not found then
    update private.production_rollback_audits set state='failed',error_text='immutable rollback artifact not found',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','immutable_rollback_artifact_not_found');
  end if;
  if art.storage_path not like 'github-actions://lundus88/fieldgis-reference/runs/%/artifacts/%' then
    update private.production_rollback_audits set state='failed',error_text='trusted GitHub rollback artifact path required',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','trusted_github_artifact_required');
  end if;
  if nullif(art.metadata->>'github_artifact_expires_at','') is null or (art.metadata->>'github_artifact_expires_at')::timestamptz<=now() then
    update private.production_rollback_audits set state='failed',error_text='rollback artifact expired or missing expiry provenance',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','rollback_artifact_expired');
  end if;

  select * into v_adapter from private.production_adapter_registry where adapter_key=r.target_adapter;
  if not found or v_adapter.status<>'active' or v_adapter.configured is distinct from true or v_adapter.can_rollback is distinct from true then
    update private.production_rollback_audits set state='failed',error_text='rollback adapter unavailable',finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','rejected','reason','rollback_adapter_unavailable');
  end if;

  update private.production_rollback_audits
  set state='leased',attempts=attempts+1,lease_token=v_lease,leased_at=now(),lease_expires_at=now()+interval '20 minutes',updated_at=now(),
      evidence=coalesce(evidence,'{}'::jsonb)||jsonb_build_object('runner_identity',coalesce(p_runner_identity,'{}'::jsonb),'leased_at',now())
  where id=r.id returning * into r;

  return jsonb_build_object(
    'status','leased','rollback_audit_id',r.id,'lease_token',v_lease,'deployment_id',cur.id,'previous_deployment_id',prev.id,
    'target_adapter',r.target_adapter,'expected_sha256',prev.artifact_sha256,'source_artifact_name',art.name,
    'source_storage_path',art.storage_path,'source_github_run_id',art.metadata->>'github_run_id','source_github_artifact_id',art.metadata->>'github_artifact_id',
    'source_commit_sha',prev.source_commit_sha,'attempt',r.attempts,'max_attempts',r.max_attempts,
    'adapter_configuration',coalesce(v_adapter.configuration,'{}'::jsonb),'required_credentials',coalesce(v_adapter.required_credentials,'[]'::jsonb));
end
$function$;

create or replace function public.complete_vrs_production_rollback_job(
  p_rollback_audit_id uuid,
  p_lease_token uuid,
  p_success boolean,
  p_result jsonb default '{}'::jsonb,
  p_error_text text default null
)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  r private.production_rollback_audits%rowtype;
  cur public.deployments%rowtype;
  prev public.deployments%rowtype;
  v_sha text;
  v_checks jsonb;
  v_bad int;
begin
  select * into r from private.production_rollback_audits where id=p_rollback_audit_id for update;
  if not found then raise exception 'rollback audit not found'; end if;
  if r.state<>'leased' or r.lease_token is distinct from p_lease_token then raise exception 'invalid rollback lease'; end if;
  if r.lease_expires_at<now() then raise exception 'rollback lease expired'; end if;
  select * into cur from public.deployments where id=r.deployment_id for update;
  select * into prev from public.deployments where id=r.previous_deployment_id;
  if not found then raise exception 'rollback target deployment missing'; end if;

  if p_success then
    v_sha:=nullif(p_result->>'artifact_sha256','');
    if v_sha is null or lower(v_sha)<>lower(coalesce(r.artifact_sha256,'')) then raise exception 'rolled-back artifact SHA-256 mismatch'; end if;
    if p_result->>'post_rollback_verification'<>'PASS' then raise exception 'post-rollback verification PASS evidence required'; end if;
    if r.target_adapter<>'mobile-release-artifact' and nullif(p_result->>'provider_url','') is null then raise exception 'rollback provider reference required'; end if;
    v_checks:=coalesce(p_result->'verification_checks','[]'::jsonb);
    if jsonb_typeof(v_checks)<>'array' or jsonb_array_length(v_checks)=0 then raise exception 'post-rollback verification checks required'; end if;
    select count(*) into v_bad from jsonb_array_elements(v_checks) c where lower(coalesce(c->>'status',''))<>'pass';
    if v_bad>0 then raise exception 'one or more post-rollback checks failed'; end if;

    update private.production_rollback_audits
      set state='succeeded',result=coalesce(p_result,'{}'::jsonb),error_text=null,finished_at=now(),updated_at=now(),
          evidence=coalesce(evidence,'{}'::jsonb)||jsonb_build_object('execution','PASS','post_rollback_verification','PASS','completed_at',now(),'verification_checks',v_checks)
      where id=r.id;

    update public.deployments
      set status='rolled_back',certificate=coalesce(certificate,'{}'::jsonb)||jsonb_build_object(
        'rollback','PASS','rollback_audit_id',r.id,'rollback_target_deployment_id',prev.id,
        'rollback_artifact_sha256',v_sha,'rollback_provider_url',p_result->>'provider_url',
        'post_rollback_verification','PASS','rolled_back_at',now(),'immutable_no_rebuild',true)
      where id=cur.id;

    update public.deployments
      set certificate=coalesce(certificate,'{}'::jsonb)||jsonb_build_object('restored_by_rollback',true,'rollback_audit_id',r.id,'restored_at',now())
      where id=prev.id;

    return jsonb_build_object('status','recorded','decision','rollback_succeeded','deployment_status','rolled_back','restored_deployment_id',prev.id,'artifact_sha256',v_sha);
  else
    if r.attempts<r.max_attempts then
      update private.production_rollback_audits set state='pending',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,updated_at=now() where id=r.id;
      return jsonb_build_object('status','recorded','decision','rollback_retry_queued');
    end if;
    update private.production_rollback_audits set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,finished_at=now(),updated_at=now() where id=r.id;
    return jsonb_build_object('status','recorded','decision','rollback_failed');
  end if;
end
$function$;;
