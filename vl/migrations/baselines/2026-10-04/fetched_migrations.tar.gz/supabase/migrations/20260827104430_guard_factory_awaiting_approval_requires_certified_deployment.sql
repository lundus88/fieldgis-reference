create or replace function private.guard_factory_awaiting_approval_requires_certified_deployment()
returns trigger
language plpgsql
set search_path to 'private','public','pg_temp'
as $$
begin
  if new.state='awaiting_approval' and (old.state is distinct from new.state) then
    if not exists (
      select 1 from public.deployments d
      where d.project_id=new.project_id
        and d.workflow_id=new.workflow_id
        and d.status='certified'
        and d.artifact_sha256 is not null
        and length(d.artifact_sha256)=64
    ) then
      raise exception 'awaiting_approval requires a certified deployment with immutable artifact SHA-256';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_guard_factory_awaiting_approval on public.factory_runs;
create trigger trg_guard_factory_awaiting_approval
before update of state on public.factory_runs
for each row
execute function private.guard_factory_awaiting_approval_requires_certified_deployment();;
