create or replace function public.vl_resend_reconciliation_source_check(p_provider_message_id text)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public, private
as $$
declare
  v_role text := coalesce(auth.role(), '');
  v_row private.notification_outbox%rowtype;
begin
  if v_role <> 'service_role' then
    raise exception 'service_role required' using errcode='42501';
  end if;
  if p_provider_message_id is null or btrim(p_provider_message_id) = '' then
    raise exception 'provider_message_id required' using errcode='22023';
  end if;
  select * into v_row
  from private.notification_outbox
  where provider_message_id = p_provider_message_id
    and environment = 'sandbox'
    and adapter_key = 'resend-email-v1'
  order by created_at desc
  limit 1;
  if not found then
    return jsonb_build_object('found',false,'provider_message_id',p_provider_message_id,'environment','sandbox');
  end if;
  return jsonb_build_object('found',true,'provider_message_id',v_row.provider_message_id,'status',v_row.status,'environment',v_row.environment,'adapter_key',v_row.adapter_key);
end;
$$;
revoke all on function public.vl_resend_reconciliation_source_check(text) from public, anon, authenticated;
grant execute on function public.vl_resend_reconciliation_source_check(text) to service_role;;
