alter table public.repair_recipe_registry add column if not exists success_count integer not null default 0;
alter table public.repair_recipe_registry add column if not exists failure_count integer not null default 0;
alter table public.repair_recipe_registry add column if not exists confidence numeric not null default 0.50 check (confidence >= 0 and confidence <= 1);
alter table public.repair_recipe_registry add column if not exists last_verified_at timestamptz;

create or replace function public.learn_from_ci_repair(
  p_action_id uuid,
  p_success boolean,
  p_details jsonb default '{}'::jsonb
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  a public.ci_repair_actions%rowtype;
  s int;
  f int;
  c numeric;
begin
  select * into a from public.ci_repair_actions where id=p_action_id;
  if not found then raise exception 'repair action not found'; end if;
  if not exists (select 1 from public.project_members where project_id=a.project_id and user_id=auth.uid()) then raise exception 'forbidden'; end if;

  update public.ci_repair_actions
  set state=case when p_success then 'verified' else 'failed' end,
      execution_result=coalesce(execution_result,'{}'::jsonb)||jsonb_build_object('verification',coalesce(p_details,'{}'::jsonb)),
      verified_at=case when p_success then now() else verified_at end,
      updated_at=now()
  where id=p_action_id;

  update public.repair_recipe_registry
  set success_count=success_count + case when p_success then 1 else 0 end,
      failure_count=failure_count + case when p_success then 0 else 1 end,
      last_verified_at=now(),
      confidence=least(0.99,greatest(0.05,
        ((success_count + case when p_success then 1 else 0 end + 1)::numeric /
         (success_count + failure_count + 3)::numeric)
      )),
      updated_at=now()
  where recipe_key=a.recipe_key
  returning success_count,failure_count,confidence into s,f,c;

  return jsonb_build_object('ok',true,'repair_action_id',p_action_id,'recipe_key',a.recipe_key,'success',p_success,'success_count',s,'failure_count',f,'confidence',c);
end;
$$;

grant execute on function public.learn_from_ci_repair(uuid,boolean,jsonb) to authenticated;;
