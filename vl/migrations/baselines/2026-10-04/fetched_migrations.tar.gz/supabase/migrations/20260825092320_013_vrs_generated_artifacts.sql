create table if not exists public.generated_artifacts (
  id uuid primary key default gen_random_uuid(),
  factory_run_id uuid not null references public.factory_runs(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  build_step_id uuid references public.build_steps(id) on delete cascade,
  artifact_kind text not null check (artifact_kind in ('source','migration','config','test','manifest','report','other')),
  path text not null,
  content text not null,
  sha256 text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(factory_run_id, path)
);

create index if not exists generated_artifacts_project_idx on public.generated_artifacts(project_id);
create index if not exists generated_artifacts_step_idx on public.generated_artifacts(build_step_id);

alter table public.generated_artifacts enable row level security;
grant select, insert, update, delete on public.generated_artifacts to authenticated;

create policy generated_artifacts_select_member on public.generated_artifacts
for select to authenticated using (private.is_project_member(project_id));

create policy generated_artifacts_insert_builder on public.generated_artifacts
for insert to authenticated with check (private.has_project_role(project_id, array['owner','admin','builder']));

create policy generated_artifacts_update_builder on public.generated_artifacts
for update to authenticated using (private.has_project_role(project_id, array['owner','admin','builder']))
with check (private.has_project_role(project_id, array['owner','admin','builder']));

create policy generated_artifacts_delete_admin on public.generated_artifacts
for delete to authenticated using (private.has_project_role(project_id, array['owner','admin']));

comment on table public.generated_artifacts is 'Deterministically generated VRS build outputs. No secrets may be stored here.';;
