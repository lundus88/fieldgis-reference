create table if not exists private.app_launch_audit (
  id uuid primary key default gen_random_uuid(),
  app_spec_id uuid not null,
  project_id uuid not null,
  approver_id uuid not null,
  builder_key text not null,
  workflow_id uuid,
  factory_run_id uuid,
  decision text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

revoke all on private.app_launch_audit from public, anon, authenticated;
grant select, insert on private.app_launch_audit to service_role;

create or replace function private.approve_and_launch_app_spec(p_app_spec_id uuid, p_approver_id uuid)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare
  v_spec public.app_specs%rowtype;
  v_builder_key text;
  v_builder_status text;
  v_workflow_id uuid;
  v_factory_run_id uuid;
  v_role text;
begin
  select * into v_spec from public.app_specs where id = p_app_spec_id for update;
  if not found then
    raise exception 'App Spec not found';
  end if;

  select pm.role into v_role
  from public.project_members pm
  where pm.project_id = v_spec.project_id and pm.user_id = p_approver_id;

  if v_role not in ('owner','admin') then
    raise exception 'Only project owner/admin may approve and launch App Spec';
  end if;

  if v_spec.status not in ('draft','approved') then
    raise exception 'App Spec status % cannot be launched', v_spec.status;
  end if;

  v_builder_key := v_spec.spec #>> '{selected_builder,builder_key}';
  if v_builder_key is null or btrim(v_builder_key) = '' then
    raise exception 'App Spec has no selected builder';
  end if;

  select br.status into v_builder_status
  from public.builder_registry br
  where br.builder_key = v_builder_key;

  if v_builder_status is distinct from 'active' then
    raise exception 'Selected builder % is not active', v_builder_key;
  end if;

  if v_spec.status <> 'approved' then
    update public.app_specs
      set status='approved', approved_by=p_approver_id, approved_at=now()
    where id=p_app_spec_id;
  end if;

  insert into public.workflows(project_id, app_spec_id, workflow_type, state, input, output, created_by)
  values(
    v_spec.project_id,
    p_app_spec_id,
    'factory_build',
    'queued',
    jsonb_build_object('builder_key',v_builder_key,'source','approved_app_spec'),
    '{}'::jsonb,
    p_approver_id
  ) returning id into v_workflow_id;

  insert into public.factory_runs(
    project_id, app_spec_id, workflow_id, requested_by, run_type, state,
    target_environment, production_locked, input, plan, result, target_platforms
  ) values(
    v_spec.project_id,
    p_app_spec_id,
    v_workflow_id,
    p_approver_id,
    'build',
    'queued',
    'staging',
    true,
    jsonb_build_object('builder_key',v_builder_key,'app_spec_id',p_app_spec_id),
    jsonb_build_object(
      'selected_builder',v_builder_key,
      'target_platforms',v_spec.target_platforms,
      'approval_required_for_production',true
    ),
    '{}'::jsonb,
    v_spec.target_platforms
  ) returning id into v_factory_run_id;

  insert into private.app_launch_audit(app_spec_id,project_id,approver_id,builder_key,workflow_id,factory_run_id,decision,details)
  values(
    p_app_spec_id,v_spec.project_id,p_approver_id,v_builder_key,v_workflow_id,v_factory_run_id,
    'launched',
    jsonb_build_object('environment','staging','production_locked',true)
  );

  return jsonb_build_object(
    'decision','launched',
    'app_spec_id',p_app_spec_id,
    'builder_key',v_builder_key,
    'workflow_id',v_workflow_id,
    'factory_run_id',v_factory_run_id,
    'target_environment','staging',
    'production_locked',true
  );
end;
$$;

revoke all on function private.approve_and_launch_app_spec(uuid,uuid) from public, anon, authenticated;
grant execute on function private.approve_and_launch_app_spec(uuid,uuid) to service_role;
;
