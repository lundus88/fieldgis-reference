create table if not exists public.customer_accounts (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null check (length(trim(display_name)) between 2 and 120),
  status text not null default 'pending' check (status in ('pending','active','suspended','closed')),
  plan_key text not null default 'launch_pilot',
  onboarding_state text not null default 'started' check (onboarding_state in ('started','profile_complete','terms_pending','ready','blocked')),
  terms_accepted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_user_id)
);
alter table public.customer_accounts enable row level security;
create policy customer_accounts_select_own on public.customer_accounts for select to authenticated using (owner_user_id=auth.uid());
create policy customer_accounts_insert_own on public.customer_accounts for insert to authenticated with check (owner_user_id=auth.uid());
create policy customer_accounts_update_own on public.customer_accounts for update to authenticated using (owner_user_id=auth.uid()) with check (owner_user_id=auth.uid());

create table if not exists public.plan_catalog (
  plan_key text primary key,
  name text not null,
  audience text not null,
  billing_status text not null default 'not_configured' check (billing_status in ('not_configured','sandbox','live')),
  currency text,
  amount_minor bigint,
  limits jsonb not null default '{}'::jsonb,
  is_public boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.plan_catalog enable row level security;
create policy plan_catalog_public_read on public.plan_catalog for select to anon,authenticated using (is_public=true);
insert into public.plan_catalog(plan_key,name,audience,billing_status,is_public,limits)
values ('launch_pilot','VL Launch Pilot','public beta','not_configured',true,'{"factory_runs_per_day":3,"concurrent_runs":1}'::jsonb)
on conflict (plan_key) do update set name=excluded.name,audience=excluded.audience,limits=excluded.limits,is_public=excluded.is_public;

create table if not exists private.usage_counters (
  id uuid primary key default gen_random_uuid(),
  customer_account_id uuid not null references public.customer_accounts(id) on delete cascade,
  metric_key text not null,
  window_start timestamptz not null,
  window_end timestamptz not null,
  used_count bigint not null default 0 check (used_count>=0),
  limit_count bigint not null check (limit_count>=0),
  updated_at timestamptz not null default now(),
  unique(customer_account_id,metric_key,window_start,window_end)
);
alter table private.usage_counters enable row level security;

create table if not exists public.support_requests (
  id uuid primary key default gen_random_uuid(),
  customer_account_id uuid not null references public.customer_accounts(id) on delete cascade,
  opened_by uuid not null references auth.users(id),
  severity text not null default 'normal' check (severity in ('low','normal','high','critical')),
  subject text not null check (length(trim(subject)) between 3 and 200),
  description text not null check (length(trim(description)) between 3 and 5000),
  status text not null default 'open' check (status in ('open','acknowledged','resolved','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  resolved_at timestamptz
);
alter table public.support_requests enable row level security;
create policy support_requests_select_own on public.support_requests for select to authenticated using (opened_by=auth.uid());
create policy support_requests_insert_own on public.support_requests for insert to authenticated with check (opened_by=auth.uid() and exists(select 1 from public.customer_accounts ca where ca.id=customer_account_id and ca.owner_user_id=auth.uid()));

create table if not exists private.operational_incidents (
  id uuid primary key default gen_random_uuid(),
  incident_key text not null unique,
  severity text not null check (severity in ('sev1','sev2','sev3','sev4')),
  status text not null default 'open' check (status in ('open','mitigating','resolved')),
  summary text not null,
  started_at timestamptz not null default now(),
  resolved_at timestamptz,
  evidence jsonb not null default '{}'::jsonb
);
alter table private.operational_incidents enable row level security;

create table if not exists private.launch_readiness_checks (
  check_key text primary key,
  category text not null,
  status text not null default 'pending' check (status in ('pending','pass','fail','blocked','not_applicable')),
  blocking boolean not null default true,
  evidence jsonb not null default '{}'::jsonb,
  checked_at timestamptz
);
alter table private.launch_readiness_checks enable row level security;

insert into private.launch_readiness_checks(check_key,category,status,blocking,evidence) values
('factory_governance','core','pass',true,'{"source":"qa_qc_final"}'::jsonb),
('production_rollback','core','pass',true,'{"source":"real_rehearsal"}'::jsonb),
('public_onboarding','commercial','pass',true,'{"source":"customer_accounts_rls"}'::jsonb),
('usage_rate_limits','operations','pass',true,'{"source":"usage_counters"}'::jsonb),
('support_intake','operations','pass',true,'{"source":"support_requests"}'::jsonb),
('incident_tracking','operations','pass',true,'{"source":"operational_incidents"}'::jsonb),
('live_billing','commercial','blocked',true,'{"reason":"production pricing/provider charging not yet configured; sandbox payment only"}'::jsonb),
('public_portal','commercial','pending',true,'{}'::jsonb),
('alerting_delivery','operations','pending',true,'{}'::jsonb)
on conflict(check_key) do update set category=excluded.category,status=excluded.status,blocking=excluded.blocking,evidence=excluded.evidence,checked_at=case when excluded.status='pass' then now() else private.launch_readiness_checks.checked_at end;

create index if not exists customer_accounts_status_idx on public.customer_accounts(status);
create index if not exists support_requests_status_created_idx on public.support_requests(status,created_at desc);
create index if not exists usage_counters_customer_metric_idx on private.usage_counters(customer_account_id,metric_key,window_end);
;
