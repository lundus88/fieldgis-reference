create or replace function private.ensure_release_candidate(p_factory_run_id uuid, p_actor uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','extensions','pg_temp'
as $$
declare
  v_run public.factory_runs%rowtype;
  v_env public.environments%rowtype;
  v_sha text; v_dep_id uuid; v_approval_id uuid; v_version text; v_required jsonb; g jsonb;
  v_builder text; v_builder_version integer; v_policy_version integer; v_policy_sha text;
  v_spec_doc jsonb; v_spec_sha text; v_source_commit text;
begin
  if p_actor is null then raise exception 'release candidate actor required'; end if;
  select * into v_run from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'factory run not found'; end if;
  if not exists(select 1 from public.project_members pm where pm.project_id=v_run.project_id and pm.user_id=p_actor and pm.role in ('owner','admin','builder')) then raise exception 'actor is not authorized project member'; end if;
  if v_run.state<>'validating' or v_run.target_environment<>'staging' or v_run.production_locked is not true then raise exception 'release candidate requires locked staging run in validating state'; end if;
  if coalesce(v_run.result->>'runner_status','')<>'PASS' then raise exception 'runner QA PASS required'; end if;
  v_sha:=coalesce(v_run.result#>>'{runner,artifact_sha256}',v_run.result->>'artifact_sha256');
  if v_sha is null or v_sha !~ '^[0-9a-fA-F]{64}$' then raise exception 'valid runner artifact SHA-256 required'; end if;
  if v_run.workflow_id is null then raise exception 'workflow_id required'; end if;

  select * into v_env from public.environments where project_id=v_run.project_id and kind='production' and status='ready' order by created_at desc limit 1;
  if not found then return jsonb_build_object('decision','blocked','reason','ready_production_environment_required','factory_run_id',v_run.id); end if;

  v_builder:=coalesce(v_run.result#>>'{runner,builder_key}',private.resolve_factory_builder(v_run.id));
  if v_builder is null then raise exception 'active builder required for release candidate'; end if;
  select builder_version into v_builder_version from public.builder_registry where builder_key=v_builder and status='active';
  if v_builder_version is null then raise exception 'active builder version required'; end if;

  v_required:=private.get_required_release_gates(v_run.id);
  select policy_version,policy_sha256 into v_policy_version,v_policy_sha from private.builder_release_gate_profiles where builder_key=v_builder;
  if v_policy_version is null then
    v_policy_version:=1;
    v_policy_sha:=encode(extensions.digest(convert_to(v_required::text,'UTF8'),'sha256'),'hex');
  end if;
  if lower(v_policy_sha)<>lower(encode(extensions.digest(convert_to(v_required::text,'UTF8'),'sha256'),'hex')) then
    raise exception 'resolved gate set does not match builder gate policy snapshot';
  end if;

  select jsonb_build_object('id',a.id,'version',a.version,'title',a.title,'objective',a.objective,'spec',a.spec,'software_kind',a.software_kind,'target_platforms',to_jsonb(a.target_platforms))
  into v_spec_doc from public.app_specs a where a.id=v_run.app_spec_id;
  if v_spec_doc is not null then v_spec_sha:=encode(extensions.digest(convert_to(v_spec_doc::text,'UTF8'),'sha256'),'hex'); end if;
  v_source_commit:=coalesce(v_run.result#>>'{runner,source_commit_sha}',v_run.result#>>'{runner,commit_sha}',v_run.result#>>'{runner,head_sha}',v_run.result->>'source_commit_sha',v_run.result->>'commit_sha');

  for g in select value from jsonb_array_elements(v_required) loop
    insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence,score,checked_at)
    values(v_run.project_id,v_run.id,g->>'key',g->>'type',case when g->>'key'='qa_regression' then 'pass' else 'pending' end,
      case when g->>'key'='qa_regression' then jsonb_build_object('runner','github-actions-oidc','runner_status','PASS','artifact_sha256',v_sha,'github_run_id',v_run.result#>>'{runner,github_run_id}') else '{}'::jsonb end,
      case when g->>'key'='qa_regression' then 1 else null end,case when g->>'key'='qa_regression' then now() else null end)
    on conflict(factory_run_id,gate_key) do update set
      status=case when excluded.gate_key='qa_regression' then 'pass' else public.release_gates.status end,
      evidence=case when excluded.gate_key='qa_regression' then excluded.evidence else public.release_gates.evidence end,
      score=case when excluded.gate_key='qa_regression' then 1 else public.release_gates.score end,
      checked_at=case when excluded.gate_key='qa_regression' then now() else public.release_gates.checked_at end;
  end loop;
  insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence)
  values(v_run.project_id,v_run.id,'human_production_approval','human_approval','pending','{}'::jsonb),(v_run.project_id,v_run.id,'production_lock','production_lock','pending','{}'::jsonb)
  on conflict(factory_run_id,gate_key) do nothing;

  select id into v_dep_id from public.deployments where factory_run_id=v_run.id and project_id=v_run.project_id and artifact_sha256=v_sha and status in ('planned','certified','approved','deploying','deployed') limit 1;
  if v_dep_id is null then
    v_version:='vl-'||to_char(clock_timestamp(),'YYYYMMDDHH24MISS')||'-'||left(v_sha,8);
    insert into public.deployments(
      project_id,environment_id,workflow_id,factory_run_id,release_version,status,artifact_sha256,certificate,created_by,
      required_gates_snapshot,builder_key_snapshot,builder_version_snapshot,gate_policy_version_snapshot,gate_policy_sha256,app_spec_sha256,source_commit_sha
    ) values(
      v_run.project_id,v_env.id,v_run.workflow_id,v_run.id,v_version,'planned',v_sha,
      jsonb_build_object('schema','vrs.release-certificate/3','factory_run_id',v_run.id,'artifact_sha256',v_sha,'builder_key',v_builder,'builder_version',v_builder_version,'runner_qa','PASS','production_locked',true,'required_gates',v_required,'gate_policy_version',v_policy_version,'gate_policy_sha256',v_policy_sha,'app_spec_sha256',v_spec_sha,'source_commit_sha',v_source_commit,'certification_snapshot_version',1),p_actor,
      v_required,v_builder,v_builder_version,v_policy_version,v_policy_sha,v_spec_sha,v_source_commit
    ) returning id into v_dep_id;
  end if;

  select id into v_approval_id from public.approvals where factory_run_id=v_run.id and project_id=v_run.project_id and workflow_id=v_run.workflow_id and approval_type='production_release' and status='pending' limit 1 for update;
  if v_approval_id is null then
    insert into public.approvals(project_id,workflow_id,factory_run_id,approval_type,status,requested_by,rationale)
    values(v_run.project_id,v_run.workflow_id,v_run.id,'production_release','pending',p_actor,'Autonomous staging build passed runner QA. Technical release gates must pass before explicit production approval.') returning id into v_approval_id;
  end if;
  return jsonb_build_object('decision','release_candidate_prepared','factory_run_id',v_run.id,'deployment_id',v_dep_id,'approval_id',v_approval_id,'artifact_sha256',v_sha,'required_gates',v_required,'gate_policy_version',v_policy_version,'gate_policy_sha256',v_policy_sha,'deployment_status','planned','human_approval','pending','production_locked',true);
end
$$;

create or replace function public.claim_vrs_release_validation_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $$
declare
  j private.release_validation_jobs%rowtype; v_lease uuid:=gen_random_uuid(); v_run public.factory_runs%rowtype; v_dep public.deployments%rowtype; v_required jsonb; v_artifacts jsonb;
begin
  select * into j from private.release_validation_jobs where (state='queued' or (state='leased' and lease_expires_at<now())) and attempts<max_attempts order by created_at for update skip locked limit 1;
  if not found then return jsonb_build_object('status','idle'); end if;
  update private.release_validation_jobs set state='leased',attempts=attempts+1,lease_token=v_lease,leased_at=now(),lease_expires_at=now()+interval '20 minutes',runner_identity=coalesce(p_runner_identity,'{}'::jsonb),updated_at=now() where id=j.id returning * into j;
  select * into v_run from public.factory_runs where id=j.factory_run_id;
  select * into v_dep from public.deployments where id=j.deployment_id;
  if v_dep.factory_run_id is distinct from j.factory_run_id or v_dep.status<>'planned' or v_run.state<>'validating' or v_run.production_locked is distinct from true then
    update private.release_validation_jobs set state='failed',error_text='release candidate not eligible',finished_at=now(),updated_at=now() where id=j.id;
    return jsonb_build_object('status','rejected','reason','release_candidate_not_eligible');
  end if;
  v_required:=private.get_deployment_required_gates(v_dep.id);
  if jsonb_array_length(v_required)=0 then raise exception 'deployment gate snapshot missing'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('path',g.path,'content',g.content,'sha256',g.sha256,'artifact_kind',g.artifact_kind,'metadata',g.metadata) order by g.path),'[]'::jsonb) into v_artifacts from public.generated_artifacts g where g.factory_run_id=v_run.id;
  return jsonb_build_object('status','leased','job_id',j.id,'lease_token',v_lease,'deployment_id',j.deployment_id,'factory_run_id',j.factory_run_id,'builder_key',v_dep.builder_key_snapshot,'builder_version',v_dep.builder_version_snapshot,'artifact_sha256',v_dep.artifact_sha256,'required_gates',v_required,'gate_policy_version',v_dep.gate_policy_version_snapshot,'gate_policy_sha256',v_dep.gate_policy_sha256,'generated_artifacts',v_artifacts,'attempt',j.attempts,'max_attempts',j.max_attempts);
end
$$;

create or replace function public.complete_vrs_release_validation_job(p_job_id uuid,p_lease_token uuid,p_success boolean,p_gate_results jsonb default '[]'::jsonb,p_result jsonb default '{}'::jsonb,p_error_text text default null)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $$
declare
  j private.release_validation_jobs%rowtype; v_dep public.deployments%rowtype; v_required jsonb; r jsonb; v_missing int; v_fail int;
begin
  select * into j from private.release_validation_jobs where id=p_job_id for update;
  if not found then raise exception 'release validation job not found'; end if;
  if j.state<>'leased' or j.lease_token is distinct from p_lease_token then raise exception 'invalid release validation lease'; end if;
  if j.lease_expires_at<now() then raise exception 'release validation lease expired'; end if;
  select * into v_dep from public.deployments where id=j.deployment_id for update;
  if not found or v_dep.factory_run_id is distinct from j.factory_run_id then raise exception 'release validation deployment binding mismatch'; end if;
  v_required:=private.get_deployment_required_gates(j.deployment_id);
  if jsonb_array_length(v_required)=0 then raise exception 'deployment gate snapshot missing'; end if;

  if p_success then
    if jsonb_typeof(coalesce(p_gate_results,'[]'::jsonb))<>'array' then raise exception 'gate_results must be array'; end if;
    for r in select value from jsonb_array_elements(coalesce(p_gate_results,'[]'::jsonb)) loop
      if (r->>'key') in ('human_production_approval','production_lock') then raise exception 'human/production lock gates cannot be set by automated validator'; end if;
      if not exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'=r->>'key') then raise exception 'validator returned gate not present in frozen deployment policy: %',r->>'key'; end if;
      if coalesce(r->>'status','') not in ('pass','fail') then raise exception 'automated gate status must be pass or fail'; end if;
      update public.release_gates set status=r->>'status',score=case when r ? 'score' then (r->>'score')::numeric else case when r->>'status'='pass' then 1 else 0 end end,evidence=coalesce(r->'evidence','{}'::jsonb),checked_at=now(),checked_by=null where factory_run_id=j.factory_run_id and gate_key=r->>'key';
    end loop;
    select count(*) into v_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=j.factory_run_id and rg.gate_key=g->>'key' and rg.status='pass');
    select count(*) into v_fail from jsonb_array_elements(v_required) g where exists(select 1 from public.release_gates rg where rg.factory_run_id=j.factory_run_id and rg.gate_key=g->>'key' and rg.status='fail');
    if v_fail>0 then
      update private.release_validation_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text='one or more technical release gates failed',finished_at=now(),updated_at=now() where id=j.id;
      update public.deployments set status='failed',certificate=certificate||jsonb_build_object('technical_validation','FAIL','validation_result',coalesce(p_result,'{}'::jsonb)) where id=j.deployment_id;
      update public.factory_runs set state='failed',error_text='Technical release validation failed',finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',finished_at=now(),output=coalesce(w.output,'{}'::jsonb)||jsonb_build_object('technical_validation','FAIL') from public.factory_runs fr where fr.id=j.factory_run_id and w.id=fr.workflow_id;
      return jsonb_build_object('status','recorded','decision','technical_gates_failed','missing_or_failed',v_missing);
    elsif v_missing=0 then
      update private.release_validation_jobs set state='succeeded',result=coalesce(p_result,'{}'::jsonb),error_text=null,finished_at=now(),updated_at=now() where id=j.id;
      update public.deployments set status='certified',certificate=certificate||jsonb_build_object('technical_validation','PASS','validation_result',coalesce(p_result,'{}'::jsonb),'certified_at',now(),'gate_policy_version',gate_policy_version_snapshot,'gate_policy_sha256',gate_policy_sha256) where id=j.deployment_id;
      update public.factory_runs set state='awaiting_approval',result=coalesce(result,'{}'::jsonb)||jsonb_build_object('technical_certification','PASS'),error_text=null where id=j.factory_run_id and target_environment<>'production' and production_locked=true;
      update public.workflows w set state='waiting_approval',output=coalesce(w.output,'{}'::jsonb)||jsonb_build_object('technical_validation','PASS') from public.factory_runs fr where fr.id=j.factory_run_id and w.id=fr.workflow_id;
      return jsonb_build_object('status','recorded','decision','technically_certified','deployment_status','certified','factory_run_state','awaiting_approval','gate_policy_version',v_dep.gate_policy_version_snapshot,'gate_policy_sha256',v_dep.gate_policy_sha256);
    else
      update private.release_validation_jobs set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text='required frozen gates still pending',updated_at=now() where id=j.id;
      update public.factory_runs set state='validating',error_text=null where id=j.factory_run_id and state<>'failed';
      return jsonb_build_object('status','recorded','decision','more_validation_required','missing_or_failed',v_missing,'factory_run_state','validating');
    end if;
  else
    if j.attempts<j.max_attempts then
      update private.release_validation_jobs set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,updated_at=now() where id=j.id;
      update public.factory_runs set state='validating',error_text=p_error_text where id=j.factory_run_id and state<>'failed';
      return jsonb_build_object('status','recorded','decision','retry_queued','factory_run_state','validating');
    else
      update private.release_validation_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,finished_at=now(),updated_at=now() where id=j.id;
      update public.deployments set status='failed',certificate=certificate||jsonb_build_object('technical_validation','FAIL','error',p_error_text) where id=j.deployment_id;
      update public.factory_runs set state='failed',error_text=coalesce(p_error_text,'Release validation failed'),finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',finished_at=now(),output=coalesce(w.output,'{}'::jsonb)||jsonb_build_object('technical_validation','FAIL','error',p_error_text) from public.factory_runs fr where fr.id=j.factory_run_id and w.id=fr.workflow_id;
      return jsonb_build_object('status','recorded','decision','validation_failed','factory_run_state','failed');
    end if;
  end if;
end
$$;

create or replace function private.approve_production_release(p_deployment_id uuid,p_rationale text default null)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_uid uuid:=auth.uid(); v_dep public.deployments%rowtype; v_run public.factory_runs%rowtype; v_required jsonb; v_missing int; v_approval_id uuid;
begin
  if v_uid is null then raise exception 'authenticated user required'; end if;
  select * into v_dep from public.deployments where id=p_deployment_id for update;
  if not found then raise exception 'deployment not found'; end if;
  if not private.has_project_role(v_dep.project_id,array['owner','admin']) then raise exception 'owner/admin production approval required'; end if;
  if v_dep.status<>'certified' then raise exception 'deployment must be technically certified before approval'; end if;
  select * into v_run from public.factory_runs where id=v_dep.factory_run_id and project_id=v_dep.project_id for update;
  if not found then raise exception 'factory run not found'; end if;
  if v_dep.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow mismatch'; end if;
  v_required:=private.get_deployment_required_gates(v_dep.id);
  if jsonb_array_length(v_required)=0 then raise exception 'frozen deployment gate policy required'; end if;
  select count(*) into v_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass');
  if v_missing>0 then raise exception 'frozen technical release gates not all PASS'; end if;
  select id into v_approval_id from public.approvals where factory_run_id=v_run.id and project_id=v_dep.project_id and workflow_id=v_dep.workflow_id and approval_type='production_release' and status='pending' limit 1 for update;
  if v_approval_id is null then raise exception 'pending production approval record required'; end if;
  update public.approvals set status='approved',decided_by=v_uid,decided_at=now(),rationale=coalesce(nullif(p_rationale,''),rationale,'Explicit owner/admin production approval') where id=v_approval_id;
  update public.release_gates set status='pass',score=1,evidence=jsonb_build_object('approval_id',v_approval_id,'approved_by',v_uid,'approved_at',now(),'explicit_human_approval',true),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key='human_production_approval';
  update public.release_gates set status='pass',score=1,evidence=jsonb_build_object('release_unlock','approved','approved_by',v_uid,'approved_at',now(),'factory_run_remains_immutable',true),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key='production_lock';
  update public.deployments set status='approved',approved_by=v_uid,certificate=certificate||jsonb_build_object('human_approval','PASS','approved_by',v_uid,'approved_at',now(),'production_release_authorized',true) where id=v_dep.id;
  return jsonb_build_object('decision','production_release_approved','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval_id,'approved_by',v_uid,'artifact_sha256',v_dep.artifact_sha256,'gate_policy_version',v_dep.gate_policy_version_snapshot,'gate_policy_sha256',v_dep.gate_policy_sha256,'next_state','approved');
end
$$;

create or replace function private.enforce_production_deployment_guard()
returns trigger
language plpgsql
security definer
set search_path to 'public','private','pg_temp'
as $$
declare
  v_env_kind text; v_run public.factory_runs%rowtype; v_required jsonb; v_technical_missing int; v_human_ok boolean; v_unlock_ok boolean; v_approval_ok boolean; v_cert_hash text;
begin
  select kind into v_env_kind from public.environments where id=new.environment_id and project_id=new.project_id;
  if v_env_kind is distinct from 'production' then return new; end if;
  if new.status not in ('certified','approved','deploying','deployed') then return new; end if;
  if new.workflow_id is null then raise exception 'production deployment requires workflow_id'; end if;
  if new.factory_run_id is null then raise exception 'production deployment requires factory_run_id'; end if;
  select * into v_run from public.factory_runs where id=new.factory_run_id and project_id=new.project_id;
  if not found then raise exception 'production deployment requires a valid factory run'; end if;
  if new.workflow_id is distinct from v_run.workflow_id then raise exception 'production deployment workflow does not match factory run'; end if;
  v_required:=coalesce(new.required_gates_snapshot,'[]'::jsonb);
  if jsonb_array_length(v_required)=0 then raise exception 'production deployment requires frozen gate policy'; end if;
  select count(*) into v_technical_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass');
  if v_technical_missing>0 then raise exception 'production certification blocked: frozen required gates not all PASS'; end if;
  if new.artifact_sha256 is null or new.artifact_sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'production deployment requires valid SHA-256 artifact hash'; end if;
  v_cert_hash:=coalesce(new.certificate->>'artifact_sha256',new.certificate->>'sha256');
  if v_cert_hash is null or lower(v_cert_hash)<>lower(new.artifact_sha256) then raise exception 'production certificate hash does not match artifact SHA-256'; end if;
  if new.gate_policy_sha256 is null or lower(new.gate_policy_sha256)<>lower(encode(extensions.digest(convert_to(new.required_gates_snapshot::text,'UTF8'),'sha256'),'hex')) then raise exception 'production gate policy snapshot hash mismatch'; end if;
  if new.status in ('approved','deploying','deployed') then
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='human_production_approval' and rg.status='pass') into v_human_ok;
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='production_lock' and rg.status='pass') into v_unlock_ok;
    select exists(select 1 from public.approvals a where a.factory_run_id=v_run.id and a.project_id=new.project_id and a.workflow_id=new.workflow_id and a.approval_type='production_release' and a.status='approved' and a.decided_by is not null and a.decided_at is not null) into v_approval_ok;
    if not v_human_ok then raise exception 'production deployment blocked: human production approval gate not PASS'; end if;
    if not v_unlock_ok then raise exception 'production deployment blocked: production lock not released'; end if;
    if not v_approval_ok then raise exception 'production deployment blocked: approved human approval record required'; end if;
    if new.approved_by is null then raise exception 'production deployment blocked: approved_by required'; end if;
  end if;
  if new.status='deployed' and new.deployed_at is null then new.deployed_at:=now(); end if;
  return new;
end
$$;;
