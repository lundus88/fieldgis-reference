create schema if not exists private;

create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','builder','reviewer','viewer')),
  created_at timestamptz not null default now(),
  primary key (organization_id,user_id)
);

create index organization_members_user_idx on public.organization_members(user_id, organization_id);

create or replace function private.is_org_member(p_org uuid, p_user uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public, private
as $$
  select p_user is not null and exists (
    select 1 from public.organization_members m
    where m.organization_id = p_org and m.user_id = p_user
  );
$$;

create or replace function private.has_org_role(p_org uuid, p_roles text[], p_user uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public, private
as $$
  select p_user is not null and exists (
    select 1 from public.organization_members m
    where m.organization_id = p_org and m.user_id = p_user and m.role = any(p_roles)
  );
$$;

revoke all on function private.is_org_member(uuid,uuid) from public;
revoke all on function private.has_org_role(uuid,text[],uuid) from public;
grant usage on schema private to authenticated;
grant execute on function private.is_org_member(uuid,uuid) to authenticated;
grant execute on function private.has_org_role(uuid,text[],uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;

create policy profiles_select_self on public.profiles for select to authenticated using ((select auth.uid()) = user_id);
create policy profiles_insert_self on public.profiles for insert to authenticated with check ((select auth.uid()) = user_id);
create policy profiles_update_self on public.profiles for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy organizations_select_member on public.organizations for select to authenticated using (private.is_org_member(id));
create policy organizations_insert_creator on public.organizations for insert to authenticated with check ((select auth.uid()) = created_by);
create policy organizations_update_admin on public.organizations for update to authenticated using (private.has_org_role(id,array['owner','admin'])) with check (private.has_org_role(id,array['owner','admin']));

create policy organization_members_select_member on public.organization_members for select to authenticated using (private.is_org_member(organization_id));
create policy organization_members_insert_admin on public.organization_members for insert to authenticated with check (
  private.has_org_role(organization_id,array['owner','admin'])
  or (
    user_id = (select auth.uid())
    and role = 'owner'
    and exists (select 1 from public.organizations o where o.id = organization_id and o.created_by = (select auth.uid()))
  )
);
create policy organization_members_update_admin on public.organization_members for update to authenticated using (private.has_org_role(organization_id,array['owner','admin'])) with check (private.has_org_role(organization_id,array['owner','admin']));
create policy organization_members_delete_admin on public.organization_members for delete to authenticated using (private.has_org_role(organization_id,array['owner','admin']));

grant select, insert, update on public.profiles to authenticated;
grant select, insert, update on public.organizations to authenticated;
grant select, insert, update, delete on public.organization_members to authenticated;;
