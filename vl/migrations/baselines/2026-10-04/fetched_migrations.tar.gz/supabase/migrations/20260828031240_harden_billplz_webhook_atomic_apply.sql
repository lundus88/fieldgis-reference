create or replace function private.apply_billplz_sandbox_webhook(
  p_event_key text,
  p_provider_bill_id text,
  p_payload_sha256 text,
  p_normalized_status text,
  p_amount_minor integer
) returns jsonb
language plpgsql
security definer
set search_path = private, pg_temp
as $$
declare
  v_order private.payment_sandbox_orders%rowtype;
  v_existing private.payment_webhook_events%rowtype;
  v_applied boolean := false;
  v_now timestamptz := now();
begin
  if coalesce(trim(p_event_key),'') = '' or coalesce(trim(p_provider_bill_id),'') = '' then
    raise exception 'invalid webhook identity';
  end if;
  if p_normalized_status not in ('paid','pending','cancelled') then
    raise exception 'invalid normalized status';
  end if;

  select * into v_existing from private.payment_webhook_events where event_key = p_event_key;
  if found then
    return jsonb_build_object('ok',true,'duplicate',true,'applied',false,'status',p_normalized_status);
  end if;

  select * into v_order from private.payment_sandbox_orders
   where provider_bill_id = p_provider_bill_id
   for update;
  if not found then raise exception 'unknown sandbox bill'; end if;
  if v_order.environment <> 'sandbox' or v_order.adapter_key <> 'billplz-payment-v1' then
    raise exception 'sandbox adapter invariant failed';
  end if;
  if p_amount_minor is distinct from v_order.amount_minor then raise exception 'amount mismatch'; end if;
  if v_order.currency <> 'MYR' then raise exception 'currency mismatch'; end if;

  if p_normalized_status = 'paid' and v_order.status <> 'paid' then
    update private.payment_sandbox_orders
       set status='paid', paid_at=coalesce(paid_at,v_now), updated_at=v_now,
           metadata=coalesce(metadata,'{}'::jsonb) || jsonb_build_object(
             'payment_confirmed_by','billplz_signed_webhook',
             'fulfillment_separated',true
           )
     where id=v_order.id and fulfillment_state='unfulfilled' and status <> 'paid';
    v_applied := found;
  end if;

  begin
    insert into private.payment_webhook_events(
      adapter_key,event_key,provider_bill_id,payload_sha256,signature_valid,
      normalized_status,amount_minor,applied,duplicate,processed_at,metadata
    ) values (
      'billplz-payment-v1',p_event_key,p_provider_bill_id,p_payload_sha256,true,
      p_normalized_status,p_amount_minor,v_applied,false,v_now,
      jsonb_build_object('environment','sandbox','authoritative_source','server_callback','fulfillment_mutated',false)
    );
  exception when unique_violation then
    return jsonb_build_object('ok',true,'duplicate',true,'applied',false,'status',p_normalized_status);
  end;

  return jsonb_build_object('ok',true,'duplicate',false,'applied',v_applied,'status',p_normalized_status,'fulfillment_mutated',false);
end;
$$;
revoke all on function private.apply_billplz_sandbox_webhook(text,text,text,text,integer) from public, anon, authenticated;
grant execute on function private.apply_billplz_sandbox_webhook(text,text,text,text,integer) to service_role;;
