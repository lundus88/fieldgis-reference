begin;
insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence)
select distinct d.project_id,d.factory_run_id,'supply_chain_attestation','supply_chain','pending',jsonb_build_object('source','mandatory_gate_backfill','backfilled_at',now())
from public.deployments d
where d.factory_run_id is not null
  and d.artifact_sha256 is not null
  and not exists (
    select 1 from public.release_gates rg
    where rg.factory_run_id=d.factory_run_id and rg.gate_key='supply_chain_attestation'
  )
on conflict(factory_run_id,gate_key) do nothing;
commit;;
