create table if not exists private.capability_adapter_registry (
  adapter_key text primary key,
  adapter_type text not null check (adapter_type in ('auth','storage','payment','notification','database')),
  provider text not null,
  version text not null,
  status text not null default 'experimental' check (status in ('experimental','candidate','active','disabled')),
  capabilities jsonb not null default '{}'::jsonb,
  required_gates jsonb not null default '[]'::jsonb,
  configuration jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists private.capability_adapter_evidence (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key) on delete cascade,
  evidence_type text not null,
  evidence_status text not null check (evidence_status in ('pass','fail','pending')),
  source_factory_run_id uuid null references public.factory_runs(id),
  source_project_id uuid null references public.projects(id),
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists private.capability_adapter_results (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key) on delete cascade,
  decision text not null check (decision in ('not_ready','candidate','certified')),
  score numeric not null default 0 check (score >= 0 and score <= 1),
  passed_gates text[] not null default '{}',
  missing_gates text[] not null default '{}',
  evaluated_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

alter table private.capability_adapter_registry enable row level security;
alter table private.capability_adapter_evidence enable row level security;
alter table private.capability_adapter_results enable row level security;

grant all on private.capability_adapter_registry to service_role;
grant all on private.capability_adapter_evidence to service_role;
grant all on private.capability_adapter_results to service_role;
revoke all on private.capability_adapter_registry from anon, authenticated;
revoke all on private.capability_adapter_evidence from anon, authenticated;
revoke all on private.capability_adapter_results from anon, authenticated;

create or replace view public.capability_adapter_status
with (security_invoker = true)
as
select adapter_key, adapter_type, provider, version, status, capabilities, required_gates, updated_at
from private.capability_adapter_registry;

revoke all on public.capability_adapter_status from anon, authenticated;
grant select on public.capability_adapter_status to service_role;

insert into private.capability_adapter_registry(adapter_key,adapter_type,provider,version,status,capabilities,required_gates,configuration)
values
('supabase-auth-v1','auth','supabase','1.0.0','experimental',
 '{"email_password":true,"jwt":true,"rbac":true,"tenant_membership":true,"password_reset":true}'::jsonb,
 '["auth_http_e2e","cross_tenant_rls","security_advisor"]'::jsonb,
 '{"verify_jwt_required":true,"client_direct_private_control_plane":false}'::jsonb),
('supabase-storage-v1','storage','supabase','1.0.0','experimental',
 '{"private_bucket":true,"upload":true,"download":true,"delete":true,"project_scoped_paths":true,"role_based_write":true}'::jsonb,
 '["storage_physical_e2e","cross_tenant_rls","security_advisor"]'::jsonb,
 '{"bucket":"vrs-private","public":false,"client_direct_private_control_plane":false}'::jsonb)
on conflict (adapter_key) do update set
  adapter_type=excluded.adapter_type,
  provider=excluded.provider,
  version=excluded.version,
  capabilities=excluded.capabilities,
  required_gates=excluded.required_gates,
  configuration=excluded.configuration,
  updated_at=now();;
