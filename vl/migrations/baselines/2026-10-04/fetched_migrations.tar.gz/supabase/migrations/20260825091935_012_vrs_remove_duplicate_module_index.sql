drop index if exists public.module_registry_project_key_uq;;
