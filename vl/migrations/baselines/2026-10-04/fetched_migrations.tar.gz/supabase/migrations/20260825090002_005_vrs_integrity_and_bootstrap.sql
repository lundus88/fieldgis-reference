create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

revoke all on function public.touch_updated_at() from public;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles for each row execute function public.touch_updated_at();
drop trigger if exists organizations_touch_updated_at on public.organizations;
create trigger organizations_touch_updated_at before update on public.organizations for each row execute function public.touch_updated_at();
drop trigger if exists projects_touch_updated_at on public.projects;
create trigger projects_touch_updated_at before update on public.projects for each row execute function public.touch_updated_at();

create or replace function public.create_organization_with_owner(p_name text, p_slug text)
returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  insert into public.organizations(name,slug,created_by)
  values (p_name,p_slug,auth.uid()) returning id into v_id;
  insert into public.organization_members(organization_id,user_id,role)
  values (v_id,auth.uid(),'owner');
  return v_id;
end;
$$;

grant execute on function public.create_organization_with_owner(text,text) to authenticated;

create or replace function public.create_project_with_owner(p_organization_id uuid, p_name text, p_slug text, p_description text default null)
returns uuid
language plpgsql
security invoker
set search_path = public, private
as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not private.has_org_role(p_organization_id,array['owner','admin','builder']) then raise exception 'insufficient organization role'; end if;
  insert into public.projects(organization_id,name,slug,description,created_by)
  values (p_organization_id,p_name,p_slug,p_description,auth.uid()) returning id into v_id;
  insert into public.project_members(project_id,user_id,role)
  values (v_id,auth.uid(),'owner');
  insert into public.environments(project_id,name,kind) values
    (v_id,'development','development'),
    (v_id,'staging','staging'),
    (v_id,'production','production');
  return v_id;
end;
$$;

grant execute on function public.create_project_with_owner(uuid,text,text,text) to authenticated;

comment on table public.organizations is 'VRS tenant boundary.';
comment on table public.projects is 'A SaaS/application build managed by VRS.';
comment on table public.app_specs is 'Versioned human/AI-approved application specification.';
comment on table public.workflows is 'Orchestrator workflow state.';
comment on table public.approvals is 'Human approval gates for consequential actions.';
comment on table public.deployments is 'Release/deployment records; production requires explicit approval.';
comment on table public.audit_logs is 'Append-only user-visible audit trail.';;
