create or replace function private.billplz_production_readiness()
returns jsonb
language sql
security definer
set search_path=private,public,pg_temp
as $$
select jsonb_build_object(
  'adapter_key',r.adapter_key,
  'adapter_status',r.status,
  'live_charge_allowed',coalesce((r.capabilities->>'live_charge_allowed')::boolean,false) and coalesce((r.configuration->>'live_charge_allowed')::boolean,false),
  'sandbox_e2e_verified_at',r.configuration->>'sandbox_e2e_verified_at',
  'production_credentials_configured',coalesce((r.configuration->>'production_credentials_configured')::boolean,false)
)
from private.capability_adapter_registry r where r.adapter_key='billplz-payment-v1';
$$;
revoke all on function private.billplz_production_readiness() from public,anon,authenticated;
grant execute on function private.billplz_production_readiness() to service_role;
create or replace function public.get_vrs_billplz_production_readiness()
returns jsonb language sql security definer set search_path=private,public,pg_temp as $$ select private.billplz_production_readiness(); $$;
revoke all on function public.get_vrs_billplz_production_readiness() from public,anon,authenticated;
grant execute on function public.get_vrs_billplz_production_readiness() to service_role;;
