grant insert on table public.release_gates to authenticated;;
