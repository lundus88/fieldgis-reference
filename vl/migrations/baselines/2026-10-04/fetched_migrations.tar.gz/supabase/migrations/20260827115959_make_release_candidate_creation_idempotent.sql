create unique index if not exists deployments_factory_run_environment_uidx on public.deployments(factory_run_id,environment_id);

create or replace function private.ensure_release_candidate(p_factory_run_id uuid, p_actor uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_run public.factory_runs%rowtype;
  v_env public.environments%rowtype;
  v_sha text; v_dep_id uuid; v_approval_id uuid; v_version text; v_required jsonb; g jsonb;
  v_builder text; v_builder_version integer; v_policy_version integer; v_profile_hash text; v_effective_hash text; v_app_spec_hash text;
begin
  if p_actor is null then raise exception 'release candidate actor required'; end if;
  select * into v_run from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'factory run not found'; end if;
  if not exists(select 1 from public.project_members pm where pm.project_id=v_run.project_id and pm.user_id=p_actor and pm.role in ('owner','admin','builder')) then raise exception 'actor is not authorized project member'; end if;
  if v_run.state<>'validating' or v_run.target_environment<>'staging' or v_run.production_locked is not true then raise exception 'release candidate requires locked staging run in validating state'; end if;
  if coalesce(v_run.result->>'runner_status','')<>'PASS' then raise exception 'runner QA PASS required'; end if;
  v_sha:=coalesce(v_run.result#>>'{runner,artifact_sha256}',v_run.result->>'artifact_sha256');
  if v_sha is null or v_sha !~ '^[0-9a-fA-F]{64}$' then raise exception 'valid runner artifact SHA-256 required'; end if;
  if v_run.workflow_id is null then raise exception 'workflow_id required'; end if;

  select * into v_env from public.environments where project_id=v_run.project_id and kind='production' and status='ready' order by created_at desc limit 1;
  if not found then return jsonb_build_object('decision','blocked','reason','ready_production_environment_required','factory_run_id',v_run.id); end if;

  v_builder:=coalesce(v_run.result#>>'{runner,builder_key}',private.resolve_factory_builder(v_run.id));
  select coalesce(br.version,1) into v_builder_version from public.builder_registry br where br.builder_key=v_builder;
  select coalesce(p.policy_version,1),p.policy_sha256 into v_policy_version,v_profile_hash from private.builder_release_gate_profiles p where p.builder_key=v_builder;
  v_required:=private.get_required_release_gates(v_run.id);
  v_effective_hash:=encode(digest(convert_to(v_required::text,'UTF8'),'sha256'),'hex');
  select encode(digest(convert_to(jsonb_build_object('version',a.version,'title',a.title,'objective',a.objective,'software_kind',a.software_kind,'target_platforms',a.target_platforms,'spec',a.spec)::text,'UTF8'),'sha256'),'hex') into v_app_spec_hash from public.app_specs a where a.id=v_run.app_spec_id;

  for g in select value from jsonb_array_elements(v_required) loop
    insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence,score,checked_at)
    values(v_run.project_id,v_run.id,g->>'key',g->>'type',case when g->>'key'='qa_regression' then 'pass' else 'pending' end,
      case when g->>'key'='qa_regression' then jsonb_build_object('runner','github-actions-oidc','runner_status','PASS','artifact_sha256',v_sha,'github_run_id',v_run.result#>>'{runner,github_run_id}') else '{}'::jsonb end,
      case when g->>'key'='qa_regression' then 1 else null end,case when g->>'key'='qa_regression' then now() else null end)
    on conflict(factory_run_id,gate_key) do update set
      status=case when excluded.gate_key='qa_regression' then 'pass' else public.release_gates.status end,
      evidence=case when excluded.gate_key='qa_regression' then excluded.evidence else public.release_gates.evidence end,
      score=case when excluded.gate_key='qa_regression' then 1 else public.release_gates.score end,
      checked_at=case when excluded.gate_key='qa_regression' then now() else public.release_gates.checked_at end;
  end loop;
  insert into public.release_gates(project_id,factory_run_id,gate_key,gate_type,status,evidence)
  values(v_run.project_id,v_run.id,'human_production_approval','human_approval','pending','{}'::jsonb),(v_run.project_id,v_run.id,'production_lock','production_lock','pending','{}'::jsonb)
  on conflict(factory_run_id,gate_key) do nothing;

  v_version:='vl-'||to_char(clock_timestamp(),'YYYYMMDDHH24MISS')||'-'||left(v_sha,8);
  insert into public.deployments(project_id,environment_id,workflow_id,factory_run_id,release_version,status,artifact_sha256,certificate,created_by)
  values(v_run.project_id,v_env.id,v_run.workflow_id,v_run.id,v_version,'planned',v_sha,
    jsonb_build_object('schema','vrs.release-certificate/3','factory_run_id',v_run.id,'artifact_sha256',v_sha,'builder_key',v_builder,'builder_version',coalesce(v_builder_version,1),'runner_qa','PASS','production_locked',true,'required_gates',v_required,'gate_policy_version',coalesce(v_policy_version,1),'gate_policy_sha256',v_effective_hash,'builder_profile_sha256',v_profile_hash,'app_spec_sha256',v_app_spec_hash,'source_commit_sha',coalesce(v_run.result#>>'{runner,commit_sha}',v_run.result#>>'{runner,github_sha}')),p_actor)
  on conflict(factory_run_id,environment_id) do nothing;

  select id into v_dep_id from public.deployments where factory_run_id=v_run.id and environment_id=v_env.id limit 1;
  if v_dep_id is null then raise exception 'release deployment could not be resolved idempotently'; end if;

  insert into public.approvals(project_id,workflow_id,factory_run_id,approval_type,status,requested_by,rationale)
  values(v_run.project_id,v_run.workflow_id,v_run.id,'production_release','pending',p_actor,'Autonomous staging build passed runner QA. Technical release gates must pass before explicit production approval.')
  on conflict(factory_run_id,approval_type) do nothing;

  select id into v_approval_id from public.approvals where factory_run_id=v_run.id and approval_type='production_release' limit 1;
  if v_approval_id is null then raise exception 'production approval could not be resolved idempotently'; end if;

  return jsonb_build_object('decision','release_candidate_prepared','factory_run_id',v_run.id,'deployment_id',v_dep_id,'approval_id',v_approval_id,'artifact_sha256',v_sha,'required_gates',v_required,'deployment_status','planned','human_approval','pending','production_locked',true);
end $function$;;
