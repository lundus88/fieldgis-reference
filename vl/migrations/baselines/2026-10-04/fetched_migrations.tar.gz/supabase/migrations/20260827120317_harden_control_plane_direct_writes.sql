revoke insert, update, delete, truncate, references, trigger on table public.approvals from anon, authenticated;
revoke insert, update, delete, truncate, references, trigger on table public.release_gates from anon, authenticated;
revoke insert, update, delete, truncate, references, trigger on table public.deployments from anon, authenticated;

revoke execute on function private.auto_prepare_release_candidate() from public, anon, authenticated;
revoke execute on function private.enforce_deployment_snapshot_immutability() from public, anon, authenticated;
revoke execute on function private.enqueue_production_promotion_job() from public, anon, authenticated;
revoke execute on function private.enqueue_release_validation_job() from public, anon, authenticated;
revoke execute on function private.set_spec_compilation_capability_plan() from public, anon, authenticated;
revoke execute on function private.request_production_rollback(uuid,text) from public, anon, authenticated;
;
