begin;

create table public.factory_runs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  app_spec_id uuid references public.app_specs(id) on delete set null,
  workflow_id uuid references public.workflows(id) on delete set null,
  requested_by uuid not null references auth.users(id) on delete restrict,
  run_type text not null check (run_type in ('build','repair','upgrade','validate','certify')),
  state text not null default 'queued' check (state in ('queued','planning','building','validating','awaiting_approval','certified','failed','cancelled')),
  target_environment text not null default 'staging' check (target_environment in ('development','staging','production')),
  production_locked boolean not null default true,
  input jsonb not null default '{}'::jsonb,
  plan jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  error_text text,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz
);

create index factory_runs_project_state_idx on public.factory_runs(project_id,state);
create index factory_runs_workflow_idx on public.factory_runs(workflow_id);
create index factory_runs_requested_by_idx on public.factory_runs(requested_by);

create table public.module_registry (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  module_key text not null,
  module_type text not null check (module_type in ('auth','database','storage','edge_function','frontend','integration','billing','reporting','ai','other')),
  version text not null default '0.1.0',
  status text not null default 'planned' check (status in ('planned','generated','validated','active','deprecated','failed')),
  config jsonb not null default '{}'::jsonb,
  artifact_sha256 text,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(project_id,module_key)
);
create index module_registry_project_status_idx on public.module_registry(project_id,status);
create index module_registry_created_by_idx on public.module_registry(created_by);

create table public.factory_artifacts (
  id uuid primary key default gen_random_uuid(),
  factory_run_id uuid not null references public.factory_runs(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  artifact_type text not null check (artifact_type in ('source','migration','edge_function','test_report','release_certificate','bundle','other')),
  name text not null,
  storage_path text,
  sha256 text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(factory_run_id,name)
);
create index factory_artifacts_project_idx on public.factory_artifacts(project_id);

create table public.release_gates (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  factory_run_id uuid references public.factory_runs(id) on delete cascade,
  gate_key text not null,
  gate_type text not null check (gate_type in ('security','rls','auth','data_api','storage','rollback','qa','human_approval','production_lock')),
  status text not null default 'pending' check (status in ('pending','pass','fail','blocked','waived')),
  score numeric(5,2),
  evidence jsonb not null default '{}'::jsonb,
  checked_at timestamptz,
  checked_by uuid references auth.users(id) on delete set null,
  unique(factory_run_id,gate_key)
);
create index release_gates_project_status_idx on public.release_gates(project_id,status);
create index release_gates_checked_by_idx on public.release_gates(checked_by);

alter table public.factory_runs enable row level security;
alter table public.module_registry enable row level security;
alter table public.factory_artifacts enable row level security;
alter table public.release_gates enable row level security;

grant select,insert,update,delete on public.factory_runs to authenticated;
grant select,insert,update,delete on public.module_registry to authenticated;
grant select,insert,update,delete on public.factory_artifacts to authenticated;
grant select,insert,update,delete on public.release_gates to authenticated;

create policy factory_runs_select_member on public.factory_runs for select to authenticated using (private.is_project_member(project_id));
create policy factory_runs_insert_builder on public.factory_runs for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']) and requested_by=(select auth.uid()) and (target_environment <> 'production' or production_locked=true));
create policy factory_runs_update_builder on public.factory_runs for update to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']) and (target_environment <> 'production' or production_locked=true));
create policy factory_runs_delete_admin on public.factory_runs for delete to authenticated using (private.has_project_role(project_id,array['owner','admin']));

create policy module_registry_select_member on public.module_registry for select to authenticated using (private.is_project_member(project_id));
create policy module_registry_insert_builder on public.module_registry for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']) and created_by=(select auth.uid()));
create policy module_registry_update_builder on public.module_registry for update to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']));
create policy module_registry_delete_admin on public.module_registry for delete to authenticated using (private.has_project_role(project_id,array['owner','admin']));

create policy factory_artifacts_select_member on public.factory_artifacts for select to authenticated using (private.is_project_member(project_id));
create policy factory_artifacts_insert_builder on public.factory_artifacts for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']));
create policy factory_artifacts_update_builder on public.factory_artifacts for update to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']));
create policy factory_artifacts_delete_admin on public.factory_artifacts for delete to authenticated using (private.has_project_role(project_id,array['owner','admin']));

create policy release_gates_select_member on public.release_gates for select to authenticated using (private.is_project_member(project_id));
create policy release_gates_insert_builder on public.release_gates for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder','reviewer']));
create policy release_gates_update_reviewer on public.release_gates for update to authenticated using (private.has_project_role(project_id,array['owner','admin','reviewer'])) with check (private.has_project_role(project_id,array['owner','admin','reviewer']));
create policy release_gates_delete_admin on public.release_gates for delete to authenticated using (private.has_project_role(project_id,array['owner','admin']));

comment on table public.factory_runs is 'VRS SaaS Factory execution state machine. Production remains locked until all required gates pass and human approval exists.';
comment on table public.module_registry is 'Generated/managed modules for each VRS-built SaaS project.';
comment on table public.factory_artifacts is 'Immutable references and hashes for generated build artifacts.';
comment on table public.release_gates is 'Evidence-backed release gates used by VRS certification.';

commit;;
