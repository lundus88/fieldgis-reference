alter table public.deployments add column if not exists factory_run_id uuid;
alter table public.approvals add column if not exists factory_run_id uuid;

update public.deployments d
set factory_run_id = fr.id
from public.factory_runs fr
where d.factory_run_id is null
  and fr.project_id=d.project_id
  and fr.workflow_id=d.workflow_id
  and not exists (
    select 1 from public.factory_runs fr2
    where fr2.project_id=d.project_id and fr2.workflow_id=d.workflow_id and fr2.id<>fr.id
  );

update public.approvals a
set factory_run_id = fr.id
from public.factory_runs fr
where a.factory_run_id is null
  and fr.project_id=a.project_id
  and fr.workflow_id=a.workflow_id
  and not exists (
    select 1 from public.factory_runs fr2
    where fr2.project_id=a.project_id and fr2.workflow_id=a.workflow_id and fr2.id<>fr.id
  );

alter table public.deployments
  drop constraint if exists deployments_factory_run_id_fkey,
  add constraint deployments_factory_run_id_fkey foreign key (factory_run_id) references public.factory_runs(id);

alter table public.approvals
  drop constraint if exists approvals_factory_run_id_fkey,
  add constraint approvals_factory_run_id_fkey foreign key (factory_run_id) references public.factory_runs(id);

create index if not exists deployments_factory_run_id_idx on public.deployments(factory_run_id);
create index if not exists approvals_factory_run_id_idx on public.approvals(factory_run_id);

alter table public.deployments alter column factory_run_id set not null;
alter table public.approvals alter column factory_run_id set not null;

create or replace function private.enqueue_release_validation_job()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare v_run public.factory_runs%rowtype; v_builder text;
begin
 if new.status='planned' and (tg_op='INSERT' or old.status is distinct from new.status) then
   select * into v_run from public.factory_runs where id=new.factory_run_id and project_id=new.project_id;
   if not found then raise exception 'deployment factory_run_id is invalid for project'; end if;
   if new.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow_id does not match factory run'; end if;
   v_builder:=coalesce(v_run.result#>>'{runner,builder_key}',private.resolve_factory_builder(v_run.id));
   if v_builder is not null then
     insert into private.release_validation_jobs(deployment_id,factory_run_id,project_id,builder_key)
     values(new.id,v_run.id,new.project_id,v_builder)
     on conflict(deployment_id) do nothing;
   end if;
 end if;
 return new;
end $function$;

create or replace function private.enqueue_production_promotion_job()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare v_run public.factory_runs%rowtype; v_builder text; v_adapter text; v_configured boolean;
begin
 if new.status='approved' and (tg_op='INSERT' or old.status is distinct from new.status) then
   select * into v_run from public.factory_runs where id=new.factory_run_id and project_id=new.project_id;
   if not found then raise exception 'deployment factory_run_id is invalid for project'; end if;
   if new.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow_id does not match factory run'; end if;
   v_builder:=coalesce(v_run.result#>>'{runner,builder_key}',private.resolve_factory_builder(v_run.id));
   select adapter_key,configured into v_adapter,v_configured from private.production_adapter_registry where builder_key=v_builder;
   insert into private.production_promotion_jobs(deployment_id,project_id,factory_run_id,builder_key,artifact_sha256,target_adapter,state,error_text)
   values(new.id,new.project_id,v_run.id,v_builder,new.artifact_sha256,v_adapter,
     case when v_configured then 'queued' else 'blocked' end,
     case when v_configured then null else 'BLOCKED/UNCONFIGURED: production adapter target or credentials unavailable' end)
   on conflict(deployment_id) do nothing;
 end if;
 return new;
end $function$;

create or replace function private.approve_production_release(p_deployment_id uuid, p_rationale text default null)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_uid uuid:=auth.uid();
  v_dep public.deployments%rowtype;
  v_run public.factory_runs%rowtype;
  v_required jsonb;
  v_missing int;
  v_approval_id uuid;
begin
  if v_uid is null then raise exception 'authenticated user required'; end if;
  select * into v_dep from public.deployments where id=p_deployment_id for update;
  if not found then raise exception 'deployment not found'; end if;
  if not private.has_project_role(v_dep.project_id,array['owner','admin']) then raise exception 'owner/admin production approval required'; end if;
  if v_dep.status<>'certified' then raise exception 'deployment must be technically certified before approval'; end if;
  select * into v_run from public.factory_runs where id=v_dep.factory_run_id and project_id=v_dep.project_id for update;
  if not found then raise exception 'factory run not found'; end if;
  if v_dep.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow mismatch'; end if;
  v_required:=private.get_required_release_gates(v_run.id);
  select count(*) into v_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass');
  if v_missing>0 then raise exception 'technical release gates not all PASS'; end if;

  select id into v_approval_id from public.approvals where factory_run_id=v_run.id and project_id=v_dep.project_id and workflow_id=v_dep.workflow_id and approval_type='production_release' and status='pending' order by requested_at desc limit 1 for update;
  if v_approval_id is null then raise exception 'pending production approval record required'; end if;
  update public.approvals set status='approved',decided_by=v_uid,decided_at=now(),rationale=coalesce(nullif(p_rationale,''),rationale,'Explicit owner/admin production approval') where id=v_approval_id;
  update public.release_gates set status='pass',score=1,evidence=jsonb_build_object('approval_id',v_approval_id,'approved_by',v_uid,'approved_at',now(),'explicit_human_approval',true),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key='human_production_approval';
  update public.release_gates set status='pass',score=1,evidence=jsonb_build_object('release_unlock','approved','approved_by',v_uid,'approved_at',now(),'factory_run_remains_immutable',true),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key='production_lock';
  update public.deployments set status='approved',approved_by=v_uid,certificate=certificate||jsonb_build_object('human_approval','PASS','approved_by',v_uid,'approved_at',now(),'production_release_authorized',true) where id=v_dep.id;
  return jsonb_build_object('decision','production_release_approved','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval_id,'approved_by',v_uid,'artifact_sha256',v_dep.artifact_sha256,'next_state','approved');
end $function$;

create or replace function private.reject_production_release(p_deployment_id uuid, p_rationale text default null)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare v_uid uuid:=auth.uid(); v_dep public.deployments%rowtype; v_run public.factory_runs%rowtype; v_approval_id uuid;
begin
 if v_uid is null then raise exception 'authenticated user required'; end if;
 select * into v_dep from public.deployments where id=p_deployment_id for update;
 if not found then raise exception 'deployment not found'; end if;
 if not private.has_project_role(v_dep.project_id,array['owner','admin']) then raise exception 'owner/admin production decision required'; end if;
 if v_dep.status not in ('planned','certified') then raise exception 'deployment is not awaiting production decision'; end if;
 select * into v_run from public.factory_runs where id=v_dep.factory_run_id and project_id=v_dep.project_id;
 if not found then raise exception 'factory run not found'; end if;
 if v_dep.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow mismatch'; end if;
 select id into v_approval_id from public.approvals where factory_run_id=v_run.id and project_id=v_dep.project_id and workflow_id=v_dep.workflow_id and approval_type='production_release' and status='pending' order by requested_at desc limit 1 for update;
 if v_approval_id is not null then update public.approvals set status='rejected',decided_by=v_uid,decided_at=now(),rationale=coalesce(nullif(p_rationale,''),'Production release rejected') where id=v_approval_id; end if;
 update public.release_gates set status='blocked',score=0,evidence=jsonb_build_object('rejected_by',v_uid,'rejected_at',now(),'rationale',coalesce(p_rationale,'Production release rejected')),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key in ('human_production_approval','production_lock');
 update public.deployments set status='failed',approved_by=null,certificate=certificate||jsonb_build_object('human_approval','REJECTED','rejected_by',v_uid,'rejected_at',now(),'rationale',coalesce(p_rationale,'Production release rejected')) where id=v_dep.id;
 return jsonb_build_object('decision','production_release_rejected','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval_id);
end $function$;

create or replace function private.enforce_production_deployment_guard()
returns trigger
language plpgsql
security definer
set search_path to 'public','private','pg_temp'
as $function$
declare
  v_env_kind text;
  v_run public.factory_runs%rowtype;
  v_required jsonb;
  v_technical_missing int;
  v_human_ok boolean;
  v_unlock_ok boolean;
  v_approval_ok boolean;
  v_cert_hash text;
begin
  select kind into v_env_kind from public.environments where id=new.environment_id and project_id=new.project_id;
  if v_env_kind is distinct from 'production' then return new; end if;
  if new.status not in ('certified','approved','deploying','deployed') then return new; end if;
  if new.workflow_id is null then raise exception 'production deployment requires workflow_id'; end if;
  if new.factory_run_id is null then raise exception 'production deployment requires factory_run_id'; end if;

  select * into v_run from public.factory_runs where id=new.factory_run_id and project_id=new.project_id;
  if not found then raise exception 'production deployment requires a valid factory run'; end if;
  if new.workflow_id is distinct from v_run.workflow_id then raise exception 'production deployment workflow does not match factory run'; end if;

  v_required := private.get_required_release_gates(v_run.id);
  select count(*) into v_technical_missing
  from jsonb_array_elements(v_required) g
  where not exists (
    select 1 from public.release_gates rg
    where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass'
  );
  if v_technical_missing > 0 then raise exception 'production certification blocked: required builder release gates not all PASS'; end if;

  if new.artifact_sha256 is null or new.artifact_sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'production deployment requires valid SHA-256 artifact hash'; end if;
  v_cert_hash := coalesce(new.certificate->>'artifact_sha256',new.certificate->>'sha256');
  if v_cert_hash is null or lower(v_cert_hash)<>lower(new.artifact_sha256) then raise exception 'production certificate hash does not match artifact SHA-256'; end if;

  if new.status in ('approved','deploying','deployed') then
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='human_production_approval' and rg.status='pass') into v_human_ok;
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='production_lock' and rg.status='pass') into v_unlock_ok;
    select exists(select 1 from public.approvals a where a.factory_run_id=v_run.id and a.project_id=new.project_id and a.workflow_id=new.workflow_id and a.approval_type='production_release' and a.status='approved' and a.decided_by is not null and a.decided_at is not null) into v_approval_ok;
    if not v_human_ok then raise exception 'production deployment blocked: human production approval gate not PASS'; end if;
    if not v_unlock_ok then raise exception 'production deployment blocked: production lock not released'; end if;
    if not v_approval_ok then raise exception 'production deployment blocked: approved human approval record required'; end if;
    if new.approved_by is null then raise exception 'production deployment blocked: approved_by required'; end if;
  end if;
  if new.status='deployed' and new.deployed_at is null then new.deployed_at:=now(); end if;
  return new;
end $function$;;
