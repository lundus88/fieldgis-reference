begin;

create or replace function private.enforce_approved_app_spec_for_factory_run()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_status text;
begin
  if new.run_type = 'build' and new.app_spec_id is not null then
    select a.status into v_status
    from public.app_specs a
    where a.id = new.app_spec_id;

    if v_status is distinct from 'approved' then
      raise exception 'VRS build requires an approved App Spec';
    end if;
  end if;
  return new;
end;
$$;

revoke all on function private.enforce_approved_app_spec_for_factory_run() from public;

drop trigger if exists trg_factory_runs_require_approved_spec on public.factory_runs;
create trigger trg_factory_runs_require_approved_spec
before insert or update of app_spec_id, run_type on public.factory_runs
for each row execute function private.enforce_approved_app_spec_for_factory_run();

commit;;
