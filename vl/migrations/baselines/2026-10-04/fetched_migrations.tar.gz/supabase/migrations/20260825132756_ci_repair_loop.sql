create table if not exists public.ci_repair_actions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  factory_run_id uuid references public.factory_runs(id) on delete cascade,
  builder_key text not null references public.builder_registry(builder_key),
  failure_event_id uuid references public.build_failure_events(id) on delete set null,
  recipe_key text not null references public.repair_recipe_registry(recipe_key),
  provider text not null default 'github',
  repository text not null,
  branch text not null default 'main',
  risk_level text not null,
  auto_apply boolean not null default false,
  state text not null default 'proposed' check (state in ('proposed','approved','applying','applied','retrying','verified','failed','rejected')),
  repair_plan jsonb not null default '{}'::jsonb,
  execution_result jsonb not null default '{}'::jsonb,
  retry_run_id text,
  created_by uuid not null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  applied_at timestamptz,
  verified_at timestamptz
);

alter table public.ci_repair_actions enable row level security;

create policy ci_repair_actions_select_project on public.ci_repair_actions
for select to authenticated
using (exists (select 1 from public.project_members pm where pm.project_id=ci_repair_actions.project_id and pm.user_id=(select auth.uid())));

create policy ci_repair_actions_insert_project on public.ci_repair_actions
for insert to authenticated
with check (exists (select 1 from public.project_members pm where pm.project_id=ci_repair_actions.project_id and pm.user_id=(select auth.uid())));

create policy ci_repair_actions_update_project on public.ci_repair_actions
for update to authenticated
using (exists (select 1 from public.project_members pm where pm.project_id=ci_repair_actions.project_id and pm.user_id=(select auth.uid())))
with check (exists (select 1 from public.project_members pm where pm.project_id=ci_repair_actions.project_id and pm.user_id=(select auth.uid())));

create index if not exists ci_repair_actions_factory_run_idx on public.ci_repair_actions(factory_run_id,created_at desc);
create index if not exists ci_repair_actions_state_idx on public.ci_repair_actions(state,created_at desc);

create or replace function public.propose_ci_repair(
  p_project_id uuid,
  p_factory_run_id uuid,
  p_builder_key text,
  p_repository text,
  p_branch text,
  p_failure_class text,
  p_signature text,
  p_error_text text
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  r public.repair_recipe_registry%rowtype;
  a public.ci_repair_actions%rowtype;
begin
  if not exists (select 1 from public.project_members where project_id=p_project_id and user_id=auth.uid()) then
    raise exception 'forbidden';
  end if;

  select * into r
  from public.repair_recipe_registry
  where status='active'
    and failure_class=p_failure_class
    and (builder_key is null or builder_key=p_builder_key)
    and (p_signature ilike '%'||signature_pattern||'%' or p_error_text ilike '%'||signature_pattern||'%')
  order by case when builder_key=p_builder_key then 0 else 1 end, auto_apply desc, updated_at desc
  limit 1;

  if not found then
    return jsonb_build_object('matched',false,'reason','no_recipe');
  end if;

  insert into public.ci_repair_actions(project_id,factory_run_id,builder_key,recipe_key,repository,branch,risk_level,auto_apply,state,repair_plan)
  values(
    p_project_id,p_factory_run_id,p_builder_key,r.recipe_key,p_repository,coalesce(nullif(p_branch,''),'main'),r.risk_level,
    (r.auto_apply and r.risk_level='low'),
    case when r.auto_apply and r.risk_level='low' then 'approved' else 'proposed' end,
    jsonb_build_object(
      'action_type',r.action_type,
      'action_spec',r.action_spec,
      'failure_class',p_failure_class,
      'signature',left(p_signature,500),
      'error_excerpt',left(p_error_text,2000),
      'production_locked',true
    )
  ) returning * into a;

  return jsonb_build_object(
    'matched',true,
    'repair_action_id',a.id,
    'recipe_key',a.recipe_key,
    'risk_level',a.risk_level,
    'auto_apply',a.auto_apply,
    'state',a.state,
    'repair_plan',a.repair_plan
  );
end;
$$;

grant execute on function public.propose_ci_repair(uuid,uuid,text,text,text,text,text,text) to authenticated;

create or replace function public.mark_ci_repair_applied(
  p_action_id uuid,
  p_execution_result jsonb
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare a public.ci_repair_actions%rowtype;
begin
  select * into a from public.ci_repair_actions where id=p_action_id;
  if not found then raise exception 'repair action not found'; end if;
  if not exists (select 1 from public.project_members where project_id=a.project_id and user_id=auth.uid()) then raise exception 'forbidden'; end if;
  if a.risk_level <> 'low' and a.state <> 'approved' then raise exception 'human approval required'; end if;
  update public.ci_repair_actions
    set state='applied', execution_result=coalesce(p_execution_result,'{}'::jsonb), applied_at=now(), updated_at=now()
  where id=p_action_id;
  return jsonb_build_object('ok',true,'repair_action_id',p_action_id,'state','applied');
end;
$$;

grant execute on function public.mark_ci_repair_applied(uuid,jsonb) to authenticated;

create or replace function public.mark_ci_repair_retry(
  p_action_id uuid,
  p_retry_run_id text
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare a public.ci_repair_actions%rowtype;
begin
  select * into a from public.ci_repair_actions where id=p_action_id;
  if not found then raise exception 'repair action not found'; end if;
  if not exists (select 1 from public.project_members where project_id=a.project_id and user_id=auth.uid()) then raise exception 'forbidden'; end if;
  update public.ci_repair_actions set state='retrying',retry_run_id=p_retry_run_id,updated_at=now() where id=p_action_id;
  return jsonb_build_object('ok',true,'repair_action_id',p_action_id,'state','retrying','retry_run_id',p_retry_run_id);
end;
$$;

grant execute on function public.mark_ci_repair_retry(uuid,text) to authenticated;

create or replace function public.verify_ci_repair(
  p_action_id uuid,
  p_success boolean,
  p_details jsonb default '{}'::jsonb
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare a public.ci_repair_actions%rowtype;
begin
  select * into a from public.ci_repair_actions where id=p_action_id;
  if not found then raise exception 'repair action not found'; end if;
  if not exists (select 1 from public.project_members where project_id=a.project_id and user_id=auth.uid()) then raise exception 'forbidden'; end if;
  update public.ci_repair_actions
    set state=case when p_success then 'verified' else 'failed' end,
        execution_result=coalesce(execution_result,'{}'::jsonb)||jsonb_build_object('verification',coalesce(p_details,'{}'::jsonb)),
        verified_at=case when p_success then now() else verified_at end,
        updated_at=now()
    where id=p_action_id;
  return jsonb_build_object('ok',true,'repair_action_id',p_action_id,'state',case when p_success then 'verified' else 'failed' end);
end;
$$;

grant execute on function public.verify_ci_repair(uuid,boolean,jsonb) to authenticated;;
