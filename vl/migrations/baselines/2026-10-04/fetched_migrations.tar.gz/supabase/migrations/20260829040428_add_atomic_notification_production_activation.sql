create or replace function private.activate_approved_notification_production()
returns jsonb
language plpgsql
security definer
set search_path = private, public, pg_temp
as $$
declare
  v_act private.notification_production_activations%rowtype;
  v_reg private.capability_adapter_registry%rowtype;
begin
  if current_user <> 'service_role' then
    raise exception 'service_role required';
  end if;

  select * into v_act
  from private.notification_production_activations
  where adapter_key='resend-email-v1' and status='approved'
  order by approved_at desc
  limit 1
  for update;

  if not found then
    raise exception 'approved production activation not found';
  end if;

  select * into v_reg
  from private.capability_adapter_registry
  where adapter_key='resend-email-v1'
  for update;

  if not found then
    raise exception 'resend adapter not found';
  end if;

  if coalesce(v_reg.configuration->>'sandbox_e2e_verified_at','')='' or
     coalesce(v_reg.configuration->>'sandbox_reconciliation_verified_at','')='' then
    raise exception 'sandbox evidence incomplete';
  end if;

  if v_reg.status='active' and
     coalesce((v_reg.capabilities->>'production_send_allowed')::boolean,false) and
     coalesce((v_reg.configuration->>'production_send_allowed')::boolean,false) then
    return jsonb_build_object('ok',true,'idempotent',true,'adapter_key',v_reg.adapter_key,'status',v_reg.status);
  end if;

  update private.capability_adapter_registry
  set status='active',
      capabilities=jsonb_set(capabilities,'{production_send_allowed}','true'::jsonb,true),
      configuration=jsonb_set(
        jsonb_set(configuration,'{production_send_allowed}','true'::jsonb,true),
        '{production_activation_approved_at}',to_jsonb(v_act.approved_at),true
      ) || jsonb_build_object('production_activation_approved_by',v_act.approved_by),
      updated_at=now()
  where adapter_key='resend-email-v1';

  update private.notification_production_activations
  set status='activated',
      evidence=coalesce(evidence,'{}'::jsonb) || jsonb_build_object('activated_at',now(),'activated_by','service_role_after_human_approval')
  where id=v_act.id;

  return jsonb_build_object('ok',true,'idempotent',false,'adapter_key','resend-email-v1','status','active','activation_id',v_act.id);
end
$$;
revoke all on function private.activate_approved_notification_production() from public, anon, authenticated;
grant execute on function private.activate_approved_notification_production() to service_role;;
