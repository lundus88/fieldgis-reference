create or replace function private.sync_successful_rollback_rehearsal_gate()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  d public.deployments%rowtype;
  prev public.deployments%rowtype;
begin
  if new.state <> 'succeeded' then return new; end if;
  if coalesce(new.result->>'post_rollback_verification','') <> 'PASS' then return new; end if;
  if coalesce(new.result->>'immutable_no_rebuild','false') <> 'true' then return new; end if;
  if nullif(new.artifact_sha256,'') is null then return new; end if;

  select * into d from public.deployments where id=new.deployment_id;
  select * into prev from public.deployments where id=new.previous_deployment_id;
  if not found then return new; end if;
  if d.factory_run_id is null then return new; end if;
  if lower(coalesce(prev.artifact_sha256,'')) <> lower(new.artifact_sha256) then return new; end if;

  update public.release_gates
     set status='pass',
         score=1.00,
         checked_at=coalesce(new.finished_at,now()),
         evidence=jsonb_build_object(
           'source','production_rollback_audit',
           'rollback_audit_id',new.id,
           'restored_deployment_id',new.previous_deployment_id,
           'artifact_sha256',new.artifact_sha256,
           'immutable_no_rebuild',true,
           'post_rollback_verification','PASS',
           'github_run_id',new.result->>'github_run_id',
           'verification_checks',coalesce(new.result->'verification_checks','[]'::jsonb)
         )
   where factory_run_id=d.factory_run_id
     and gate_key='rollback_rehearsal';
  return new;
end $$;

drop trigger if exists trg_sync_successful_rollback_rehearsal_gate on private.production_rollback_audits;
create trigger trg_sync_successful_rollback_rehearsal_gate
after update of state,result,finished_at on private.production_rollback_audits
for each row
when (new.state='succeeded')
execute function private.sync_successful_rollback_rehearsal_gate();

with eligible as (
  select r.id as rollback_audit_id,r.deployment_id,r.previous_deployment_id,r.artifact_sha256,r.finished_at,r.result,d.factory_run_id
  from private.production_rollback_audits r
  join public.deployments d on d.id=r.deployment_id
  join public.deployments p on p.id=r.previous_deployment_id
  where r.state='succeeded'
    and r.result->>'post_rollback_verification'='PASS'
    and r.result->>'immutable_no_rebuild'='true'
    and lower(coalesce(p.artifact_sha256,''))=lower(coalesce(r.artifact_sha256,''))
)
update public.release_gates g
set status='pass',score=1.00,checked_at=coalesce(e.finished_at,now()),
    evidence=jsonb_build_object('source','production_rollback_audit','rollback_audit_id',e.rollback_audit_id,'restored_deployment_id',e.previous_deployment_id,'artifact_sha256',e.artifact_sha256,'immutable_no_rebuild',true,'post_rollback_verification','PASS','github_run_id',e.result->>'github_run_id','verification_checks',coalesce(e.result->'verification_checks','[]'::jsonb))
from eligible e
where g.factory_run_id=e.factory_run_id and g.gate_key='rollback_rehearsal';;
