alter function public.guard_builder_activation() set search_path = public, pg_temp;;
