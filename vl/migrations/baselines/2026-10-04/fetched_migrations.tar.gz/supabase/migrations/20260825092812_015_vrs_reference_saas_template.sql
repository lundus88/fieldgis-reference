create table if not exists public.reference_saas_templates (
  template_key text primary key,
  name text not null,
  objective text not null,
  spec jsonb not null default '{}'::jsonb,
  recommended_slug text not null,
  status text not null default 'active' check (status in ('active','deprecated')),
  created_at timestamptz not null default now()
);

alter table public.reference_saas_templates enable row level security;
grant select on public.reference_saas_templates to authenticated;

drop policy if exists reference_saas_templates_select_authenticated on public.reference_saas_templates;
create policy reference_saas_templates_select_authenticated
on public.reference_saas_templates for select to authenticated
using (status='active');

insert into public.reference_saas_templates(template_key,name,objective,recommended_slug,spec)
values (
  'contractor_quote_job_tracker',
  'QuoteFlow Reference',
  'Create, issue and track quotations and jobs for small contractors with client records, line items, attachments, dashboard status and printable reports.',
  'quoteflow-reference',
  jsonb_build_object(
    'audience', jsonb_build_array('small contractors','service businesses','project administrators'),
    'features', jsonb_build_array(
      'Client management',
      'Quotation creation',
      'Quotation line items',
      'Quotation status tracking',
      'Job tracking after acceptance',
      'Document and attachment upload',
      'Dashboard metrics',
      'Printable quotation and job reports'
    ),
    'entities', jsonb_build_array(
      jsonb_build_object('name','clients','fields',jsonb_build_array(
        jsonb_build_object('name','name','type','text','required',true),
        jsonb_build_object('name','email','type','text'),
        jsonb_build_object('name','phone','type','text'),
        jsonb_build_object('name','company','type','text')
      )),
      jsonb_build_object('name','quotations','fields',jsonb_build_array(
        jsonb_build_object('name','client_id','type','uuid','required',true),
        jsonb_build_object('name','quote_no','type','text','required',true),
        jsonb_build_object('name','status','type','text','required',true,'default','draft'),
        jsonb_build_object('name','valid_until','type','date'),
        jsonb_build_object('name','subtotal','type','numeric','default',0),
        jsonb_build_object('name','tax','type','numeric','default',0),
        jsonb_build_object('name','total','type','numeric','default',0)
      )),
      jsonb_build_object('name','quotation_items','fields',jsonb_build_array(
        jsonb_build_object('name','quotation_id','type','uuid','required',true),
        jsonb_build_object('name','description','type','text','required',true),
        jsonb_build_object('name','quantity','type','numeric','default',1),
        jsonb_build_object('name','unit_price','type','numeric','default',0),
        jsonb_build_object('name','amount','type','numeric','default',0)
      )),
      jsonb_build_object('name','jobs','fields',jsonb_build_array(
        jsonb_build_object('name','quotation_id','type','uuid'),
        jsonb_build_object('name','title','type','text','required',true),
        jsonb_build_object('name','status','type','text','required',true,'default','planned'),
        jsonb_build_object('name','start_date','type','date'),
        jsonb_build_object('name','end_date','type','date')
      )),
      jsonb_build_object('name','attachments','fields',jsonb_build_array(
        jsonb_build_object('name','entity_type','type','text','required',true),
        jsonb_build_object('name','entity_id','type','uuid','required',true),
        jsonb_build_object('name','file_name','type','text','required',true),
        jsonb_build_object('name','storage_path','type','text','required',true)
      ))
    ),
    'auth', true,
    'storage', true,
    'workflows', jsonb_build_array('quotation accepted -> create job'),
    'reporting', true,
    'billing', false,
    'ai', false,
    'integrations', jsonb_build_array(),
    'ui', jsonb_build_object('mobile_first',true,'dashboard',true),
    'constraints', jsonb_build_object('production_locked',true,'tenant_isolation_required',true),
    'non_goals', jsonb_build_array('Payment gateway in reference v1','Public marketplace')
  )
)
on conflict (template_key) do update set
  name=excluded.name,
  objective=excluded.objective,
  recommended_slug=excluded.recommended_slug,
  spec=excluded.spec,
  status='active';

create or replace function public.bootstrap_reference_saas(p_template_key text default 'contractor_quote_job_tracker')
returns table(organization_id uuid, project_id uuid, app_spec_id uuid)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_template public.reference_saas_templates%rowtype;
  v_org uuid;
  v_project uuid;
  v_spec uuid;
  v_suffix text;
begin
  if v_user is null then raise exception 'authenticated user required'; end if;
  select * into v_template from public.reference_saas_templates where template_key=p_template_key and status='active';
  if not found then raise exception 'active template not found'; end if;
  v_suffix := substr(replace(v_user::text,'-',''),1,8);

  insert into public.organizations(name,slug,created_by)
  values ('VRS Reference Workspace','vrs-reference-'||v_suffix,v_user)
  on conflict (slug) do update set name=excluded.name
  returning id into v_org;

  insert into public.organization_members(organization_id,user_id,role)
  values (v_org,v_user,'owner')
  on conflict (organization_id,user_id) do update set role='owner';

  insert into public.projects(organization_id,name,slug,description,status,created_by)
  values (v_org,v_template.name,v_template.recommended_slug||'-'||v_suffix,v_template.objective,'active',v_user)
  on conflict (organization_id,slug) do update set description=excluded.description
  returning id into v_project;

  insert into public.project_members(project_id,user_id,role)
  values (v_project,v_user,'owner')
  on conflict (project_id,user_id) do update set role='owner';

  insert into public.app_specs(project_id,version,title,objective,spec,status,created_by,approved_by,approved_at)
  values (v_project,1,v_template.name,v_template.objective,v_template.spec,'approved',v_user,v_user,now())
  on conflict (project_id,version) do update set title=excluded.title,objective=excluded.objective,spec=excluded.spec,status='approved',approved_by=v_user,approved_at=now()
  returning id into v_spec;

  insert into public.environments(project_id,name,kind,status)
  values
    (v_project,'Development','development','ready'),
    (v_project,'Staging','staging','ready'),
    (v_project,'Production','production','paused')
  on conflict (project_id,kind) do nothing;

  return query select v_org,v_project,v_spec;
end;
$$;

grant execute on function public.bootstrap_reference_saas(text) to authenticated;;
