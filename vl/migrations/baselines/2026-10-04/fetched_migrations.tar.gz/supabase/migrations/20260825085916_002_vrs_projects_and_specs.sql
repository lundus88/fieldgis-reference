create table public.projects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  slug text not null,
  description text,
  status text not null default 'active' check (status in ('draft','active','paused','archived')),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, slug)
);

create table public.project_members (
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','builder','reviewer','viewer')),
  created_at timestamptz not null default now(),
  primary key (project_id,user_id)
);

create table public.app_specs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  version integer not null default 1,
  title text not null,
  objective text,
  spec jsonb not null default '{}'::jsonb,
  status text not null default 'draft' check (status in ('draft','approved','superseded','rejected')),
  created_by uuid not null references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  unique (project_id, version)
);

create index projects_org_idx on public.projects(organization_id, status);
create index project_members_user_idx on public.project_members(user_id, project_id);
create index app_specs_project_idx on public.app_specs(project_id, version desc);

create or replace function private.is_project_member(p_project uuid, p_user uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public, private as $$
  select p_user is not null and exists (
    select 1 from public.project_members pm where pm.project_id = p_project and pm.user_id = p_user
  );
$$;

create or replace function private.has_project_role(p_project uuid, p_roles text[], p_user uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public, private as $$
  select p_user is not null and exists (
    select 1 from public.project_members pm where pm.project_id = p_project and pm.user_id = p_user and pm.role = any(p_roles)
  );
$$;

revoke all on function private.is_project_member(uuid,uuid) from public;
revoke all on function private.has_project_role(uuid,text[],uuid) from public;
grant execute on function private.is_project_member(uuid,uuid) to authenticated;
grant execute on function private.has_project_role(uuid,text[],uuid) to authenticated;

alter table public.projects enable row level security;
alter table public.project_members enable row level security;
alter table public.app_specs enable row level security;

create policy projects_select_member on public.projects for select to authenticated using (private.is_org_member(organization_id));
create policy projects_insert_builder on public.projects for insert to authenticated with check (private.has_org_role(organization_id,array['owner','admin','builder']) and created_by=(select auth.uid()));
create policy projects_update_admin on public.projects for update to authenticated using (private.has_org_role(organization_id,array['owner','admin'])) with check (private.has_org_role(organization_id,array['owner','admin']));

create policy project_members_select_member on public.project_members for select to authenticated using (private.is_project_member(project_id));
create policy project_members_insert_admin on public.project_members for insert to authenticated with check (
  private.has_project_role(project_id,array['owner','admin'])
  or (
    user_id=(select auth.uid()) and role='owner' and exists (
      select 1 from public.projects p where p.id=project_id and p.created_by=(select auth.uid())
    )
  )
);
create policy project_members_update_admin on public.project_members for update to authenticated using (private.has_project_role(project_id,array['owner','admin'])) with check (private.has_project_role(project_id,array['owner','admin']));
create policy project_members_delete_admin on public.project_members for delete to authenticated using (private.has_project_role(project_id,array['owner','admin']));

create policy app_specs_select_member on public.app_specs for select to authenticated using (private.is_project_member(project_id));
create policy app_specs_insert_builder on public.app_specs for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']) and created_by=(select auth.uid()));
create policy app_specs_update_builder on public.app_specs for update to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']));

grant select, insert, update on public.projects to authenticated;
grant select, insert, update, delete on public.project_members to authenticated;
grant select, insert, update on public.app_specs to authenticated;;
