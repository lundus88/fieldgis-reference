begin;

create table if not exists public.spec_compilations (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  app_spec_id uuid not null references public.app_specs(id) on delete cascade,
  compiler_version text not null default '1.0.0',
  status text not null default 'pending' check (status in ('pending','valid','invalid','superseded')),
  normalized_spec jsonb not null default '{}'::jsonb,
  validation_errors jsonb not null default '[]'::jsonb,
  module_plan jsonb not null default '[]'::jsonb,
  build_plan jsonb not null default '[]'::jsonb,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  unique(app_spec_id, compiler_version)
);

create index if not exists spec_compilations_project_idx on public.spec_compilations(project_id);
create index if not exists spec_compilations_app_spec_idx on public.spec_compilations(app_spec_id);
create index if not exists spec_compilations_created_by_idx on public.spec_compilations(created_by);

create table if not exists public.build_steps (
  id uuid primary key default gen_random_uuid(),
  factory_run_id uuid not null references public.factory_runs(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  step_order integer not null,
  step_key text not null,
  step_type text not null check (step_type in ('plan','generate','migrate','configure','test','validate','package','certify','approval')),
  state text not null default 'queued' check (state in ('queued','running','succeeded','failed','blocked','cancelled')),
  depends_on text[] not null default '{}',
  input jsonb not null default '{}'::jsonb,
  output jsonb not null default '{}'::jsonb,
  error_text text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  unique(factory_run_id, step_key),
  unique(factory_run_id, step_order)
);

create index if not exists build_steps_run_state_idx on public.build_steps(factory_run_id,state,step_order);
create index if not exists build_steps_project_idx on public.build_steps(project_id);

alter table public.spec_compilations enable row level security;
alter table public.build_steps enable row level security;

grant select, insert, update on public.spec_compilations to authenticated;
grant select, insert, update on public.build_steps to authenticated;

create policy "spec_compilations_select_member" on public.spec_compilations
for select to authenticated using (private.is_project_member(project_id));

create policy "spec_compilations_insert_builder" on public.spec_compilations
for insert to authenticated with check (
  private.has_project_role(project_id, array['owner','admin','builder'])
  and created_by = (select auth.uid())
);

create policy "spec_compilations_update_builder" on public.spec_compilations
for update to authenticated
using (private.has_project_role(project_id, array['owner','admin','builder']))
with check (private.has_project_role(project_id, array['owner','admin','builder']));

create policy "build_steps_select_member" on public.build_steps
for select to authenticated using (private.is_project_member(project_id));

create policy "build_steps_insert_builder" on public.build_steps
for insert to authenticated with check (private.has_project_role(project_id, array['owner','admin','builder']));

create policy "build_steps_update_builder" on public.build_steps
for update to authenticated
using (private.has_project_role(project_id, array['owner','admin','builder']))
with check (private.has_project_role(project_id, array['owner','admin','builder']));

comment on table public.spec_compilations is 'Deterministic normalization/validation output produced from an approved VRS App Spec.';
comment on table public.build_steps is 'Ordered dependency-aware execution steps for a VRS factory run.';

commit;;
