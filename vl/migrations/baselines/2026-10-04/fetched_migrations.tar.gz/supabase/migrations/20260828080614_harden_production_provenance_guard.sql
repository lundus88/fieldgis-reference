create or replace function private.enforce_production_deployment_guard()
returns trigger
language plpgsql
security definer
set search_path to 'public','private','extensions','pg_temp'
as $function$
declare
  v_env_kind text; v_run public.factory_runs%rowtype; v_required jsonb; v_technical_missing int; v_human_ok boolean; v_unlock_ok boolean; v_approval_ok boolean; v_cert_hash text;
begin
  select kind into v_env_kind from public.environments where id=new.environment_id and project_id=new.project_id;
  if v_env_kind is distinct from 'production' then return new; end if;
  if new.status not in ('certified','approved','deploying','deployed') then return new; end if;
  if new.workflow_id is null then raise exception 'production deployment requires workflow_id'; end if;
  if new.factory_run_id is null then raise exception 'production deployment requires factory_run_id'; end if;
  select * into v_run from public.factory_runs where id=new.factory_run_id and project_id=new.project_id;
  if not found then raise exception 'production deployment requires a valid factory run'; end if;
  if new.workflow_id is distinct from v_run.workflow_id then raise exception 'production deployment workflow does not match factory run'; end if;
  v_required:=coalesce(new.required_gates_snapshot,'[]'::jsonb);
  if jsonb_array_length(v_required)=0 then raise exception 'production deployment requires frozen gate policy'; end if;
  select count(*) into v_technical_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass');
  if v_technical_missing>0 then raise exception 'production certification blocked: frozen required gates not all PASS'; end if;
  if new.artifact_sha256 is null or new.artifact_sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'production deployment requires valid SHA-256 artifact hash'; end if;
  v_cert_hash:=coalesce(new.certificate->>'artifact_sha256',new.certificate->>'sha256');
  if v_cert_hash is null or lower(v_cert_hash)<>lower(new.artifact_sha256) then raise exception 'production certificate hash does not match artifact SHA-256'; end if;
  if new.gate_policy_sha256 is null or lower(new.gate_policy_sha256)<>lower(encode(extensions.digest(convert_to(new.required_gates_snapshot::text,'UTF8'),'sha256'),'hex')) then raise exception 'production gate policy snapshot hash mismatch'; end if;

  if new.status in ('approved','deploying','deployed') then
    if new.app_spec_sha256 is null or new.app_spec_sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'production approval blocked: valid app spec SHA-256 provenance required'; end if;
    if new.builder_profile_sha256_snapshot is null or new.builder_profile_sha256_snapshot !~ '^[0-9a-fA-F]{64}$' then raise exception 'production approval blocked: valid builder profile SHA-256 provenance required'; end if;
    if new.source_commit_sha is null or new.source_commit_sha !~ '^[0-9a-fA-F]{40,64}$' then raise exception 'production approval blocked: source commit SHA provenance required'; end if;
    if coalesce(new.certificate->>'app_spec_sha256','') <> new.app_spec_sha256 then raise exception 'production approval blocked: app spec provenance mismatch'; end if;
    if coalesce(new.certificate->>'builder_profile_sha256','') <> new.builder_profile_sha256_snapshot then raise exception 'production approval blocked: builder profile provenance mismatch'; end if;
    if lower(coalesce(new.certificate->>'source_commit_sha','')) <> lower(new.source_commit_sha) then raise exception 'production approval blocked: source commit provenance mismatch'; end if;

    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='human_production_approval' and rg.status='pass') into v_human_ok;
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='production_lock' and rg.status='pass') into v_unlock_ok;
    select exists(select 1 from public.approvals a where a.factory_run_id=v_run.id and a.project_id=new.project_id and a.workflow_id=new.workflow_id and a.approval_type='production_release' and a.status='approved' and a.decided_by is not null and a.decided_at is not null) into v_approval_ok;
    if not v_human_ok then raise exception 'production deployment blocked: human production approval gate not PASS'; end if;
    if not v_unlock_ok then raise exception 'production deployment blocked: production lock not released'; end if;
    if not v_approval_ok then raise exception 'production deployment blocked: approved human approval record required'; end if;
    if new.approved_by is null then raise exception 'production deployment blocked: approved_by required'; end if;
  end if;
  if new.status='deployed' and new.deployed_at is null then new.deployed_at:=now(); end if;
  return new;
end
$function$;;
