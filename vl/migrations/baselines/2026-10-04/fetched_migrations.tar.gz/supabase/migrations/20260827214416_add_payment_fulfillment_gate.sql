create table if not exists private.payment_fulfillment_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references private.payment_sandbox_orders(id),
  adapter_key text not null default 'billplz-payment-v1',
  action_key text not null unique,
  status text not null check (status in ('fulfilled','rejected')),
  reason text,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table private.payment_fulfillment_events enable row level security;

create or replace function private.fulfill_verified_sandbox_payment(p_order_id uuid, p_action_key text)
returns jsonb
language plpgsql
security definer
set search_path = private, pg_temp
as $$
declare
  o private.payment_sandbox_orders%rowtype;
  valid_evidence boolean := false;
  prior private.payment_fulfillment_events%rowtype;
begin
  if p_action_key is null or length(trim(p_action_key)) < 8 then
    raise exception 'invalid action key';
  end if;

  select * into o from private.payment_sandbox_orders where id=p_order_id for update;
  if not found then raise exception 'order not found'; end if;

  select * into prior from private.payment_fulfillment_events where action_key=p_action_key;
  if found then
    return jsonb_build_object('ok', prior.status='fulfilled', 'duplicate', true, 'status', prior.status, 'order_id', p_order_id);
  end if;

  if o.environment <> 'sandbox' or o.adapter_key <> 'billplz-payment-v1' then
    raise exception 'sandbox billplz order required';
  end if;
  if o.status <> 'paid' or o.paid_at is null then
    raise exception 'payment not verified';
  end if;
  if o.fulfillment_state = 'fulfilled' then
    return jsonb_build_object('ok', true, 'duplicate', true, 'status', 'fulfilled', 'order_id', p_order_id);
  end if;
  if o.fulfillment_state <> 'unfulfilled' then
    raise exception 'invalid fulfillment state';
  end if;

  select exists(
    select 1 from private.payment_webhook_events e
    where e.provider_bill_id=o.provider_bill_id
      and e.adapter_key='billplz-payment-v1'
      and e.signature_valid=true
      and e.normalized_status='paid'
      and e.amount_minor=o.amount_minor
      and e.applied=true
      and coalesce(e.error_text,'')=''
  ) into valid_evidence;
  if not valid_evidence then raise exception 'signed paid webhook evidence required'; end if;

  update private.payment_sandbox_orders
     set fulfillment_state='fulfilled', updated_at=now()
   where id=o.id and fulfillment_state='unfulfilled';
  if not found then raise exception 'fulfillment race blocked'; end if;

  insert into private.payment_fulfillment_events(order_id,adapter_key,action_key,status,evidence)
  values(o.id,o.adapter_key,p_action_key,'fulfilled',jsonb_build_object(
    'provider_bill_id',o.provider_bill_id,
    'amount_minor',o.amount_minor,
    'currency',o.currency,
    'payment_status',o.status,
    'signed_webhook_required',true,
    'environment','sandbox'
  ));

  return jsonb_build_object('ok',true,'duplicate',false,'status','fulfilled','order_id',o.id);
end;
$$;

revoke all on function private.fulfill_verified_sandbox_payment(uuid,text) from public, anon, authenticated;
revoke all on table private.payment_fulfillment_events from public, anon, authenticated;
;
