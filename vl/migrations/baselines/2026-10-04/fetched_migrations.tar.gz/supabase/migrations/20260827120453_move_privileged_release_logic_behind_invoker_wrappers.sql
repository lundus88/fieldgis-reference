create or replace function public.approve_vrs_production_release(p_deployment_id uuid,p_rationale text default null)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
begin
  return private.approve_production_release(p_deployment_id,p_rationale);
end
$$;

create or replace function public.reject_vrs_production_release(p_deployment_id uuid,p_rationale text default null)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
begin
  return private.reject_production_release(p_deployment_id,p_rationale);
end
$$;

create or replace function public.request_vrs_production_rollback(p_deployment_id uuid,p_reason text default null)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
begin
  return private.request_production_rollback(p_deployment_id,p_reason);
end
$$;

grant execute on function private.approve_production_release(uuid,text) to authenticated;
grant execute on function private.reject_production_release(uuid,text) to authenticated;
grant execute on function private.request_production_rollback(uuid,text) to authenticated;

revoke execute on function public.approve_vrs_production_release(uuid,text) from public, anon;
revoke execute on function public.reject_vrs_production_release(uuid,text) from public, anon;
revoke execute on function public.request_vrs_production_rollback(uuid,text) from public, anon;
grant execute on function public.approve_vrs_production_release(uuid,text) to authenticated;
grant execute on function public.reject_vrs_production_release(uuid,text) to authenticated;
grant execute on function public.request_vrs_production_rollback(uuid,text) to authenticated;;
