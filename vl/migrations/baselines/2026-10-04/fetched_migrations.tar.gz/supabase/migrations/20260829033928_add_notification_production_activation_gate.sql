create table if not exists private.notification_production_activations (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null unique,
  status text not null default 'pending' check (status in ('pending','approved','revoked')),
  requested_at timestamptz not null default now(),
  approved_at timestamptz,
  approved_by uuid,
  rationale text,
  evidence jsonb not null default '{}'::jsonb
);

revoke all on private.notification_production_activations from anon, authenticated;
grant select,insert,update on private.notification_production_activations to service_role;

insert into private.notification_production_activations(adapter_key,status,evidence)
values ('resend-email-v1','pending',jsonb_build_object('sandbox_gate','required','production_config','required'))
on conflict (adapter_key) do nothing;

create or replace function private.approve_notification_production_activation(p_rationale text default null)
returns jsonb
language plpgsql
security definer
set search_path=private,public,pg_temp
as $$
declare
  v_uid uuid:=auth.uid();
  v_reg private.capability_adapter_registry%rowtype;
  v_act private.notification_production_activations%rowtype;
  v_is_owner boolean:=false;
begin
  if v_uid is null then raise exception 'authenticated user required'; end if;
  select exists(select 1 from public.project_members pm where pm.user_id=v_uid and pm.role in ('owner','admin')) into v_is_owner;
  if not v_is_owner then raise exception 'owner/admin activation approval required'; end if;

  select * into v_reg from private.capability_adapter_registry where adapter_key='resend-email-v1' for update;
  if not found then raise exception 'resend-email-v1 adapter not found'; end if;
  if coalesce(v_reg.configuration->>'sandbox_e2e_verified_at','')='' then raise exception 'sandbox E2E evidence required'; end if;
  if coalesce(v_reg.configuration->>'sandbox_reconciliation_verified_at','')='' then raise exception 'sandbox reconciliation evidence required'; end if;

  select * into v_act from private.notification_production_activations where adapter_key='resend-email-v1' for update;
  if v_act.status='approved' then
    return jsonb_build_object('ok',true,'decision','already_approved','adapter_key','resend-email-v1','approved_by',v_act.approved_by,'approved_at',v_act.approved_at,'idempotent',true);
  end if;

  update private.notification_production_activations
  set status='approved',approved_at=now(),approved_by=v_uid,
      rationale=coalesce(nullif(p_rationale,''),'Explicit owner/admin approval for controlled production alert activation'),
      evidence=jsonb_build_object(
        'explicit_human_approval',true,
        'sandbox_e2e_verified_at',v_reg.configuration->>'sandbox_e2e_verified_at',
        'sandbox_reconciliation_verified_at',v_reg.configuration->>'sandbox_reconciliation_verified_at',
        'production_runtime_config_must_be_verified_by_dispatcher',true
      )
  where adapter_key='resend-email-v1';

  return jsonb_build_object('ok',true,'decision','notification_production_activation_approved','adapter_key','resend-email-v1','approved_by',v_uid,'approved_at',now(),'idempotent',false);
end$$;

create or replace function public.approve_vrs_notification_production_activation(p_rationale text default null)
returns jsonb
language sql
security invoker
set search_path=public,private,pg_temp
as $$ select private.approve_notification_production_activation(p_rationale); $$;

revoke all on function private.approve_notification_production_activation(text) from public,anon,authenticated;
grant execute on function private.approve_notification_production_activation(text) to authenticated;
revoke all on function public.approve_vrs_notification_production_activation(text) from public,anon;
grant execute on function public.approve_vrs_notification_production_activation(text) to authenticated;

create or replace function private.activate_notification_adapter_if_approved()
returns jsonb
language plpgsql
security definer
set search_path=private,public,pg_temp
as $$
declare v_act private.notification_production_activations%rowtype; v_reg private.capability_adapter_registry%rowtype;
begin
  if current_user not in ('service_role','postgres') then raise exception 'service role required'; end if;
  select * into v_act from private.notification_production_activations where adapter_key='resend-email-v1';
  if not found or v_act.status<>'approved' then raise exception 'explicit human production activation approval required'; end if;
  select * into v_reg from private.capability_adapter_registry where adapter_key='resend-email-v1' for update;
  if coalesce(v_reg.configuration->>'sandbox_e2e_verified_at','')='' or coalesce(v_reg.configuration->>'sandbox_reconciliation_verified_at','')='' then raise exception 'sandbox evidence incomplete'; end if;
  update private.capability_adapter_registry
  set status='active',
      capabilities=jsonb_set(capabilities,'{production_send_allowed}','true'::jsonb,true),
      configuration=jsonb_set(jsonb_set(configuration,'{production_send_allowed}','true'::jsonb,true),'{production_activation_approved_at}',to_jsonb(v_act.approved_at),true),
      updated_at=now()
  where adapter_key='resend-email-v1';
  return private.notification_production_readiness();
end$$;
revoke all on function private.activate_notification_adapter_if_approved() from public,anon,authenticated;
grant execute on function private.activate_notification_adapter_if_approved() to service_role;;
