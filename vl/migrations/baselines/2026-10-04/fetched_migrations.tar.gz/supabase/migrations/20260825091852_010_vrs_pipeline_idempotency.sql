begin;
create unique index if not exists module_registry_project_key_uq on public.module_registry(project_id,module_key);
create index if not exists factory_artifacts_run_idx on public.factory_artifacts(factory_run_id);
create index if not exists release_gates_run_idx on public.release_gates(factory_run_id);
commit;;
