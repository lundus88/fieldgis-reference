create or replace function private.auto_prepare_release_candidate()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
begin
  if new.state='validating'
     and new.target_environment='staging'
     and new.production_locked=true
     and coalesce(new.result->>'runner_status','')='PASS'
     and not exists (
       select 1 from public.deployments d
       where d.factory_run_id=new.id
         and d.project_id=new.project_id
     ) then
    begin
      perform private.ensure_release_candidate(new.id,new.requested_by);
    exception when others then
      insert into private.factory_execution_events(
        factory_run_id,project_id,event_type,from_state,to_state,payload
      ) values(
        new.id,new.project_id,'release_candidate_prepare_blocked',old.state,new.state,
        jsonb_build_object('error',sqlerrm,'phase','validating_after_runner_pass')
      );
    end;
  end if;
  return new;
end
$function$;

revoke all on function private.auto_prepare_release_candidate() from public, anon, authenticated;;
