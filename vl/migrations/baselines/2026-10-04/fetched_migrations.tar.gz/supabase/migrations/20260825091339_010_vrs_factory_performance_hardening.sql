create index if not exists factory_runs_app_spec_idx on public.factory_runs(app_spec_id);;
