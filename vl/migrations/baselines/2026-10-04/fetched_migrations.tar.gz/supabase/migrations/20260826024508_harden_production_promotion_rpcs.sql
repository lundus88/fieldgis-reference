alter function public.claim_vrs_production_promotion_job(jsonb) security definer;
alter function public.claim_vrs_production_promotion_job(jsonb) set search_path = private, public, pg_temp;
alter function public.complete_vrs_production_promotion_job(uuid,uuid,boolean,jsonb,text) security definer;
alter function public.complete_vrs_production_promotion_job(uuid,uuid,boolean,jsonb,text) set search_path = private, public, pg_temp;
revoke all on function public.claim_vrs_production_promotion_job(jsonb) from public, anon, authenticated;
revoke all on function public.complete_vrs_production_promotion_job(uuid,uuid,boolean,jsonb,text) from public, anon, authenticated;
grant execute on function public.claim_vrs_production_promotion_job(jsonb) to service_role;
grant execute on function public.complete_vrs_production_promotion_job(uuid,uuid,boolean,jsonb,text) to service_role;;
