create or replace function private.enforce_production_deployment_guard()
returns trigger
language plpgsql
security definer
set search_path = public, private, pg_temp
as $$
declare
  v_env_kind text;
  v_run_id uuid;
  v_technical_missing int;
  v_human_ok boolean;
  v_unlock_ok boolean;
  v_approval_ok boolean;
  v_cert_hash text;
begin
  select kind into v_env_kind from public.environments where id = new.environment_id and project_id = new.project_id;
  if v_env_kind is distinct from 'production' then return new; end if;

  if new.status not in ('certified','approved','deploying','deployed') then return new; end if;
  if new.workflow_id is null then raise exception 'production deployment requires workflow_id'; end if;

  select fr.id into v_run_id
  from public.factory_runs fr
  where fr.workflow_id = new.workflow_id and fr.project_id = new.project_id
  order by fr.created_at desc limit 1;
  if v_run_id is null then raise exception 'production deployment requires a factory run'; end if;

  select count(*) into v_technical_missing
  from public.release_gates rg
  where rg.factory_run_id = v_run_id
    and rg.gate_key in ('security_advisor','cross_tenant_rls','auth_http_e2e','data_api_http_e2e','storage_physical_e2e','rollback_rehearsal','qa_regression')
    and rg.status <> 'pass';
  if v_technical_missing > 0 then raise exception 'production certification blocked: technical release gates not all PASS'; end if;

  if (select count(*) from public.release_gates rg where rg.factory_run_id=v_run_id and rg.gate_key in ('security_advisor','cross_tenant_rls','auth_http_e2e','data_api_http_e2e','storage_physical_e2e','rollback_rehearsal','qa_regression')) < 7 then
    raise exception 'production certification blocked: required release gates missing';
  end if;

  if new.artifact_sha256 is null or new.artifact_sha256 !~ '^[0-9a-fA-F]{64}$' then
    raise exception 'production deployment requires valid SHA-256 artifact hash';
  end if;
  v_cert_hash := coalesce(new.certificate->>'artifact_sha256', new.certificate->>'sha256');
  if v_cert_hash is null or lower(v_cert_hash) <> lower(new.artifact_sha256) then
    raise exception 'production certificate hash does not match artifact SHA-256';
  end if;

  if new.status in ('approved','deploying','deployed') then
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run_id and rg.gate_key='human_production_approval' and rg.status='pass') into v_human_ok;
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run_id and rg.gate_key='production_lock' and rg.status='pass') into v_unlock_ok;
    select exists(select 1 from public.approvals a where a.project_id=new.project_id and a.workflow_id=new.workflow_id and a.status='approved' and a.decided_by is not null and a.decided_at is not null) into v_approval_ok;
    if not v_human_ok then raise exception 'production deployment blocked: human production approval gate not PASS'; end if;
    if not v_unlock_ok then raise exception 'production deployment blocked: production lock not released'; end if;
    if not v_approval_ok then raise exception 'production deployment blocked: approved human approval record required'; end if;
    if new.approved_by is null then raise exception 'production deployment blocked: approved_by required'; end if;
  end if;

  if new.status='deployed' and new.deployed_at is null then new.deployed_at := now(); end if;
  return new;
end;
$$;
revoke all on function private.enforce_production_deployment_guard() from public, anon, authenticated;
drop trigger if exists trg_enforce_production_deployment_guard on public.deployments;
create trigger trg_enforce_production_deployment_guard before insert or update on public.deployments for each row execute function private.enforce_production_deployment_guard();;
