create or replace function private.apply_resend_sandbox_webhook(p_event_key text, p_provider_message_id text, p_event_type text, p_status text, p_payload_sha256 text)
returns jsonb
language plpgsql
security definer
set search_path to 'private','pg_temp'
as $function$
declare
  v_existing private.notification_events%rowtype;
  v_current text;
  v_next text;
  v_rows int := 0;
  v_matched boolean := false;
  v_applied boolean := false;
begin
  if coalesce(trim(p_event_key),'')='' then raise exception 'event_key required'; end if;
  select * into v_existing from private.notification_events where event_key=p_event_key;
  if found then return jsonb_build_object('duplicate',true,'applied',false,'event_type',p_event_type); end if;

  if coalesce(p_provider_message_id,'')<>'' and p_status is not null then
    select status into v_current
      from private.notification_outbox
      where provider_message_id=p_provider_message_id
        and adapter_key='resend-email-v1'
        and environment='sandbox'
      for update;
    if found then
      v_matched := true;
      v_next := case
        when v_current in ('bounced','failed') then v_current
        when p_status in ('bounced','failed') then p_status
        when v_current='delivered' then 'delivered'
        when p_status='delivered' then 'delivered'
        when v_current='sent' then 'sent'
        when p_status='sent' then 'sent'
        else coalesce(p_status,v_current)
      end;
      if v_next is distinct from v_current then
        update private.notification_outbox set status=v_next,updated_at=now()
          where provider_message_id=p_provider_message_id
            and adapter_key='resend-email-v1' and environment='sandbox';
        get diagnostics v_rows=row_count;
        v_applied := v_rows>0;
      end if;
    end if;
  end if;

  begin
    insert into private.notification_events(adapter_key,provider_message_id,event_key,event_type,signature_valid,payload_sha256,duplicate,applied,processed_at,metadata)
    values('resend-email-v1',nullif(p_provider_message_id,''),p_event_key,coalesce(nullif(p_event_type,''),'unknown'),true,p_payload_sha256,false,v_applied,now(),jsonb_build_object('environment','sandbox','pii_stored',false,'matched_outbox',v_matched,'previous_status',v_current,'resulting_status',coalesce(v_next,v_current)));
  exception when unique_violation then
    return jsonb_build_object('duplicate',true,'applied',false,'event_type',p_event_type);
  end;
  return jsonb_build_object('duplicate',false,'applied',v_applied,'event_type',p_event_type,'status',coalesce(v_next,v_current));
end $function$;;
