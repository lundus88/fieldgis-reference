create or replace function private.evaluate_factory_preflight(p_compilation_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = private, public, pg_temp
as $$
declare
  v_plan jsonb;
  v_blockers jsonb;
  v_blocker_count integer;
  v_project_id uuid;
  v_app_spec_id uuid;
begin
  select project_id, app_spec_id, capability_adapter_plan
    into v_project_id, v_app_spec_id, v_plan
  from public.spec_compilations
  where id = p_compilation_id;

  if not found then
    return jsonb_build_object(
      'ready', false,
      'decision', 'BLOCKED',
      'reason', 'compilation_not_found',
      'production_locked', true
    );
  end if;

  v_plan := coalesce(v_plan, '[]'::jsonb);

  select coalesce(jsonb_agg(x), '[]'::jsonb), count(*)
    into v_blockers, v_blocker_count
  from jsonb_array_elements(v_plan) x
  where coalesce((x->>'blocking')::boolean, false) = true
     or coalesce(x->>'resolution','') = 'missing';

  return jsonb_build_object(
    'ready', v_blocker_count = 0,
    'decision', case when v_blocker_count = 0 then 'READY_FOR_FACTORY' else 'BLOCKED' end,
    'compilation_id', p_compilation_id,
    'project_id', v_project_id,
    'app_spec_id', v_app_spec_id,
    'production_locked', true,
    'adapter_plan', v_plan,
    'blocker_count', v_blocker_count,
    'blockers', v_blockers
  );
end;
$$;

revoke all on function private.evaluate_factory_preflight(uuid) from public, anon, authenticated;
grant execute on function private.evaluate_factory_preflight(uuid) to service_role;
;
