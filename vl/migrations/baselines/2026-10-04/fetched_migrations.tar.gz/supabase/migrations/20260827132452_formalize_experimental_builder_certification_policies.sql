insert into public.builder_certification_policies(builder_key,required_evidence,minimum_score,minimum_distinct_runs,allow_auto_activate,status,updated_at)
values
('ai-app-v1',
 '["experimental_golden_build","isolated_build_boundary","ai_runtime_contract","prompt_injection_resistance","secret_exfiltration_test","model_output_contract"]'::jsonb,
 1.0,2,false,'active',now()),
('desktop-tauri-v1',
 '["experimental_golden_build","isolated_build_boundary","desktop_compile_test","filesystem_permission_contract","offline_runtime_contract","updater_signature_contract"]'::jsonb,
 1.0,2,false,'active',now())
on conflict(builder_key) do update set
 required_evidence=excluded.required_evidence,
 minimum_score=excluded.minimum_score,
 minimum_distinct_runs=excluded.minimum_distinct_runs,
 allow_auto_activate=false,
 status='active',
 updated_at=now();;
