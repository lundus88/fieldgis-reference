alter table public.spec_compilations add column if not exists capability_adapter_plan jsonb not null default '[]'::jsonb;;
