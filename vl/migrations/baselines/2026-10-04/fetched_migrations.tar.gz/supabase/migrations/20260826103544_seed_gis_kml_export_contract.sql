create or replace function private.seed_gis_kml_export_source()
returns trigger
language plpgsql
set search_path to 'private','public','extensions','pg_temp'
as $function$
declare
  a public.app_specs%rowtype;
  v_builder text;
  v_kml text;
begin
  if new.run_type <> 'build' or new.target_environment='production' or new.production_locked is distinct from true or new.app_spec_id is null then return new; end if;
  select * into a from public.app_specs where id=new.app_spec_id;
  if not found or a.status <> 'approved' then return new; end if;
  v_builder := coalesce(nullif(new.input->>'builder_key',''), a.spec #>> '{selected_builder,builder_key}', a.spec #>> '{routing,selected_builder,builder_key}');
  if v_builder <> 'gis-web-v1' then return new; end if;

  v_kml := $ts$export type KmlPoint={name?:string;longitude:number;latitude:number};
export function pointsToKml(points:KmlPoint[]):string{
  const escapeXml=(v:string)=>v.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
  const marks=points.map((p,i)=>`<Placemark><name>${escapeXml(p.name??`P${i+1}`)}</name><Point><coordinates>${p.longitude},${p.latitude},0</coordinates></Point></Placemark>`).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document>${marks}</Document></kml>`;
}
export const exportKml=pointsToKml;
$ts$;

  insert into public.generated_artifacts(factory_run_id,project_id,artifact_kind,path,content,sha256,metadata)
  values(new.id,new.project_id,'source','gis/src/kml.ts',v_kml,encode(extensions.digest(v_kml,'sha256'),'hex'),jsonb_build_object('auto_seeded',true,'generator_version','2.1','builder_key',v_builder,'kml_export_contract',true))
  on conflict(factory_run_id,path) do nothing;
  return new;
end;
$function$;

drop trigger if exists trg_seed_gis_kml_export_source on public.factory_runs;
create trigger trg_seed_gis_kml_export_source
after insert on public.factory_runs
for each row execute function private.seed_gis_kml_export_source();;
