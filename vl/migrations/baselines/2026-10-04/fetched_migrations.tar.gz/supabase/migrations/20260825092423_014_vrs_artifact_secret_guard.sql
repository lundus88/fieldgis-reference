create or replace function private.reject_generated_artifact_secrets()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
begin
  if new.content ~* '(SUPABASE_SERVICE_ROLE_KEY|sb_secret_[A-Za-z0-9_-]+|sk-proj-[A-Za-z0-9_-]+|OPENAI_API_KEY\s*=|BEGIN[[:space:]]+(RSA |EC |OPENSSH )?PRIVATE KEY)' then
    raise exception 'Generated artifact rejected: potential secret material detected';
  end if;
  return new;
end;
$$;

revoke all on function private.reject_generated_artifact_secrets() from public, anon, authenticated;

drop trigger if exists generated_artifacts_secret_guard on public.generated_artifacts;
create trigger generated_artifacts_secret_guard
before insert or update of content on public.generated_artifacts
for each row execute function private.reject_generated_artifact_secrets();;
