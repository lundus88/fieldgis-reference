create table if not exists private.payment_sandbox_orders (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key),
  provider_bill_id text unique,
  merchant_reference text not null unique,
  amount_minor integer not null check (amount_minor > 0),
  currency text not null default 'MYR' check (currency = 'MYR'),
  environment text not null default 'sandbox' check (environment = 'sandbox'),
  status text not null default 'pending' check (status in ('pending','paid','failed','cancelled','refunded')),
  fulfillment_state text not null default 'unfulfilled' check (fulfillment_state in ('unfulfilled','fulfilled','reversed')),
  checkout_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  paid_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists private.payment_webhook_events (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key),
  event_key text not null unique,
  provider_bill_id text,
  payload_sha256 text not null,
  signature_valid boolean not null,
  normalized_status text check (normalized_status in ('pending','paid','failed','cancelled','refunded')),
  amount_minor integer,
  applied boolean not null default false,
  duplicate boolean not null default false,
  error_text text,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists private.payment_reconciliation_checks (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key),
  order_id uuid not null references private.payment_sandbox_orders(id),
  provider_bill_id text,
  expected_status text not null,
  provider_status text,
  expected_amount_minor integer not null,
  provider_amount_minor integer,
  status text not null check (status in ('pass','fail','blocked')),
  evidence jsonb not null default '{}'::jsonb,
  checked_at timestamptz not null default now()
);

alter table private.payment_sandbox_orders enable row level security;
alter table private.payment_webhook_events enable row level security;
alter table private.payment_reconciliation_checks enable row level security;

revoke all on private.payment_sandbox_orders from public, anon, authenticated;
revoke all on private.payment_webhook_events from public, anon, authenticated;
revoke all on private.payment_reconciliation_checks from public, anon, authenticated;
grant select, insert, update, delete on private.payment_sandbox_orders to service_role;
grant select, insert, update, delete on private.payment_webhook_events to service_role;
grant select, insert, update, delete on private.payment_reconciliation_checks to service_role;

comment on table private.payment_sandbox_orders is 'VL sandbox-only payment orders. Never stores provider credentials.';
comment on table private.payment_webhook_events is 'VL sanitized payment webhook ledger for idempotency and audit. No raw secrets or full PII payloads.';
comment on table private.payment_reconciliation_checks is 'VL sandbox payment reconciliation evidence.';;
