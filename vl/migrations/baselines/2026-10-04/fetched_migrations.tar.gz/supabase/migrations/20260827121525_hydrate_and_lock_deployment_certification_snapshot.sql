create or replace function private.enforce_deployment_snapshot_immutability()
returns trigger
language plpgsql
security definer
set search_path = private, public, extensions, pg_temp
as $function$
declare
  v_calc_hash text;
begin
  -- Materialize immutable snapshot columns from the release certificate when
  -- they have not yet been populated. This keeps certificate JSON and typed
  -- columns in one deterministic contract.
  if new.required_gates_snapshot is null and jsonb_typeof(new.certificate->'required_gates')='array' then
    new.required_gates_snapshot := new.certificate->'required_gates';
  end if;
  if new.builder_key_snapshot is null then
    new.builder_key_snapshot := nullif(new.certificate->>'builder_key','');
  end if;
  if new.builder_version_snapshot is null and coalesce(new.certificate->>'builder_version','') ~ '^[0-9]+$' then
    new.builder_version_snapshot := (new.certificate->>'builder_version')::integer;
  end if;
  if new.gate_policy_version_snapshot is null and coalesce(new.certificate->>'gate_policy_version','') ~ '^[0-9]+$' then
    new.gate_policy_version_snapshot := (new.certificate->>'gate_policy_version')::integer;
  end if;
  if new.gate_policy_sha256 is null then
    new.gate_policy_sha256 := nullif(new.certificate->>'gate_policy_sha256','');
  end if;
  if new.builder_profile_sha256_snapshot is null then
    new.builder_profile_sha256_snapshot := nullif(new.certificate->>'builder_profile_sha256','');
  end if;
  if new.app_spec_sha256 is null then
    new.app_spec_sha256 := nullif(new.certificate->>'app_spec_sha256','');
  end if;
  if new.source_commit_sha is null then
    new.source_commit_sha := nullif(new.certificate->>'source_commit_sha','');
  end if;

  if new.required_gates_snapshot is not null then
    v_calc_hash := encode(extensions.digest(convert_to(new.required_gates_snapshot::text,'UTF8'),'sha256'),'hex');
    if new.gate_policy_sha256 is null then
      new.gate_policy_sha256 := v_calc_hash;
    elsif lower(new.gate_policy_sha256) <> lower(v_calc_hash) then
      raise exception 'deployment gate policy hash does not match required gate snapshot';
    end if;
  end if;

  if tg_op='UPDATE' and old.gate_policy_sha256 is not null then
    if new.factory_run_id is distinct from old.factory_run_id
       or new.required_gates_snapshot is distinct from old.required_gates_snapshot
       or new.builder_key_snapshot is distinct from old.builder_key_snapshot
       or new.builder_version_snapshot is distinct from old.builder_version_snapshot
       or new.gate_policy_version_snapshot is distinct from old.gate_policy_version_snapshot
       or new.gate_policy_sha256 is distinct from old.gate_policy_sha256
       or new.builder_profile_sha256_snapshot is distinct from old.builder_profile_sha256_snapshot
       or new.app_spec_sha256 is distinct from old.app_spec_sha256
       or new.source_commit_sha is distinct from old.source_commit_sha then
      raise exception 'deployment certification snapshot is immutable';
    end if;
  end if;

  if new.status in ('certified','approved','deploying','deployed') then
    if new.factory_run_id is null or new.required_gates_snapshot is null
       or new.builder_key_snapshot is null or new.builder_version_snapshot is null
       or new.gate_policy_version_snapshot is null or new.gate_policy_sha256 is null then
      raise exception 'certified deployment requires immutable certification snapshot';
    end if;
  end if;
  return new;
end
$function$;

-- Materialize snapshot columns for release-certificate/3 rows whose certificate
-- already contains the same immutable values. No evidence is changed.
update public.deployments
set certificate = certificate
where certificate->>'schema'='vrs.release-certificate/3'
  and (required_gates_snapshot is null
       or builder_key_snapshot is null
       or builder_version_snapshot is null
       or gate_policy_version_snapshot is null
       or gate_policy_sha256 is null);;
