create or replace function public.claim_vrs_release_validation_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $function$
declare
  j private.release_validation_jobs%rowtype;
  v_lease uuid:=gen_random_uuid();
  v_run public.factory_runs%rowtype;
  v_dep public.deployments%rowtype;
  v_required jsonb;
  v_artifacts jsonb;
begin
  select * into j from private.release_validation_jobs
  where (state='queued' or (state='leased' and lease_expires_at<now())) and attempts<max_attempts
  order by created_at for update skip locked limit 1;
  if not found then return jsonb_build_object('status','idle'); end if;

  update private.release_validation_jobs
  set state='leased',attempts=attempts+1,lease_token=v_lease,leased_at=now(),lease_expires_at=now()+interval '20 minutes',runner_identity=coalesce(p_runner_identity,'{}'::jsonb),updated_at=now()
  where id=j.id returning * into j;

  select * into v_run from public.factory_runs where id=j.factory_run_id;
  select * into v_dep from public.deployments where id=j.deployment_id;

  if v_dep.status<>'planned' or v_run.state<>'validating' or v_run.production_locked is distinct from true then
    update private.release_validation_jobs
    set state='failed',error_text='release candidate not eligible',finished_at=now(),updated_at=now()
    where id=j.id;
    return jsonb_build_object('status','rejected','reason','release_candidate_not_eligible');
  end if;

  v_required:=private.get_required_release_gates(v_run.id);
  select coalesce(jsonb_agg(jsonb_build_object('path',g.path,'content',g.content,'sha256',g.sha256,'artifact_kind',g.artifact_kind,'metadata',g.metadata) order by g.path),'[]'::jsonb)
  into v_artifacts from public.generated_artifacts g where g.factory_run_id=v_run.id;

  return jsonb_build_object('status','leased','job_id',j.id,'lease_token',v_lease,'deployment_id',j.deployment_id,'factory_run_id',j.factory_run_id,'builder_key',j.builder_key,'artifact_sha256',v_dep.artifact_sha256,'required_gates',v_required,'generated_artifacts',v_artifacts,'attempt',j.attempts,'max_attempts',j.max_attempts);
end
$function$;;
