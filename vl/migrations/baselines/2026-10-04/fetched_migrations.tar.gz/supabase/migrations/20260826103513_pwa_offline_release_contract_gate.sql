update private.builder_release_gate_profiles
set required_gates = (
  select jsonb_agg(
    case when g->>'key'='offline_pwa_e2e'
      then jsonb_build_object('key','offline_pwa_contract','type','qa')
      else g end
  )
  from jsonb_array_elements(required_gates) g
), updated_at=now()
where builder_key='pwa-react-v1';

create or replace function public.evaluate_vrs_release_server_gates(p_factory_run_id uuid)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_required jsonb;
  v_run public.factory_runs%rowtype;
  v_dep public.deployments%rowtype;
  v_rls_off int;
  v_bad_definer int;
  v_artifact_match boolean;
  v_results jsonb:='[]'::jsonb;
  v_sw text;
  v_manifest text;
  v_pwa_offline_ok boolean;
begin
  select * into v_run from public.factory_runs where id=p_factory_run_id;
  if not found then raise exception 'factory run not found'; end if;
  select * into v_dep from public.deployments
   where project_id=v_run.project_id and workflow_id=v_run.workflow_id
     and artifact_sha256=coalesce(v_run.result#>>'{runner,artifact_sha256}',v_run.result->>'artifact_sha256')
   order by created_at desc limit 1;
  if not found then raise exception 'release deployment not found'; end if;
  v_required:=private.get_required_release_gates(v_run.id);

  if exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'='database_security') then
    select count(*) into v_rls_off from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and c.relrowsecurity=false;
    select count(*) into v_bad_definer from pg_proc p join pg_namespace n on n.oid=p.pronamespace
     where n.nspname='public' and p.prokind='f' and p.prosecdef
       and (has_function_privilege('public',p.oid,'EXECUTE') or has_function_privilege('anon',p.oid,'EXECUTE') or has_function_privilege('authenticated',p.oid,'EXECUTE'));
    update public.release_gates set status=case when v_rls_off=0 and v_bad_definer=0 then 'pass' else 'fail' end,
      score=case when v_rls_off=0 and v_bad_definer=0 then 1 else 0 end,
      evidence=jsonb_build_object('scope','vrs_control_plane_database','public_tables_without_rls',v_rls_off,'public_security_definer_exposed_to_client_roles',v_bad_definer,'checked_by','server_gate_evaluator'),checked_at=now(),checked_by=null
      where factory_run_id=v_run.id and gate_key='database_security';
    v_results:=v_results||jsonb_build_array(jsonb_build_object('key','database_security','status',case when v_rls_off=0 and v_bad_definer=0 then 'pass' else 'fail' end));
  end if;

  if exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'='rollback_contract') then
    select exists(select 1 from public.factory_artifacts fa where fa.factory_run_id=v_run.id and lower(fa.sha256)=lower(v_dep.artifact_sha256)) into v_artifact_match;
    update public.release_gates set status=case when v_run.production_locked=true and v_dep.status in ('planned','certified') and v_artifact_match then 'pass' else 'fail' end,
      score=case when v_run.production_locked=true and v_dep.status in ('planned','certified') and v_artifact_match then 1 else 0 end,
      evidence=jsonb_build_object('scope','control_plane_rollback_contract','immutable_artifact_hash_match',v_artifact_match,'production_lock_preserved',v_run.production_locked,'deployment_status',v_dep.status,'rollback_status_supported',true,'note','External target rollback remains adapter-specific and is required before deployed state.'),checked_at=now(),checked_by=null
      where factory_run_id=v_run.id and gate_key='rollback_contract';
    v_results:=v_results||jsonb_build_array(jsonb_build_object('key','rollback_contract','status',case when v_run.production_locked=true and v_dep.status in ('planned','certified') and v_artifact_match then 'pass' else 'fail' end));
  end if;

  if exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'='offline_pwa_contract') then
    select content into v_sw from public.generated_artifacts where factory_run_id=v_run.id and path='web/public/sw.js' order by created_at desc limit 1;
    select content into v_manifest from public.generated_artifacts where factory_run_id=v_run.id and path='web/public/manifest.webmanifest' order by created_at desc limit 1;
    v_pwa_offline_ok := coalesce(v_sw,'') like '%caches.open%'
      and coalesce(v_sw,'') like '%cache.put%'
      and coalesce(v_sw,'') like '%caches.match%'
      and coalesce(v_manifest,'') <> '';
    update public.release_gates set status=case when v_pwa_offline_ok then 'pass' else 'fail' end,
      score=case when v_pwa_offline_ok then 1 else 0 end,
      evidence=jsonb_build_object('scope','generated_pwa_offline_contract','manifest_present',coalesce(v_manifest,'')<>'','cache_open',coalesce(v_sw,'') like '%caches.open%','cache_put',coalesce(v_sw,'') like '%cache.put%','cache_match',coalesce(v_sw,'') like '%caches.match%','checked_by','server_gate_evaluator'),checked_at=now(),checked_by=null
      where factory_run_id=v_run.id and gate_key='offline_pwa_contract';
    v_results:=v_results||jsonb_build_array(jsonb_build_object('key','offline_pwa_contract','status',case when v_pwa_offline_ok then 'pass' else 'fail' end));
  end if;

  return jsonb_build_object('factory_run_id',v_run.id,'server_gate_results',v_results);
end;
$function$;;
