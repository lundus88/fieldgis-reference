create unique index if not exists approvals_factory_run_type_uidx on public.approvals(factory_run_id,approval_type);

create or replace function private.approve_production_release(p_deployment_id uuid, p_rationale text default null::text)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_uid uuid:=auth.uid();
  v_dep public.deployments%rowtype;
  v_run public.factory_runs%rowtype;
  v_required jsonb;
  v_missing int;
  v_approval public.approvals%rowtype;
begin
  if v_uid is null then raise exception 'authenticated user required'; end if;
  select * into v_dep from public.deployments where id=p_deployment_id for update;
  if not found then raise exception 'deployment not found'; end if;
  if not private.has_project_role(v_dep.project_id,array['owner','admin']) then raise exception 'owner/admin production approval required'; end if;
  if v_dep.status in ('approved','deploying','deployed') and v_dep.approved_by is not null then
    select * into v_approval from public.approvals where factory_run_id=v_dep.factory_run_id and approval_type='production_release' limit 1;
    return jsonb_build_object('decision','production_release_already_approved','deployment_id',v_dep.id,'factory_run_id',v_dep.factory_run_id,'approval_id',v_approval.id,'approved_by',v_dep.approved_by,'artifact_sha256',v_dep.artifact_sha256,'idempotent',true);
  end if;
  if v_dep.status<>'certified' then raise exception 'deployment must be technically certified before approval'; end if;
  select * into v_run from public.factory_runs where id=v_dep.factory_run_id and project_id=v_dep.project_id for update;
  if not found then raise exception 'factory run not found'; end if;
  if v_dep.workflow_id is distinct from v_run.workflow_id then raise exception 'deployment workflow mismatch'; end if;
  v_required:=private.get_deployment_required_release_gates(v_dep.id);
  select count(*) into v_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass');
  if v_missing>0 then raise exception 'technical release gates not all PASS'; end if;

  select * into v_approval from public.approvals where factory_run_id=v_run.id and approval_type='production_release' for update;
  if not found then raise exception 'production approval record required'; end if;
  if v_approval.status='approved' then
    return jsonb_build_object('decision','production_release_already_approved','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval.id,'approved_by',v_approval.decided_by,'artifact_sha256',v_dep.artifact_sha256,'idempotent',true);
  end if;
  if v_approval.status<>'pending' then raise exception 'production approval is not pending'; end if;

  update public.approvals set status='approved',decided_by=v_uid,decided_at=now(),rationale=coalesce(nullif(p_rationale,''),rationale,'Explicit owner/admin production approval') where id=v_approval.id;
  update public.release_gates set status='pass',score=1,evidence=jsonb_build_object('approval_id',v_approval.id,'approved_by',v_uid,'approved_at',now(),'explicit_human_approval',true),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key='human_production_approval';
  update public.release_gates set status='pass',score=1,evidence=jsonb_build_object('release_unlock','approved','approved_by',v_uid,'approved_at',now(),'factory_run_remains_immutable',true),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key='production_lock';
  update public.deployments set status='approved',approved_by=v_uid,certificate=certificate||jsonb_build_object('human_approval','PASS','approved_by',v_uid,'approved_at',now(),'production_release_authorized',true) where id=v_dep.id;
  return jsonb_build_object('decision','production_release_approved','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval.id,'approved_by',v_uid,'artifact_sha256',v_dep.artifact_sha256,'next_state','approved','idempotent',false);
end $function$;

create or replace function private.reject_production_release(p_deployment_id uuid, p_rationale text default null::text)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_uid uuid:=auth.uid();
  v_dep public.deployments%rowtype;
  v_run public.factory_runs%rowtype;
  v_approval public.approvals%rowtype;
begin
  if v_uid is null then raise exception 'authenticated user required'; end if;
  select * into v_dep from public.deployments where id=p_deployment_id for update;
  if not found then raise exception 'deployment not found'; end if;
  if not private.has_project_role(v_dep.project_id,array['owner','admin']) then raise exception 'owner/admin production decision required'; end if;
  select * into v_run from public.factory_runs where id=v_dep.factory_run_id and project_id=v_dep.project_id for update;
  if not found then raise exception 'factory run not found'; end if;
  select * into v_approval from public.approvals where factory_run_id=v_run.id and approval_type='production_release' for update;
  if found and v_approval.status='rejected' then
    return jsonb_build_object('decision','production_release_already_rejected','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval.id,'idempotent',true);
  end if;
  if v_dep.status not in ('planned','certified') then raise exception 'deployment is not awaiting production decision'; end if;
  if found then
    if v_approval.status<>'pending' then raise exception 'production approval is not pending'; end if;
    update public.approvals set status='rejected',decided_by=v_uid,decided_at=now(),rationale=coalesce(nullif(p_rationale,''),'Production release rejected') where id=v_approval.id;
  end if;
  update public.release_gates set status='blocked',score=0,evidence=jsonb_build_object('rejected_by',v_uid,'rejected_at',now(),'rationale',coalesce(p_rationale,'Production release rejected')),checked_at=now(),checked_by=v_uid where factory_run_id=v_run.id and gate_key in ('human_production_approval','production_lock');
  update public.deployments set status='failed',approved_by=null,certificate=certificate||jsonb_build_object('human_approval','REJECTED','rejected_by',v_uid,'rejected_at',now(),'rationale',coalesce(p_rationale,'Production release rejected')) where id=v_dep.id;
  return jsonb_build_object('decision','production_release_rejected','deployment_id',v_dep.id,'factory_run_id',v_run.id,'approval_id',v_approval.id,'idempotent',false);
end $function$;;
