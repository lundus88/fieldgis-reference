create or replace function private.get_required_release_gates(p_factory_run_id uuid)
returns jsonb
language sql
set search_path to 'private','public','pg_temp'
as $$
  with ctx as (
    select
      fr.run_type,
      coalesce(fr.result#>>'{runner,builder_key}', private.resolve_factory_builder(fr.id)) as builder_key,
      coalesce(a.spec,'{}'::jsonb) as spec
    from public.factory_runs fr
    left join public.app_specs a on a.id=fr.app_spec_id
    where fr.id=p_factory_run_id
  ), base as (
    select c.run_type,c.spec,
           coalesce(p.required_gates,
             '[{"key":"security_advisor","type":"security"},{"key":"cross_tenant_rls","type":"rls"},{"key":"auth_http_e2e","type":"auth"},{"key":"data_api_http_e2e","type":"data_api"},{"key":"storage_physical_e2e","type":"storage"},{"key":"rollback_rehearsal","type":"rollback"},{"key":"qa_regression","type":"qa"}]'::jsonb
           ) as gates
    from ctx c
    left join private.builder_release_gate_profiles p using(builder_key)
  ), filtered as (
    select b.run_type,jsonb_agg(g.value order by g.ord) as gates
    from base b,
         lateral jsonb_array_elements(b.gates) with ordinality as g(value,ord)
    where not (
      (g.value->>'key'='auth_http_e2e' and ((b.spec ? 'auth' and b.spec->'auth'='false'::jsonb) or coalesce((b.spec#>>'{inferred,auth_requested}')::boolean,false)=false))
      or (g.value->>'key'='storage_physical_e2e' and b.spec ? 'storage' and b.spec->'storage'='false'::jsonb)
      or (g.value->>'key' in ('cross_tenant_rls','data_api_http_e2e') and not exists (
          select 1 from jsonb_array_elements_text(coalesce(b.spec#>'{inferred,required_capabilities}','[]'::jsonb)) c(value) where c.value='supabase'))
      or (g.value->>'key' in ('cross_tenant_rls','data_api_http_e2e') and coalesce((b.spec#>>'{constraints,demo_data_only}')::boolean,false)=true and jsonb_array_length(coalesce(b.spec->'entities','[]'::jsonb))=0)
    )
    group by b.run_type
  )
  select coalesce(f.gates,'[]'::jsonb) ||
         case when f.run_type='upgrade'
              then '[{"key":"upgrade_lineage_contract","type":"qa"}]'::jsonb
              else '[]'::jsonb end
  from filtered f
$$;;
