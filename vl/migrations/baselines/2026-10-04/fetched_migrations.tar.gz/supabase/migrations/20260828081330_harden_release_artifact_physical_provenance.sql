create or replace function private.enforce_factory_artifact_immutability()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_referenced boolean := false;
  v_run_state text;
  v_old_base jsonb;
  v_new_base jsonb;
  v_old_id text;
  v_new_id text;
  v_old_digest text;
  v_new_digest text;
  v_old_exp text;
  v_new_exp text;
begin
  if tg_op='INSERT' then
    if new.sha256 is not null and new.sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'factory artifact sha256 must be a valid SHA-256 hex digest'; end if;
    return new;
  end if;

  select exists(select 1 from public.deployments d where d.factory_run_id=old.factory_run_id and lower(coalesce(d.artifact_sha256,''))=lower(coalesce(old.sha256,'')) and d.status in ('planned','certified','approved','deploying','deployed')) into v_referenced;
  select state into v_run_state from public.factory_runs where id=old.factory_run_id;

  if tg_op='DELETE' then
    if v_referenced then raise exception 'immutable factory artifact: artifact is referenced by a release deployment'; end if;
    if v_run_state not in ('queued','building','validating','failed') then raise exception 'immutable factory artifact: deletion not allowed after factory run leaves mutable states'; end if;
    return old;
  end if;

  if new.factory_run_id is distinct from old.factory_run_id or new.project_id is distinct from old.project_id or new.artifact_type is distinct from old.artifact_type or new.name is distinct from old.name or new.storage_path is distinct from old.storage_path or new.sha256 is distinct from old.sha256 or new.created_at is distinct from old.created_at then
    if v_referenced then raise exception 'immutable factory artifact: release-bound identity/content fields cannot be changed'; end if;
    if v_run_state not in ('building','validating') then raise exception 'immutable factory artifact: identity/content fields may only change during building/validating'; end if;
  end if;

  if v_referenced and new.metadata is distinct from old.metadata then
    v_old_id:=nullif(old.metadata->>'github_artifact_id',''); v_new_id:=nullif(new.metadata->>'github_artifact_id','');
    v_old_digest:=nullif(old.metadata->>'github_artifact_digest',''); v_new_digest:=nullif(new.metadata->>'github_artifact_digest','');
    v_old_exp:=nullif(old.metadata->>'github_artifact_expires_at',''); v_new_exp:=nullif(new.metadata->>'github_artifact_expires_at','');
    v_old_base:=coalesce(old.metadata,'{}'::jsonb)-'github_artifact_id'-'github_artifact_digest'-'github_artifact_expires_at'-'github_head_sha'-'github_artifact_verified_at';
    v_new_base:=coalesce(new.metadata,'{}'::jsonb)-'github_artifact_id'-'github_artifact_digest'-'github_artifact_expires_at'-'github_head_sha'-'github_artifact_verified_at';
    if v_old_base is distinct from v_new_base then raise exception 'immutable factory artifact: release-bound metadata cannot change'; end if;
    if v_old_id is not null or v_old_digest is not null or v_old_exp is not null then raise exception 'immutable factory artifact: physical provenance is write-once'; end if;
    if v_new_id is null or v_new_id !~ '^[0-9]+$' then raise exception 'github artifact id required for physical provenance'; end if;
    if v_new_digest is null or v_new_digest !~ '^sha256:[0-9a-fA-F]{64}$' then raise exception 'github artifact digest required for physical provenance'; end if;
    if v_new_exp is null then raise exception 'github artifact expiry required for physical provenance'; end if;
  end if;

  if new.sha256 is not null and new.sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'factory artifact sha256 must be a valid SHA-256 hex digest'; end if;
  return new;
end
$$;

create or replace function private.enforce_production_deployment_guard()
returns trigger
language plpgsql
security definer
set search_path to 'public','private','extensions','pg_temp'
as $$
declare
  v_env_kind text; v_run public.factory_runs%rowtype; v_required jsonb; v_technical_missing int; v_human_ok boolean; v_unlock_ok boolean; v_approval_ok boolean; v_cert_hash text; v_art public.factory_artifacts%rowtype;
begin
  select kind into v_env_kind from public.environments where id=new.environment_id and project_id=new.project_id;
  if v_env_kind is distinct from 'production' then return new; end if;
  if new.status not in ('certified','approved','deploying','deployed') then return new; end if;
  if new.workflow_id is null then raise exception 'production deployment requires workflow_id'; end if;
  if new.factory_run_id is null then raise exception 'production deployment requires factory_run_id'; end if;
  select * into v_run from public.factory_runs where id=new.factory_run_id and project_id=new.project_id;
  if not found then raise exception 'production deployment requires a valid factory run'; end if;
  if new.workflow_id is distinct from v_run.workflow_id then raise exception 'production deployment workflow does not match factory run'; end if;
  v_required:=coalesce(new.required_gates_snapshot,'[]'::jsonb);
  if jsonb_array_length(v_required)=0 then raise exception 'production deployment requires frozen gate policy'; end if;
  select count(*) into v_technical_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key=g->>'key' and rg.status='pass');
  if v_technical_missing>0 then raise exception 'production certification blocked: frozen required gates not all PASS'; end if;
  if new.artifact_sha256 is null or new.artifact_sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'production deployment requires valid SHA-256 artifact hash'; end if;
  v_cert_hash:=coalesce(new.certificate->>'artifact_sha256',new.certificate->>'sha256');
  if v_cert_hash is null or lower(v_cert_hash)<>lower(new.artifact_sha256) then raise exception 'production certificate hash does not match artifact SHA-256'; end if;
  if new.gate_policy_sha256 is null or lower(new.gate_policy_sha256)<>lower(encode(extensions.digest(convert_to(new.required_gates_snapshot::text,'UTF8'),'sha256'),'hex')) then raise exception 'production gate policy snapshot hash mismatch'; end if;

  if new.status in ('approved','deploying','deployed') then
    select * into v_art from public.factory_artifacts where factory_run_id=new.factory_run_id and artifact_type='bundle' and lower(sha256)=lower(new.artifact_sha256) order by created_at desc limit 1;
    if not found then raise exception 'production deployment blocked: immutable source artifact required'; end if;
    if v_art.storage_path not like 'github-actions://lundus88/fieldgis-reference/runs/%/artifacts/%' then raise exception 'production deployment blocked: trusted GitHub Actions artifact path required'; end if;
    if coalesce(v_art.metadata->>'github_artifact_id','') !~ '^[0-9]+$' then raise exception 'production deployment blocked: GitHub artifact id provenance required'; end if;
    if coalesce(v_art.metadata->>'github_artifact_digest','') !~ '^sha256:[0-9a-fA-F]{64}$' then raise exception 'production deployment blocked: GitHub artifact digest provenance required'; end if;
    if nullif(v_art.metadata->>'github_artifact_expires_at','') is null then raise exception 'production deployment blocked: GitHub artifact expiry provenance required'; end if;
    if (v_art.metadata->>'github_artifact_expires_at')::timestamptz <= now() then raise exception 'production deployment blocked: GitHub artifact has expired'; end if;
    if new.source_commit_sha is null or new.source_commit_sha !~ '^[0-9a-fA-F]{40}$' then raise exception 'production deployment blocked: valid source commit SHA required'; end if;
    if nullif(v_art.metadata->>'github_head_sha','') is null or lower(v_art.metadata->>'github_head_sha')<>lower(new.source_commit_sha) then raise exception 'production deployment blocked: GitHub artifact commit provenance mismatch'; end if;

    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='human_production_approval' and rg.status='pass') into v_human_ok;
    select exists(select 1 from public.release_gates rg where rg.factory_run_id=v_run.id and rg.gate_key='production_lock' and rg.status='pass') into v_unlock_ok;
    select exists(select 1 from public.approvals a where a.factory_run_id=v_run.id and a.project_id=new.project_id and a.workflow_id=new.workflow_id and a.approval_type='production_release' and a.status='approved' and a.decided_by is not null and a.decided_at is not null) into v_approval_ok;
    if not v_human_ok then raise exception 'production deployment blocked: human production approval gate not PASS'; end if;
    if not v_unlock_ok then raise exception 'production deployment blocked: production lock not released'; end if;
    if not v_approval_ok then raise exception 'production deployment blocked: approved human approval record required'; end if;
    if new.approved_by is null then raise exception 'production deployment blocked: approved_by required'; end if;
  end if;
  if new.status='deployed' and new.deployed_at is null then new.deployed_at:=now(); end if;
  return new;
end
$$;;
