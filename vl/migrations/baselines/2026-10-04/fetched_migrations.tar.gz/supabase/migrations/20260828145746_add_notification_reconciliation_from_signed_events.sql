create or replace function private.reconcile_notification_outbox(p_outbox_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=private,public,pg_temp
as $$
declare
  v_outbox private.notification_outbox%rowtype;
  v_provider_status text;
  v_check_status text;
  v_event_count int;
  v_signature_ok boolean;
begin
  select * into v_outbox from private.notification_outbox where id=p_outbox_id;
  if not found then raise exception 'outbox not found'; end if;
  if v_outbox.provider_message_id is null then raise exception 'provider message id missing'; end if;

  select count(*), coalesce(bool_and(signature_valid),false)
    into v_event_count,v_signature_ok
  from private.notification_events
  where adapter_key=v_outbox.adapter_key and provider_message_id=v_outbox.provider_message_id;

  select case
    when exists(select 1 from private.notification_events where adapter_key=v_outbox.adapter_key and provider_message_id=v_outbox.provider_message_id and signature_valid and event_type='email.bounced') then 'bounced'
    when exists(select 1 from private.notification_events where adapter_key=v_outbox.adapter_key and provider_message_id=v_outbox.provider_message_id and signature_valid and event_type='email.delivered') then 'delivered'
    when exists(select 1 from private.notification_events where adapter_key=v_outbox.adapter_key and provider_message_id=v_outbox.provider_message_id and signature_valid and event_type='email.sent') then 'sent'
    else null end into v_provider_status;

  v_check_status := case when v_event_count>0 and v_signature_ok and v_provider_status=v_outbox.status then 'pass' else 'fail' end;

  insert into private.notification_reconciliation_checks(adapter_key,outbox_id,expected_status,provider_status,status,evidence,checked_at)
  values(v_outbox.adapter_key,v_outbox.id,v_outbox.status,v_provider_status,v_check_status,
    jsonb_build_object('provider_message_id',v_outbox.provider_message_id,'signed_event_count',v_event_count,'all_signatures_valid',v_signature_ok,'environment',v_outbox.environment),now());

  return jsonb_build_object('outbox_id',v_outbox.id,'status',v_check_status,'expected_status',v_outbox.status,'provider_status',v_provider_status);
end $$;
revoke all on function private.reconcile_notification_outbox(uuid) from public,anon,authenticated;
grant execute on function private.reconcile_notification_outbox(uuid) to service_role;

select private.reconcile_notification_outbox(id) from private.notification_outbox
where adapter_key='resend-email-v1' and environment='sandbox' and status in ('delivered','bounced') and provider_message_id is not null
and not exists(select 1 from private.notification_reconciliation_checks rc where rc.outbox_id=notification_outbox.id);
;
