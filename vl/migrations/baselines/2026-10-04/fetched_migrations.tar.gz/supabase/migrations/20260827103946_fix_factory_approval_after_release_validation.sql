create or replace function public.complete_vrs_runner_job(
  p_job_id uuid,
  p_lease_token uuid,
  p_success boolean,
  p_result jsonb default '{}'::jsonb,
  p_error_text text default null
) returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $function$
declare
  j private.runner_jobs%rowtype;
  v_run_state text;
  v_artifact_name text;
  v_storage_path text;
  v_sha text;
begin
  select * into j from private.runner_jobs where id=p_job_id for update;
  if not found then raise exception 'runner job not found'; end if;
  if j.state <> 'leased' or j.lease_token is distinct from p_lease_token then raise exception 'invalid runner lease'; end if;
  if j.lease_expires_at < now() then raise exception 'runner lease expired'; end if;

  if p_success then
    update private.runner_jobs
      set state='succeeded',result=coalesce(p_result,'{}'::jsonb),error_text=null,finished_at=now(),updated_at=now()
      where id=j.id;

    v_artifact_name := coalesce(nullif(p_result->>'artifact_name',''), j.builder_key || '-build');
    v_sha := nullif(p_result->>'artifact_sha256','');
    v_storage_path := case when nullif(p_result->>'github_run_id','') is not null
      then 'github-actions://lundus88/fieldgis-reference/runs/' || (p_result->>'github_run_id') || '/artifacts/' || v_artifact_name
      else null end;

    insert into public.factory_artifacts(factory_run_id,project_id,artifact_type,name,storage_path,sha256,metadata)
    values(j.factory_run_id,j.project_id,'bundle',v_artifact_name,v_storage_path,v_sha,
      jsonb_build_object('runner','github-actions-oidc','builder_key',j.builder_key,'qa_result','PASS','github_run_id',p_result->>'github_run_id'))
    on conflict(factory_run_id,name) do update
      set storage_path=excluded.storage_path,sha256=excluded.sha256,metadata=excluded.metadata;

    update public.factory_runs
      set state='validating',
          started_at=coalesce(started_at,j.leased_at,j.created_at),
          result=coalesce(result,'{}'::jsonb)||jsonb_build_object('runner',coalesce(p_result,'{}'::jsonb),'runner_status','PASS'),
          error_text=null
      where id=j.factory_run_id and target_environment<>'production' and production_locked=true;

    update public.workflows w
      set state='running',
          started_at=coalesce(w.started_at,j.leased_at,j.created_at),
          output=coalesce(output,'{}'::jsonb)||jsonb_build_object('runner_status','PASS','runner',coalesce(p_result,'{}'::jsonb))
      from public.factory_runs r where r.id=j.factory_run_id and w.id=r.workflow_id;
    v_run_state := 'validating';
  else
    if j.attempts < j.max_attempts then
      update private.runner_jobs
        set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,updated_at=now()
        where id=j.id;
      update public.factory_runs set state='building',started_at=coalesce(started_at,j.leased_at,j.created_at),error_text=p_error_text where id=j.factory_run_id and target_environment<>'production' and production_locked=true;
      v_run_state := 'building';
    else
      update private.runner_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,finished_at=now(),updated_at=now() where id=j.id;
      update public.factory_runs set state='failed',started_at=coalesce(started_at,j.leased_at,j.created_at),error_text=p_error_text,finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',started_at=coalesce(w.started_at,j.leased_at,j.created_at),finished_at=now(),output=coalesce(output,'{}'::jsonb)||jsonb_build_object('runner_status','FAIL','error',p_error_text)
        from public.factory_runs r where r.id=j.factory_run_id and w.id=r.workflow_id;
      v_run_state := 'failed';
    end if;
  end if;

  return jsonb_build_object('status','recorded','job_id',j.id,'factory_run_id',j.factory_run_id,'factory_run_state',v_run_state);
end;
$function$;

create or replace function public.complete_vrs_release_validation_job(
  p_job_id uuid,
  p_lease_token uuid,
  p_success boolean,
  p_gate_results jsonb default '[]'::jsonb,
  p_result jsonb default '{}'::jsonb,
  p_error_text text default null
) returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $function$
declare
  j private.release_validation_jobs%rowtype;
  v_required jsonb;
  r jsonb;
  v_missing int;
  v_fail int;
begin
  select * into j from private.release_validation_jobs where id=p_job_id for update;
  if not found then raise exception 'release validation job not found'; end if;
  if j.state<>'leased' or j.lease_token is distinct from p_lease_token then raise exception 'invalid release validation lease'; end if;
  if j.lease_expires_at<now() then raise exception 'release validation lease expired'; end if;
  v_required:=private.get_required_release_gates(j.factory_run_id);

  if p_success then
    if jsonb_typeof(coalesce(p_gate_results,'[]'::jsonb))<>'array' then raise exception 'gate_results must be array'; end if;
    for r in select value from jsonb_array_elements(coalesce(p_gate_results,'[]'::jsonb)) loop
      if (r->>'key') in ('human_production_approval','production_lock') then raise exception 'human/production lock gates cannot be set by automated validator'; end if;
      if not exists(select 1 from jsonb_array_elements(v_required) g where g->>'key'=r->>'key') then raise exception 'validator returned gate not required by builder profile: %',r->>'key'; end if;
      if coalesce(r->>'status','') not in ('pass','fail') then raise exception 'automated gate status must be pass or fail'; end if;
      update public.release_gates set status=r->>'status',score=case when r ? 'score' then (r->>'score')::numeric else case when r->>'status'='pass' then 1 else 0 end end,evidence=coalesce(r->'evidence','{}'::jsonb),checked_at=now(),checked_by=null where factory_run_id=j.factory_run_id and gate_key=r->>'key';
    end loop;

    select count(*) into v_missing from jsonb_array_elements(v_required) g where not exists(select 1 from public.release_gates rg where rg.factory_run_id=j.factory_run_id and rg.gate_key=g->>'key' and rg.status='pass');
    select count(*) into v_fail from jsonb_array_elements(v_required) g where exists(select 1 from public.release_gates rg where rg.factory_run_id=j.factory_run_id and rg.gate_key=g->>'key' and rg.status='fail');

    if v_fail>0 then
      update private.release_validation_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text='one or more technical release gates failed',finished_at=now(),updated_at=now() where id=j.id;
      update public.deployments set status='failed',certificate=certificate||jsonb_build_object('technical_validation','FAIL','validation_result',coalesce(p_result,'{}'::jsonb)) where id=j.deployment_id;
      update public.factory_runs set state='failed',error_text='Technical release validation failed',finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',finished_at=now(),output=coalesce(w.output,'{}'::jsonb)||jsonb_build_object('technical_validation','FAIL') from public.factory_runs fr where fr.id=j.factory_run_id and w.id=fr.workflow_id;
      return jsonb_build_object('status','recorded','decision','technical_gates_failed','missing_or_failed',v_missing);
    elsif v_missing=0 then
      update private.release_validation_jobs set state='succeeded',result=coalesce(p_result,'{}'::jsonb),error_text=null,finished_at=now(),updated_at=now() where id=j.id;
      update public.deployments set status='certified',certificate=certificate||jsonb_build_object('technical_validation','PASS','validation_result',coalesce(p_result,'{}'::jsonb),'certified_at',now()) where id=j.deployment_id;
      update public.factory_runs set state='awaiting_approval',result=coalesce(result,'{}'::jsonb)||jsonb_build_object('technical_certification','PASS'),error_text=null where id=j.factory_run_id and target_environment<>'production' and production_locked=true;
      update public.workflows w set state='waiting_approval',output=coalesce(w.output,'{}'::jsonb)||jsonb_build_object('technical_validation','PASS') from public.factory_runs fr where fr.id=j.factory_run_id and w.id=fr.workflow_id;
      return jsonb_build_object('status','recorded','decision','technically_certified','deployment_status','certified','factory_run_state','awaiting_approval');
    else
      update private.release_validation_jobs set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text='required gates still pending',updated_at=now() where id=j.id;
      update public.factory_runs set state='validating',error_text=null where id=j.factory_run_id and state<>'failed';
      return jsonb_build_object('status','recorded','decision','more_validation_required','missing_or_failed',v_missing,'factory_run_state','validating');
    end if;
  else
    if j.attempts<j.max_attempts then
      update private.release_validation_jobs set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,updated_at=now() where id=j.id;
      update public.factory_runs set state='validating',error_text=p_error_text where id=j.factory_run_id and state<>'failed';
      return jsonb_build_object('status','recorded','decision','retry_queued','factory_run_state','validating');
    else
      update private.release_validation_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,finished_at=now(),updated_at=now() where id=j.id;
      update public.deployments set status='failed',certificate=certificate||jsonb_build_object('technical_validation','FAIL','error',p_error_text) where id=j.deployment_id;
      update public.factory_runs set state='failed',error_text=coalesce(p_error_text,'Release validation failed'),finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',finished_at=now(),output=coalesce(w.output,'{}'::jsonb)||jsonb_build_object('technical_validation','FAIL','error',p_error_text) from public.factory_runs fr where fr.id=j.factory_run_id and w.id=fr.workflow_id;
      return jsonb_build_object('status','recorded','decision','validation_failed','factory_run_state','failed');
    end if;
  end if;
end
$function$;;
