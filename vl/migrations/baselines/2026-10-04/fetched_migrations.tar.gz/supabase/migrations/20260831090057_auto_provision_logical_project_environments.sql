create or replace function private.ensure_default_project_environments()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
begin
  insert into public.environments(project_id,name,kind,status,metadata)
  select new.id,v.name,v.kind,'ready',jsonb_build_object(
    'provisioning','logical_default',
    'provider_binding','required_before_promotion'
  )
  from (values
    ('development'::text,'development'::text),
    ('staging'::text,'staging'::text),
    ('production'::text,'production'::text)
  ) as v(name,kind)
  where not exists (
    select 1 from public.environments e
    where e.project_id=new.id and e.kind=v.kind
  );
  return new;
end;
$$;

revoke all on function private.ensure_default_project_environments() from public,anon,authenticated;

drop trigger if exists trg_ensure_default_project_environments on public.projects;
create trigger trg_ensure_default_project_environments
after insert on public.projects
for each row execute function private.ensure_default_project_environments();;
