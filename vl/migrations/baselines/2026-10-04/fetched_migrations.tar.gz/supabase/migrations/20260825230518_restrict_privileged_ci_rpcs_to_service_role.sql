revoke execute on function public.ingest_ci_evidence(uuid,uuid,text,text,text,text,text,text,text,jsonb,jsonb,jsonb) from authenticated;
revoke execute on function public.learn_from_ci_repair(uuid,boolean,jsonb) from authenticated;
grant execute on function public.ingest_ci_evidence(uuid,uuid,text,text,text,text,text,text,text,jsonb,jsonb,jsonb) to service_role;
grant execute on function public.learn_from_ci_repair(uuid,boolean,jsonb) to service_role;;
