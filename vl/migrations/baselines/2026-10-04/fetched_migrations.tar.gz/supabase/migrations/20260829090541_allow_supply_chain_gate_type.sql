begin;
alter table public.release_gates drop constraint if exists release_gates_gate_type_check;
alter table public.release_gates add constraint release_gates_gate_type_check check (gate_type = any (array['security'::text,'rls'::text,'auth'::text,'data_api'::text,'storage'::text,'rollback'::text,'qa'::text,'human_approval'::text,'production_lock'::text,'supply_chain'::text]));
commit;;
