create table if not exists private.factory_execution_events (
  id uuid primary key default gen_random_uuid(),
  factory_run_id uuid not null references public.factory_runs(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  event_type text not null,
  from_state text,
  to_state text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists factory_execution_events_run_idx
  on private.factory_execution_events(factory_run_id, created_at);

revoke all on private.factory_execution_events from public, anon, authenticated;
grant select, insert on private.factory_execution_events to service_role;

create or replace function private.prepare_factory_execution(p_factory_run_id uuid)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare
  r public.factory_runs%rowtype;
  a public.app_specs%rowtype;
  v_builder_key text;
  v_builder public.builder_registry%rowtype;
  v_dispatch jsonb;
begin
  select * into r from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'Factory run not found'; end if;
  if r.state <> 'queued' then raise exception 'Factory run must be queued'; end if;
  if r.target_environment = 'production' or r.production_locked is distinct from true then
    raise exception 'Factory execution v1 only allows production-locked non-production runs';
  end if;
  if r.app_spec_id is null then raise exception 'Factory run requires app spec'; end if;

  select * into a from public.app_specs where id=r.app_spec_id;
  if not found or a.status <> 'approved' then raise exception 'Approved App Spec required'; end if;

  v_builder_key := coalesce(a.spec #>> '{selected_builder,builder_key}', a.spec #>> '{routing,selected_builder,builder_key}');
  if v_builder_key is null then raise exception 'Approved App Spec has no selected builder'; end if;

  select * into v_builder from public.builder_registry where builder_key=v_builder_key and status='active';
  if not found then raise exception 'Selected builder is not active'; end if;

  v_dispatch := jsonb_build_object(
    'contract_version','1.0',
    'factory_run_id',r.id,
    'project_id',r.project_id,
    'app_spec_id',r.app_spec_id,
    'builder_key',v_builder.builder_key,
    'runtime',v_builder.runtime,
    'targets',v_builder.targets,
    'target_environment',r.target_environment,
    'production_locked',r.production_locked,
    'spec',a.spec
  );

  update public.factory_runs
  set state='planning', started_at=coalesce(started_at,now()),
      plan = coalesce(plan,'{}'::jsonb) || jsonb_build_object('dispatch',v_dispatch,'execution_engine','v1')
  where id=r.id;

  update public.workflows set state='running', started_at=coalesce(started_at,now()) where id=r.workflow_id and state='queued';

  insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
  values(r.id,r.project_id,'prepared','queued','planning',v_dispatch);

  return jsonb_build_object('decision','prepared','dispatch',v_dispatch,'state','planning');
end;
$$;

create or replace function private.mark_factory_build_started(p_factory_run_id uuid, p_adapter_metadata jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare r public.factory_runs%rowtype;
begin
  select * into r from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'Factory run not found'; end if;
  if r.state <> 'planning' then raise exception 'Factory run must be planning'; end if;
  update public.factory_runs set state='building', result=coalesce(result,'{}'::jsonb)||jsonb_build_object('adapter',p_adapter_metadata) where id=r.id;
  insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
  values(r.id,r.project_id,'build_started','planning','building',p_adapter_metadata);
  return jsonb_build_object('decision','building','state','building');
end;
$$;

create or replace function private.record_factory_artifact(
  p_factory_run_id uuid,
  p_artifact_type text,
  p_name text,
  p_storage_path text default null,
  p_sha256 text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare r public.factory_runs%rowtype; v_id uuid;
begin
  select * into r from public.factory_runs where id=p_factory_run_id;
  if not found then raise exception 'Factory run not found'; end if;
  if r.state not in ('building','validating') then raise exception 'Artifacts may only be recorded during building/validating'; end if;
  insert into public.factory_artifacts(factory_run_id,project_id,artifact_type,name,storage_path,sha256,metadata)
  values(r.id,r.project_id,p_artifact_type,p_name,p_storage_path,p_sha256,p_metadata)
  returning id into v_id;
  insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
  values(r.id,r.project_id,'artifact_recorded',r.state,r.state,jsonb_build_object('artifact_id',v_id,'artifact_type',p_artifact_type,'name',p_name));
  return v_id;
end;
$$;

create or replace function private.begin_factory_validation(p_factory_run_id uuid, p_build_result jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare r public.factory_runs%rowtype;
begin
  select * into r from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'Factory run not found'; end if;
  if r.state <> 'building' then raise exception 'Factory run must be building'; end if;
  update public.factory_runs set state='validating', result=coalesce(result,'{}'::jsonb)||jsonb_build_object('build',p_build_result) where id=r.id;
  insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
  values(r.id,r.project_id,'validation_started','building','validating',p_build_result);
  return jsonb_build_object('decision','validating','state','validating');
end;
$$;

create or replace function private.complete_factory_validation(p_factory_run_id uuid, p_pass boolean, p_qa jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare r public.factory_runs%rowtype;
begin
  select * into r from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'Factory run not found'; end if;
  if r.state <> 'validating' then raise exception 'Factory run must be validating'; end if;

  if p_pass then
    update public.factory_runs
    set state='awaiting_approval', result=coalesce(result,'{}'::jsonb)||jsonb_build_object('qa',p_qa,'technical_certification','PASS')
    where id=r.id;
    update public.workflows set state='waiting_approval', output=coalesce(output,'{}'::jsonb)||jsonb_build_object('qa',p_qa) where id=r.workflow_id;
    insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
    values(r.id,r.project_id,'validation_passed','validating','awaiting_approval',p_qa);
    return jsonb_build_object('decision','awaiting_approval','state','awaiting_approval','production_locked',r.production_locked);
  else
    update public.factory_runs set state='failed', error_text='Factory validation failed', finished_at=now(), result=coalesce(result,'{}'::jsonb)||jsonb_build_object('qa',p_qa,'technical_certification','FAIL') where id=r.id;
    update public.workflows set state='failed', finished_at=now(), output=coalesce(output,'{}'::jsonb)||jsonb_build_object('qa',p_qa) where id=r.workflow_id;
    insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
    values(r.id,r.project_id,'validation_failed','validating','failed',p_qa);
    return jsonb_build_object('decision','failed','state','failed');
  end if;
end;
$$;

revoke all on function private.prepare_factory_execution(uuid) from public, anon, authenticated;
revoke all on function private.mark_factory_build_started(uuid,jsonb) from public, anon, authenticated;
revoke all on function private.record_factory_artifact(uuid,text,text,text,text,jsonb) from public, anon, authenticated;
revoke all on function private.begin_factory_validation(uuid,jsonb) from public, anon, authenticated;
revoke all on function private.complete_factory_validation(uuid,boolean,jsonb) from public, anon, authenticated;
grant execute on function private.prepare_factory_execution(uuid) to service_role;
grant execute on function private.mark_factory_build_started(uuid,jsonb) to service_role;
grant execute on function private.record_factory_artifact(uuid,text,text,text,text,jsonb) to service_role;
grant execute on function private.begin_factory_validation(uuid,jsonb) to service_role;
grant execute on function private.complete_factory_validation(uuid,boolean,jsonb) to service_role;;
