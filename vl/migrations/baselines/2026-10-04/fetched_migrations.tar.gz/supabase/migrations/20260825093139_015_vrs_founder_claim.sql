create table if not exists public.system_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('founder','admin')),
  claimed_at timestamptz not null default now()
);

alter table public.system_roles enable row level security;
revoke all on public.system_roles from anon, authenticated;
grant select on public.system_roles to authenticated;

create policy system_roles_select_self
on public.system_roles
for select
to authenticated
using ((select auth.uid()) = user_id);

create or replace function public.claim_founder()
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_uid uuid := auth.uid();
  v_user_count bigint;
  v_existing bigint;
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;

  select count(*) into v_existing from public.system_roles where role = 'founder';
  if v_existing > 0 then
    raise exception 'Founder already claimed';
  end if;

  select count(*) into v_user_count from auth.users where deleted_at is null;
  if v_user_count <> 1 then
    raise exception 'Founder claim requires exactly one active Auth user; found %', v_user_count;
  end if;

  if not exists (select 1 from auth.users where id = v_uid and deleted_at is null) then
    raise exception 'Authenticated user is not an active Auth user';
  end if;

  insert into public.system_roles(user_id, role)
  values (v_uid, 'founder')
  on conflict (user_id) do update set role = excluded.role;

  insert into public.profiles(user_id, display_name)
  values (v_uid, coalesce((select raw_user_meta_data->>'full_name' from auth.users where id=v_uid), 'Founder'))
  on conflict (user_id) do nothing;

  return jsonb_build_object('user_id', v_uid, 'role', 'founder', 'claimed', true);
end;
$$;

revoke all on function public.claim_founder() from public, anon;
grant execute on function public.claim_founder() to authenticated;

comment on function public.claim_founder() is 'One-time VRS founder claim. Requires authenticated user and exactly one active Auth account.';;
