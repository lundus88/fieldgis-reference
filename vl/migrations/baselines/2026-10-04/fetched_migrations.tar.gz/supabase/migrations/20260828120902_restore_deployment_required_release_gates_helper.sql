create or replace function private.get_deployment_required_release_gates(p_deployment_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_factory_run_id uuid;
begin
  select d.factory_run_id into v_factory_run_id
  from public.deployments d
  where d.id = p_deployment_id;

  if v_factory_run_id is null then
    raise exception 'deployment not found';
  end if;

  return private.get_required_release_gates(v_factory_run_id);
end;
$$;

revoke all on function private.get_deployment_required_release_gates(uuid) from public, anon, authenticated;
grant execute on function private.get_deployment_required_release_gates(uuid) to service_role;;
