create or replace function private.resolve_capability_adapter_plan(p_normalized_spec jsonb, p_module_plan jsonb)
returns jsonb
language plpgsql
security definer
set search_path = private, public, pg_temp
as $$
declare
  v_plan jsonb := '[]'::jsonb;
  v_auth boolean := coalesce((p_normalized_spec->>'auth')::boolean, true);
  v_storage boolean := coalesce((p_normalized_spec->>'storage')::boolean, false)
    or exists (select 1 from jsonb_array_elements(coalesce(p_module_plan,'[]'::jsonb)) m where m->>'type'='storage');
  v_billing boolean := coalesce((p_normalized_spec->>'billing')::boolean, false);
  r record;
begin
  if v_auth then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='auth' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','auth','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','auth','resolution','missing','blocking',true));
    end if;
  end if;

  if v_storage then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='storage' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','storage','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','storage','resolution','missing','blocking',true));
    end if;
  end if;

  if v_billing then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='payment' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','billing','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','billing','resolution','missing','blocking',true,'reason','No certified/candidate payment adapter available'));
    end if;
  end if;

  return v_plan;
end;
$$;

revoke all on function private.resolve_capability_adapter_plan(jsonb,jsonb) from public, anon, authenticated;
grant execute on function private.resolve_capability_adapter_plan(jsonb,jsonb) to service_role;

create or replace function private.set_spec_compilation_capability_plan()
returns trigger
language plpgsql
security definer
set search_path = private, public, pg_temp
as $$
begin
  new.capability_adapter_plan := private.resolve_capability_adapter_plan(new.normalized_spec,new.module_plan);
  return new;
end;
$$;

drop trigger if exists trg_spec_compilation_capability_plan on public.spec_compilations;
create trigger trg_spec_compilation_capability_plan
before insert or update of normalized_spec,module_plan on public.spec_compilations
for each row execute function private.set_spec_compilation_capability_plan();

create or replace function private.enrich_factory_run_capability_plan()
returns trigger
language plpgsql
security definer
set search_path = private, public, pg_temp
as $$
declare v_compilation_id uuid; v_adapters jsonb;
begin
  begin v_compilation_id := nullif(new.input->>'compilation_id','')::uuid; exception when others then v_compilation_id := null; end;
  if v_compilation_id is not null then
    select capability_adapter_plan into v_adapters from public.spec_compilations where id=v_compilation_id;
    if v_adapters is not null then
      new.plan := coalesce(new.plan,'{}'::jsonb) || jsonb_build_object('capability_adapters',v_adapters);
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_factory_run_capability_plan on public.factory_runs;
create trigger trg_factory_run_capability_plan
before insert or update of input,plan on public.factory_runs
for each row execute function private.enrich_factory_run_capability_plan();

update public.spec_compilations
set capability_adapter_plan = private.resolve_capability_adapter_plan(normalized_spec,module_plan);
;
