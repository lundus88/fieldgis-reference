create or replace function private.resolve_capability_adapter_plan(p_normalized_spec jsonb, p_module_plan jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_plan jsonb := '[]'::jsonb;
  v_auth boolean := coalesce((p_normalized_spec->>'auth')::boolean, true);
  v_storage boolean := coalesce((p_normalized_spec->>'storage')::boolean, false)
    or exists (select 1 from jsonb_array_elements(coalesce(p_module_plan,'[]'::jsonb)) m where m->>'type'='storage');
  v_database boolean := exists (select 1 from jsonb_array_elements(coalesce(p_module_plan,'[]'::jsonb)) m where m->>'type'='database');
  v_billing boolean := coalesce((p_normalized_spec->>'billing')::boolean, false);
  v_notification boolean := exists (select 1 from jsonb_array_elements(coalesce(p_module_plan,'[]'::jsonb)) m where m->>'type'='notification')
    or lower(coalesce(p_normalized_spec->'features','[]'::jsonb)::text || ' ' || coalesce(p_normalized_spec->'integrations','[]'::jsonb)::text || ' ' || coalesce(p_normalized_spec->'workflows','[]'::jsonb)::text) ~ '(notification|notify|email|resend)';
  r record;
begin
  if v_database then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='database' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','database','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','database','resolution','missing','blocking',true,'reason','No certified/candidate database adapter available'));
    end if;
  end if;

  if v_auth then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='auth' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','auth','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','auth','resolution','missing','blocking',true));
    end if;
  end if;

  if v_storage then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='storage' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','storage','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','storage','resolution','missing','blocking',true));
    end if;
  end if;

  if v_notification then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='notification' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','notification','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','notification','resolution','missing','blocking',true,'reason','No certified/candidate notification adapter available'));
    end if;
  end if;

  if v_billing then
    select adapter_key,provider,version,status,required_gates into r
    from private.capability_adapter_registry
    where adapter_type='payment' and status in ('candidate','active')
    order by case status when 'active' then 0 else 1 end, updated_at desc limit 1;
    if found then
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','billing','adapter_key',r.adapter_key,'provider',r.provider,'version',r.version,'adapter_status',r.status,'required_gates',r.required_gates,'resolution','resolved'));
    else
      v_plan := v_plan || jsonb_build_array(jsonb_build_object('module','billing','resolution','missing','blocking',true,'reason','No certified/candidate payment adapter available'));
    end if;
  end if;

  return v_plan;
end;
$$;

revoke all on function private.resolve_capability_adapter_plan(jsonb,jsonb) from public,anon,authenticated;
grant execute on function private.resolve_capability_adapter_plan(jsonb,jsonb) to service_role;;
