update private.builder_release_gate_profiles
set required_gates = case
  when exists (select 1 from jsonb_array_elements(required_gates) g where g->>'key'='api_compile_test') then required_gates
  else required_gates || jsonb_build_array(jsonb_build_object('key','api_compile_test','type','qa'))
end,
updated_at=now()
where builder_key='api-service-v1';;
