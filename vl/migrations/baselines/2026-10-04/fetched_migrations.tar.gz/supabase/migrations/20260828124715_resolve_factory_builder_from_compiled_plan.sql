create or replace function private.resolve_factory_builder(p_factory_run_id uuid)
returns text
language plpgsql
set search_path to 'private','public','pg_temp'
as $$
declare
  v_builder text;
  v_input jsonb;
  v_plan jsonb;
  v_status text;
begin
  select input, plan into v_input, v_plan from public.factory_runs where id=p_factory_run_id;
  if not found then return null; end if;

  v_builder := nullif(v_input->>'builder_key','');

  if v_builder is null then
    v_builder := nullif(v_plan#>>'{builders,0,key}','');
  end if;

  if v_builder is null then
    if exists(select 1 from public.build_steps where factory_run_id=p_factory_run_id and step_key ilike '%mobile-flutter%')
       or coalesce(v_plan::text,'') ilike '%mobile-flutter%' then
      v_builder := 'mobile-flutter-v1';
    elsif exists(select 1 from public.build_steps where factory_run_id=p_factory_run_id and step_key ilike '%gis-web%')
       or (coalesce(v_plan::text,'') ilike '%gis%' and coalesce(v_plan::text,'') ilike '%web%') then
      v_builder := 'gis-web-v1';
    end if;
  end if;

  if v_builder is null then return null; end if;
  select status into v_status from public.builder_registry where builder_key=v_builder;
  if v_status='active' then return v_builder; end if;
  if v_status='experimental'
     and coalesce((v_input->>'allow_experimental_builder')::boolean,false)=true
     and v_builder in ('ai-app-v1','desktop-tauri-v1') then
    return v_builder;
  end if;
  return null;
end;
$$;

revoke all on function private.resolve_factory_builder(uuid) from public, anon, authenticated;
grant execute on function private.resolve_factory_builder(uuid) to service_role;;
