create table public.audit_logs (
  id bigint generated always as identity primary key,
  organization_id uuid references public.organizations(id) on delete cascade,
  project_id uuid references public.projects(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index audit_logs_org_idx on public.audit_logs(organization_id,created_at desc);
create index audit_logs_project_idx on public.audit_logs(project_id,created_at desc);
create index audit_logs_actor_idx on public.audit_logs(actor_user_id,created_at desc);

alter table public.audit_logs enable row level security;

create policy audit_logs_select_member on public.audit_logs for select to authenticated using (
  (project_id is not null and private.is_project_member(project_id))
  or (project_id is null and organization_id is not null and private.is_org_member(organization_id))
);
create policy audit_logs_insert_member on public.audit_logs for insert to authenticated with check (
  actor_user_id=(select auth.uid()) and (
    (project_id is not null and private.is_project_member(project_id))
    or (project_id is null and organization_id is not null and private.is_org_member(organization_id))
  )
);

grant select,insert on public.audit_logs to authenticated;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('vrs-private','vrs-private',false,52428800,null)
on conflict (id) do update set public=false;

create policy vrs_private_select on storage.objects for select to authenticated using (
  bucket_id='vrs-private'
  and (storage.foldername(name))[1] is not null
  and private.is_project_member(((storage.foldername(name))[1])::uuid)
);
create policy vrs_private_insert on storage.objects for insert to authenticated with check (
  bucket_id='vrs-private'
  and (storage.foldername(name))[1] is not null
  and private.has_project_role(((storage.foldername(name))[1])::uuid,array['owner','admin','builder'])
);
create policy vrs_private_update on storage.objects for update to authenticated using (
  bucket_id='vrs-private'
  and (storage.foldername(name))[1] is not null
  and private.has_project_role(((storage.foldername(name))[1])::uuid,array['owner','admin','builder'])
) with check (
  bucket_id='vrs-private'
  and (storage.foldername(name))[1] is not null
  and private.has_project_role(((storage.foldername(name))[1])::uuid,array['owner','admin','builder'])
);
create policy vrs_private_delete on storage.objects for delete to authenticated using (
  bucket_id='vrs-private'
  and (storage.foldername(name))[1] is not null
  and private.has_project_role(((storage.foldername(name))[1])::uuid,array['owner','admin'])
);;
