create or replace function private.enforce_factory_artifact_immutability()
returns trigger
language plpgsql
security definer
set search_path = private, public, pg_temp
as $function$
declare
  v_referenced boolean := false;
  v_run_state text;
  v_old_base jsonb;
  v_new_base jsonb;
  v_old_id text;
  v_new_id text;
  v_old_digest text;
  v_new_digest text;
  v_old_exp text;
  v_new_exp text;
  v_old_reconciled_at text;
  v_new_reconciled_at text;
  v_old_source text;
  v_new_source text;
begin
  if tg_op='INSERT' then
    if new.sha256 is not null and new.sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'factory artifact sha256 must be a valid SHA-256 hex digest'; end if;
    return new;
  end if;

  select exists(
    select 1 from public.deployments d
    where d.factory_run_id=old.factory_run_id
      and lower(coalesce(d.artifact_sha256,''))=lower(coalesce(old.sha256,''))
      and d.status in ('planned','certified','approved','deploying','deployed')
  ) into v_referenced;
  select state into v_run_state from public.factory_runs where id=old.factory_run_id;

  if tg_op='DELETE' then
    if v_referenced then raise exception 'immutable factory artifact: artifact is referenced by a release deployment'; end if;
    if v_run_state not in ('queued','building','validating','failed') then raise exception 'immutable factory artifact: deletion not allowed after factory run leaves mutable states'; end if;
    return old;
  end if;

  if new.factory_run_id is distinct from old.factory_run_id
     or new.project_id is distinct from old.project_id
     or new.artifact_type is distinct from old.artifact_type
     or new.name is distinct from old.name
     or new.storage_path is distinct from old.storage_path
     or new.sha256 is distinct from old.sha256
     or new.created_at is distinct from old.created_at then
    if v_referenced then raise exception 'immutable factory artifact: release-bound identity/content fields cannot be changed'; end if;
    if v_run_state not in ('building','validating') then raise exception 'immutable factory artifact: identity/content fields may only change during building/validating'; end if;
  end if;

  if v_referenced and new.metadata is distinct from old.metadata then
    v_old_id:=nullif(old.metadata->>'github_artifact_id','');
    v_new_id:=nullif(new.metadata->>'github_artifact_id','');
    v_old_digest:=nullif(old.metadata->>'github_artifact_digest','');
    v_new_digest:=nullif(new.metadata->>'github_artifact_digest','');
    v_old_exp:=nullif(old.metadata->>'github_artifact_expires_at','');
    v_new_exp:=nullif(new.metadata->>'github_artifact_expires_at','');
    v_old_reconciled_at:=nullif(old.metadata->>'physical_provenance_reconciled_at','');
    v_new_reconciled_at:=nullif(new.metadata->>'physical_provenance_reconciled_at','');
    v_old_source:=nullif(old.metadata->>'physical_provenance_source','');
    v_new_source:=nullif(new.metadata->>'physical_provenance_source','');

    v_old_base:=coalesce(old.metadata,'{}'::jsonb)
      -'github_artifact_id'
      -'github_artifact_digest'
      -'github_artifact_expires_at'
      -'github_head_sha'
      -'github_artifact_verified_at'
      -'physical_provenance_reconciled_at'
      -'physical_provenance_source';
    v_new_base:=coalesce(new.metadata,'{}'::jsonb)
      -'github_artifact_id'
      -'github_artifact_digest'
      -'github_artifact_expires_at'
      -'github_head_sha'
      -'github_artifact_verified_at'
      -'physical_provenance_reconciled_at'
      -'physical_provenance_source';

    if v_old_base is distinct from v_new_base then raise exception 'immutable factory artifact: release-bound metadata cannot change'; end if;

    if v_old_id is not null or v_old_digest is not null or v_old_exp is not null
       or v_old_reconciled_at is not null or v_old_source is not null then
      raise exception 'immutable factory artifact: physical provenance is write-once';
    end if;

    if v_new_id is null or v_new_id !~ '^[0-9]+$' then raise exception 'github artifact id required for physical provenance'; end if;
    if v_new_digest is null or v_new_digest !~ '^sha256:[0-9a-fA-F]{64}$' then raise exception 'github artifact digest required for physical provenance'; end if;
    if v_new_exp is null then raise exception 'github artifact expiry required for physical provenance'; end if;
    if v_new_reconciled_at is null then raise exception 'physical provenance reconciliation timestamp required'; end if;
    if v_new_source is null then raise exception 'physical provenance reconciliation source required'; end if;
  end if;

  if new.sha256 is not null and new.sha256 !~ '^[0-9a-fA-F]{64}$' then raise exception 'factory artifact sha256 must be a valid SHA-256 hex digest'; end if;
  return new;
end
$function$;;
