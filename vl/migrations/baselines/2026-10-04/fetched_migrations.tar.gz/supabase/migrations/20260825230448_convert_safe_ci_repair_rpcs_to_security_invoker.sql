alter function public.propose_ci_repair(uuid,uuid,text,text,text,text,text,text) security invoker;
alter function public.mark_ci_repair_applied(uuid,jsonb) security invoker;
alter function public.mark_ci_repair_retry(uuid,text) security invoker;
alter function public.verify_ci_repair(uuid,boolean,jsonb) security invoker;;
