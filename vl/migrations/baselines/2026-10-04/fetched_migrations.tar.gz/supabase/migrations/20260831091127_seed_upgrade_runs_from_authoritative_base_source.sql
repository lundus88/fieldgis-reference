create or replace function private.seed_upgrade_source_from_base(
  p_upgrade_run_id uuid,
  p_base_run_id uuid,
  p_change_request text
) returns jsonb
language plpgsql
security definer
set search_path to 'private','public','extensions','pg_temp'
as $$
declare
  v_upgrade public.factory_runs%rowtype;
  v_base public.factory_runs%rowtype;
  v_base_manifest jsonb := '{}'::jsonb;
  v_manifest jsonb;
  v_change jsonb;
  v_count integer;
begin
  select * into v_upgrade from public.factory_runs where id=p_upgrade_run_id;
  select * into v_base from public.factory_runs where id=p_base_run_id;
  if not found or v_upgrade.id is null or v_base.id is null then raise exception 'upgrade/base run not found'; end if;
  if v_upgrade.run_type<>'upgrade' or v_upgrade.base_factory_run_id is distinct from v_base.id then raise exception 'invalid upgrade lineage'; end if;
  if coalesce(v_base.result->>'runner_status','')<>'PASS' then raise exception 'base run must have runner PASS'; end if;

  select content::jsonb into v_base_manifest
  from public.generated_artifacts
  where factory_run_id=v_base.id and path='vrs/factory-source-manifest.json'
  limit 1;
  v_base_manifest:=coalesce(v_base_manifest,'{}'::jsonb);

  delete from public.generated_artifacts where factory_run_id=v_upgrade.id;

  insert into public.generated_artifacts(factory_run_id,project_id,artifact_kind,path,content,sha256,metadata)
  select v_upgrade.id,v_upgrade.project_id,ga.artifact_kind,ga.path,ga.content,ga.sha256,
         ga.metadata || jsonb_build_object(
           'upgrade_inherited',true,
           'upgrade_base_factory_run_id',v_base.id,
           'upgrade_base_artifact_sha256',coalesce(v_base.result#>>'{runner,artifact_sha256}','')
         )
  from public.generated_artifacts ga
  where ga.factory_run_id=v_base.id and ga.path<>'vrs/factory-source-manifest.json';
  get diagnostics v_count=row_count;

  v_change:=jsonb_build_object(
    'schema','vrs.upgrade-change-request/1',
    'upgrade_factory_run_id',v_upgrade.id,
    'base_factory_run_id',v_base.id,
    'base_app_spec_id',v_base.app_spec_id,
    'upgrade_app_spec_id',v_upgrade.app_spec_id,
    'change_request',p_change_request,
    'change_application_status','pending'
  );

  insert into public.generated_artifacts(factory_run_id,project_id,artifact_kind,path,content,sha256,metadata)
  values(v_upgrade.id,v_upgrade.project_id,'manifest','vrs/upgrade-change-request.json',v_change::text,
         encode(digest(convert_to(v_change::text,'UTF8'),'sha256'),'hex'),
         jsonb_build_object('upgrade_contract',true,'change_applied',false));

  v_manifest:=v_base_manifest || jsonb_build_object(
    'revision',jsonb_build_object(
      'kind','upgrade',
      'base_factory_run_id',v_base.id,
      'upgrade_factory_run_id',v_upgrade.id,
      'change_request_manifest','vrs/upgrade-change-request.json',
      'source_inheritance','authoritative_base_copy',
      'change_application_status','pending'
    )
  );

  insert into public.generated_artifacts(factory_run_id,project_id,artifact_kind,path,content,sha256,metadata)
  values(v_upgrade.id,v_upgrade.project_id,'manifest','vrs/factory-source-manifest.json',v_manifest::text,
         encode(digest(convert_to(v_manifest::text,'UTF8'),'sha256'),'hex'),
         jsonb_build_object('upgrade_contract',true,'upgrade_base_factory_run_id',v_base.id,'change_applied',false));

  return jsonb_build_object('decision','upgrade_source_seeded','base_factory_run_id',v_base.id,'upgrade_factory_run_id',v_upgrade.id,'inherited_artifact_count',v_count,'change_application_status','pending');
end;
$$;

revoke all on function private.seed_upgrade_source_from_base(uuid,uuid,text) from public,anon,authenticated;;
