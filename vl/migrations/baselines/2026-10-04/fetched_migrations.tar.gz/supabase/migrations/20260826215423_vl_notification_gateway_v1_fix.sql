insert into private.capability_adapter_registry(adapter_key,adapter_type,provider,version,status,capabilities,required_gates,configuration)
values
('notification-gateway-v1','notification','unbound','1.0.0','experimental',
 '{"email":true,"webhook":true,"idempotency":true,"delivery_tracking":true,"bounce_tracking":true,"provider_binding_required":true,"production_send_allowed":false}'::jsonb,
 '["notification_send_sandbox","notification_webhook_signature","notification_idempotency","notification_delivery_event","notification_bounce_event","notification_reconciliation"]'::jsonb,
 '{"provider_bound":false,"sandbox_credentials_configured":false,"production_send_allowed":false}'::jsonb),
('resend-email-v1','notification','resend','1.0.0','experimental',
 '{"email":true,"webhook":true,"idempotency":true,"delivery_tracking":true,"bounce_tracking":true,"provider_binding_required":false,"production_send_allowed":false}'::jsonb,
 '["notification_send_sandbox","notification_webhook_signature","notification_idempotency","notification_delivery_event","notification_bounce_event","notification_reconciliation"]'::jsonb,
 '{"provider_bound":true,"sandbox_credentials_configured":false,"production_send_allowed":false,"delivery_mode":"email"}'::jsonb)
on conflict (adapter_key) do update set
  capabilities=excluded.capabilities,
  required_gates=excluded.required_gates,
  configuration=excluded.configuration,
  updated_at=now();

create table if not exists private.notification_outbox (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key),
  channel text not null check (channel in ('email')),
  recipient_hash text not null,
  template_key text,
  subject text,
  provider_message_id text unique,
  idempotency_key text not null unique,
  environment text not null default 'sandbox' check (environment in ('sandbox','development','staging')),
  status text not null default 'queued' check (status in ('queued','sent','delivered','bounced','failed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists private.notification_events (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key),
  provider_message_id text,
  event_key text not null unique,
  event_type text not null,
  signature_valid boolean not null,
  payload_sha256 text not null,
  duplicate boolean not null default false,
  applied boolean not null default false,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists private.notification_reconciliation_checks (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null references private.capability_adapter_registry(adapter_key),
  outbox_id uuid not null references private.notification_outbox(id),
  expected_status text not null,
  provider_status text,
  status text not null check (status in ('pass','fail','blocked')),
  evidence jsonb not null default '{}'::jsonb,
  checked_at timestamptz not null default now()
);

alter table private.notification_outbox enable row level security;
alter table private.notification_events enable row level security;
alter table private.notification_reconciliation_checks enable row level security;
revoke all on private.notification_outbox from public,anon,authenticated;
revoke all on private.notification_events from public,anon,authenticated;
revoke all on private.notification_reconciliation_checks from public,anon,authenticated;
grant select,insert,update,delete on private.notification_outbox to service_role;
grant select,insert,update,delete on private.notification_events to service_role;
grant select,insert,update,delete on private.notification_reconciliation_checks to service_role;

comment on table private.notification_outbox is 'VL notification outbox; stores hashed recipients and provider message ids, not provider secrets.';
comment on table private.notification_events is 'VL sanitized notification delivery event ledger for signed webhook and idempotency evidence.';;
