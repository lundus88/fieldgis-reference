create or replace function public.claim_vrs_experimental_runner_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $function$
declare
  j private.runner_jobs%rowtype;
  v_lease uuid := gen_random_uuid();
  v_spec jsonb;
  v_artifacts jsonb;
  v_run public.factory_runs%rowtype;
  v_status text;
begin
  select rj.* into j
  from private.runner_jobs rj
  join public.builder_registry br on br.builder_key=rj.builder_key
  where rj.builder_key in ('ai-app-v1','desktop-tauri-v1')
    and br.status='experimental'
    and (rj.state='queued' or (rj.state='leased' and rj.lease_expires_at < now()))
    and rj.attempts < rj.max_attempts
  order by rj.created_at
  for update of rj skip locked
  limit 1;

  if not found then return jsonb_build_object('status','idle'); end if;

  update private.runner_jobs
  set state='leased', attempts=attempts+1, lease_token=v_lease,
      leased_at=now(), lease_expires_at=now()+interval '20 minutes',
      runner_identity=coalesce(p_runner_identity,'{}'::jsonb), updated_at=now()
  where id=j.id returning * into j;

  select * into v_run from public.factory_runs where id=j.factory_run_id;
  select status into v_status from public.builder_registry where builder_key=j.builder_key;
  if v_run.target_environment='production'
     or v_run.production_locked is distinct from true
     or coalesce((v_run.input->>'allow_experimental_builder')::boolean,false) is distinct from true
     or v_status<>'experimental' then
    update private.runner_jobs set state='failed',error_text='experimental execution boundary rejected',finished_at=now(),updated_at=now() where id=j.id;
    return jsonb_build_object('status','rejected','reason','experimental_execution_boundary_rejected');
  end if;

  select jsonb_build_object(
    'id',a.id,'title',a.title,'objective',a.objective,'spec',a.spec,
    'software_kind',a.software_kind,'target_platforms',a.target_platforms,'status',a.status
  ) into v_spec from public.app_specs a where a.id=v_run.app_spec_id;

  select coalesce(jsonb_agg(jsonb_build_object(
    'path',g.path,'content',g.content,'sha256',g.sha256,'artifact_kind',g.artifact_kind,'metadata',g.metadata
  ) order by g.path),'[]'::jsonb)
  into v_artifacts
  from public.generated_artifacts g where g.factory_run_id=j.factory_run_id;

  return jsonb_build_object(
    'status','leased','job_id',j.id,'lease_token',v_lease,'factory_run_id',j.factory_run_id,
    'builder_key',j.builder_key,'attempt',j.attempts,'max_attempts',j.max_attempts,
    'app_spec',v_spec,'generated_artifacts',v_artifacts,
    'target_environment',v_run.target_environment,'production_locked',v_run.production_locked,
    'experimental',true,'network_policy','restricted_by_workflow','credential_policy','no_control_plane_token_during_build'
  );
end;
$function$;

revoke all on function public.claim_vrs_experimental_runner_job(jsonb) from public,anon,authenticated;
grant execute on function public.claim_vrs_experimental_runner_job(jsonb) to service_role;;
