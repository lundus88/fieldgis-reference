create table if not exists private.payment_production_orders (
  id uuid primary key default gen_random_uuid(),
  adapter_key text not null default 'billplz-payment-v1',
  provider_bill_id text unique,
  merchant_reference text not null unique,
  amount_minor integer not null check (amount_minor > 0),
  currency text not null default 'MYR' check (currency='MYR'),
  environment text not null default 'production' check (environment='production'),
  purpose text not null default 'controlled_live_test',
  status text not null default 'pending' check (status in ('pending','paid','cancelled','failed')),
  fulfillment_state text not null default 'unfulfilled' check (fulfillment_state in ('unfulfilled','fulfilled','blocked')),
  checkout_url text,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  paid_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists private.payment_production_webhook_events (
  id uuid primary key default gen_random_uuid(),
  event_key text not null unique,
  provider_bill_id text,
  payload_sha256 text not null,
  signature_valid boolean not null,
  normalized_status text,
  amount_minor integer,
  applied boolean not null default false,
  duplicate boolean not null default false,
  error_text text,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists private.payment_production_fulfillment_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references private.payment_production_orders(id),
  action_key text not null unique,
  status text not null check (status in ('fulfilled','blocked')),
  reason text,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists payment_production_fulfillment_events_order_id_idx on private.payment_production_fulfillment_events(order_id);

alter table private.payment_production_orders enable row level security;
alter table private.payment_production_webhook_events enable row level security;
alter table private.payment_production_fulfillment_events enable row level security;
revoke all on private.payment_production_orders from public, anon, authenticated;
revoke all on private.payment_production_webhook_events from public, anon, authenticated;
revoke all on private.payment_production_fulfillment_events from public, anon, authenticated;
grant all on private.payment_production_orders to service_role;
grant all on private.payment_production_webhook_events to service_role;
grant all on private.payment_production_fulfillment_events to service_role;

create or replace function public.vl_apply_billplz_production_test_webhook(
  p_event_key text,
  p_provider_bill_id text,
  p_payload_sha256 text,
  p_normalized_status text,
  p_amount_minor integer
) returns jsonb
language plpgsql
security definer
set search_path=private,public,pg_temp
as $$
declare
  v_order private.payment_production_orders%rowtype;
  v_event private.payment_production_webhook_events%rowtype;
  v_duplicate boolean:=false;
begin
  if current_user not in ('service_role','postgres') then raise exception 'service role required'; end if;
  select * into v_order from private.payment_production_orders where provider_bill_id=p_provider_bill_id for update;
  if not found then raise exception 'unknown production test bill'; end if;
  if v_order.purpose<>'controlled_live_test' or v_order.amount_minor<>100 or v_order.currency<>'MYR' then raise exception 'production test invariant failed'; end if;
  if p_amount_minor<>v_order.amount_minor then raise exception 'amount mismatch'; end if;

  select * into v_event from private.payment_production_webhook_events where event_key=p_event_key;
  if found then
    return jsonb_build_object('ok',true,'duplicate',true,'applied',v_event.applied,'status',v_order.status,'order_id',v_order.id);
  end if;

  insert into private.payment_production_webhook_events(event_key,provider_bill_id,payload_sha256,signature_valid,normalized_status,amount_minor,applied,duplicate,metadata)
  values(p_event_key,p_provider_bill_id,p_payload_sha256,true,p_normalized_status,p_amount_minor,false,false,jsonb_build_object('environment','production','purpose','controlled_live_test'))
  returning * into v_event;

  if p_normalized_status='paid' then
    update private.payment_production_orders set status='paid',paid_at=coalesce(paid_at,now()),updated_at=now() where id=v_order.id;
    insert into private.payment_production_fulfillment_events(order_id,action_key,status,evidence)
    values(v_order.id,'billplz-production-test:'||v_order.id::text,'fulfilled',jsonb_build_object('payment_status','paid','amount_minor',100,'currency','MYR','provider_bill_id',p_provider_bill_id,'exactly_once',true))
    on conflict(action_key) do nothing;
    update private.payment_production_orders set fulfillment_state='fulfilled',updated_at=now() where id=v_order.id;
  elsif p_normalized_status='cancelled' then
    update private.payment_production_orders set status='cancelled',updated_at=now() where id=v_order.id;
  end if;

  update private.payment_production_webhook_events set applied=true,processed_at=now() where id=v_event.id;
  return jsonb_build_object('ok',true,'duplicate',false,'applied',true,'status',p_normalized_status,'order_id',v_order.id);
end$$;

create or replace function public.vl_record_invalid_billplz_production_test_webhook(
  p_event_key text,
  p_provider_bill_id text,
  p_payload_sha256 text,
  p_normalized_status text,
  p_amount_minor integer
) returns jsonb
language plpgsql
security definer
set search_path=private,public,pg_temp
as $$
begin
  if current_user not in ('service_role','postgres') then raise exception 'service role required'; end if;
  insert into private.payment_production_webhook_events(event_key,provider_bill_id,payload_sha256,signature_valid,normalized_status,amount_minor,applied,duplicate,error_text,metadata)
  values(p_event_key,p_provider_bill_id,p_payload_sha256,false,p_normalized_status,p_amount_minor,false,false,'invalid signature',jsonb_build_object('environment','production','purpose','controlled_live_test'))
  on conflict(event_key) do nothing;
  return jsonb_build_object('ok',true,'recorded',true);
end$$;

revoke all on function public.vl_apply_billplz_production_test_webhook(text,text,text,text,integer) from public,anon,authenticated;
revoke all on function public.vl_record_invalid_billplz_production_test_webhook(text,text,text,text,integer) from public,anon,authenticated;
grant execute on function public.vl_apply_billplz_production_test_webhook(text,text,text,text,integer) to service_role;
grant execute on function public.vl_record_invalid_billplz_production_test_webhook(text,text,text,text,integer) to service_role;;
