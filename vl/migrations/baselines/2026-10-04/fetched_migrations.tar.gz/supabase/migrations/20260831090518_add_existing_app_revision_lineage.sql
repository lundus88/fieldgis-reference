alter table public.app_specs
  add column if not exists parent_app_spec_id uuid references public.app_specs(id),
  add column if not exists change_request text;

alter table public.factory_runs
  add column if not exists base_factory_run_id uuid references public.factory_runs(id);

create index if not exists idx_app_specs_parent_app_spec_id on public.app_specs(parent_app_spec_id);
create index if not exists idx_factory_runs_base_factory_run_id on public.factory_runs(base_factory_run_id);

create or replace function private.create_app_spec_revision(
  p_base_app_spec_id uuid,
  p_change_request text,
  p_actor uuid
) returns uuid
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_base public.app_specs%rowtype;
  v_new_id uuid;
  v_next_version integer;
  v_spec jsonb;
begin
  if p_actor is null then raise exception 'revision actor required'; end if;
  if nullif(btrim(p_change_request),'') is null then raise exception 'change request required'; end if;

  select * into v_base from public.app_specs where id=p_base_app_spec_id;
  if not found then raise exception 'base app spec not found'; end if;
  if not exists (
    select 1 from public.project_members pm
    where pm.project_id=v_base.project_id and pm.user_id=p_actor and pm.role in ('owner','admin','builder')
  ) then raise exception 'actor is not authorized project member'; end if;

  select coalesce(max(version),0)+1 into v_next_version
  from public.app_specs where project_id=v_base.project_id;

  v_spec := jsonb_set(
    coalesce(v_base.spec,'{}'::jsonb),
    '{revision}',
    jsonb_build_object(
      'kind','upgrade',
      'base_app_spec_id',v_base.id,
      'base_version',v_base.version,
      'change_request',p_change_request,
      'created_at',now()
    ),
    true
  );

  insert into public.app_specs(
    project_id,version,title,objective,spec,status,created_by,software_kind,target_platforms,
    parent_app_spec_id,change_request
  ) values (
    v_base.project_id,v_next_version,v_base.title,
    v_base.objective || E'\n\nRequested revision: ' || p_change_request,
    v_spec,'draft',p_actor,v_base.software_kind,v_base.target_platforms,
    v_base.id,p_change_request
  ) returning id into v_new_id;

  return v_new_id;
end;
$$;

revoke all on function private.create_app_spec_revision(uuid,text,uuid) from public,anon,authenticated;;
