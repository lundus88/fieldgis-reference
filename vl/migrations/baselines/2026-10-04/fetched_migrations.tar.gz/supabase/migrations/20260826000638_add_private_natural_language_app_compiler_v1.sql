create table if not exists private.app_compiler_audit (
  id uuid primary key default gen_random_uuid(),
  prompt text not null,
  inferred_builder_type text,
  inferred_target text,
  inferred_capabilities text[] not null default '{}',
  routing_result jsonb not null default '{}'::jsonb,
  compiled_spec jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

revoke all on private.app_compiler_audit from public, anon, authenticated;
grant select, insert on private.app_compiler_audit to service_role;

create or replace function private.compile_app_request(p_prompt text)
returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare
  v_prompt text := lower(coalesce(p_prompt,''));
  v_builder_type text;
  v_target text;
  v_caps text[] := '{}';
  v_route jsonb;
  v_spec jsonb;
  v_title text;
begin
  if btrim(v_prompt) = '' then
    raise exception 'Prompt must not be empty';
  end if;

  if v_prompt ~ '(android|mobile|flutter|phone|telefon|smartphone)' then
    v_builder_type := 'mobile';
    v_target := 'android';
  elsif v_prompt ~ '(gis|map|mapping|peta|maplibre|geojson|kml)' then
    v_builder_type := 'gis';
    v_target := 'web';
  elsif v_prompt ~ '(api|backend|endpoint|rest|webhook)' then
    v_builder_type := 'api';
    v_target := 'api';
  elsif v_prompt ~ '(web|website|dashboard|portal|saas)' then
    v_builder_type := 'web';
    v_target := 'web';
  else
    v_builder_type := null;
    v_target := null;
  end if;

  if v_prompt ~ '(gps|gnss|location|lokasi|coordinate|coordinates|koordinat)' then v_caps := array_append(v_caps,'gps'); end if;
  if v_prompt ~ '(offline|tanpa internet|no internet)' then v_caps := array_append(v_caps,'offline'); end if;
  if v_prompt ~ '(supabase|database|database sync|sync)' then v_caps := array_append(v_caps,'supabase'); end if;
  if v_prompt ~ '(camera|kamera|photo|gambar)' then v_caps := array_append(v_caps,'camera'); end if;
  if v_prompt ~ '(map|mapping|peta|maplibre)' then v_caps := array_append(v_caps,'map'); end if;
  if v_prompt ~ '(geojson)' then v_caps := array_append(v_caps,'geojson'); end if;
  if v_prompt ~ '(kml)' then v_caps := array_append(v_caps,'kml'); end if;
  if v_prompt ~ '(geospatial|spatial|gis)' then v_caps := array_append(v_caps,'geospatial'); end if;
  if v_prompt ~ '(jwt|authentication|auth)' then v_caps := array_append(v_caps,'jwt'); end if;
  if v_prompt ~ '(rest)' then v_caps := array_append(v_caps,'rest'); end if;

  select coalesce(array_agg(distinct x order by x),'{}'::text[]) into v_caps from unnest(v_caps) x;

  v_route := private.route_builder(v_builder_type,v_target,v_caps);

  v_title := left(regexp_replace(btrim(p_prompt),'\s+',' ','g'),120);
  v_spec := jsonb_build_object(
    'compiler_version','1.0',
    'source_prompt',p_prompt,
    'inferred',jsonb_build_object(
      'builder_type',v_builder_type,
      'target',v_target,
      'required_capabilities',v_caps
    ),
    'routing',v_route,
    'selected_builder',v_route->'selected_builder',
    'governance',jsonb_build_object(
      'status','draft',
      'requires_human_approval',true,
      'auto_build_allowed',false
    )
  );

  insert into private.app_compiler_audit(prompt,inferred_builder_type,inferred_target,inferred_capabilities,routing_result,compiled_spec)
  values(p_prompt,v_builder_type,v_target,v_caps,v_route,v_spec);

  return jsonb_build_object(
    'title',v_title,
    'objective',p_prompt,
    'software_kind',case when v_builder_type='api' then 'api' else 'saas' end,
    'target_platforms',case when v_target is null then jsonb_build_array() else jsonb_build_array(v_target) end,
    'status','draft',
    'spec',v_spec
  );
end;
$$;

revoke all on function private.compile_app_request(text) from public, anon, authenticated;
grant execute on function private.compile_app_request(text) to service_role;
;
