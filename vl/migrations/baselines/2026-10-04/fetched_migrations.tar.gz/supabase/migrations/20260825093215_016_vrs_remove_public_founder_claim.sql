revoke all on function public.claim_founder() from public, anon, authenticated;
drop function if exists public.claim_founder();;
