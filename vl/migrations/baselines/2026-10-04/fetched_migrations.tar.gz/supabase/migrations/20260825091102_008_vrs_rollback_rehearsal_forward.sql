create table public.__vrs_rollback_probe (id integer primary key, marker text not null); insert into public.__vrs_rollback_probe(id,marker) values (1,'forward-ok');;
