create or replace function private.enqueue_factory_runner_job()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
  v_builder text;
begin
  if new.run_type <> 'build' then return new; end if;
  if new.target_environment='production' or new.production_locked is distinct from true then return new; end if;
  if new.state not in ('queued','planning','building','validating') then return new; end if;
  v_builder := private.resolve_factory_builder(new.id);
  if v_builder is null then return new; end if;
  insert into private.runner_jobs(factory_run_id,project_id,builder_key)
  values(new.id,new.project_id,v_builder)
  on conflict(factory_run_id) do nothing;
  return new;
end;
$function$;

revoke all on function private.enqueue_factory_runner_job() from public, anon, authenticated;
grant execute on function private.enqueue_factory_runner_job() to service_role;;
