create or replace function private.enforce_factory_artifact_immutability()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_referenced boolean := false;
  v_run_state text;
begin
  if tg_op = 'INSERT' then
    if new.sha256 is not null and new.sha256 !~ '^[0-9a-fA-F]{64}$' then
      raise exception 'factory artifact sha256 must be a valid SHA-256 hex digest';
    end if;
    return new;
  end if;

  select exists(
    select 1
    from public.deployments d
    where d.factory_run_id = old.factory_run_id
      and lower(coalesce(d.artifact_sha256,'')) = lower(coalesce(old.sha256,''))
      and d.status in ('planned','certified','approved','deploying','deployed')
  ) into v_referenced;

  select state into v_run_state
  from public.factory_runs
  where id = old.factory_run_id;

  if tg_op = 'DELETE' then
    if v_referenced then
      raise exception 'immutable factory artifact: artifact is referenced by a release deployment';
    end if;
    if v_run_state not in ('queued','building','validating','failed') then
      raise exception 'immutable factory artifact: deletion not allowed after factory run leaves mutable states';
    end if;
    return old;
  end if;

  if new.factory_run_id is distinct from old.factory_run_id
     or new.project_id is distinct from old.project_id
     or new.artifact_type is distinct from old.artifact_type
     or new.name is distinct from old.name
     or new.storage_path is distinct from old.storage_path
     or new.sha256 is distinct from old.sha256
     or new.created_at is distinct from old.created_at then
    if v_referenced then
      raise exception 'immutable factory artifact: release-bound identity/content fields cannot be changed';
    end if;
    if v_run_state not in ('building','validating') then
      raise exception 'immutable factory artifact: identity/content fields may only change during building/validating';
    end if;
  end if;

  if new.sha256 is not null and new.sha256 !~ '^[0-9a-fA-F]{64}$' then
    raise exception 'factory artifact sha256 must be a valid SHA-256 hex digest';
  end if;

  return new;
end
$$;

drop trigger if exists trg_enforce_factory_artifact_immutability on public.factory_artifacts;
create trigger trg_enforce_factory_artifact_immutability
before insert or update or delete on public.factory_artifacts
for each row execute function private.enforce_factory_artifact_immutability();;
