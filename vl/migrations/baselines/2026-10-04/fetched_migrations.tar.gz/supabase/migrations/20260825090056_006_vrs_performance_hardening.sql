create index if not exists organizations_created_by_idx on public.organizations(created_by);
create index if not exists projects_created_by_idx on public.projects(created_by);
create index if not exists app_specs_created_by_idx on public.app_specs(created_by);
create index if not exists app_specs_approved_by_idx on public.app_specs(approved_by) where approved_by is not null;
create index if not exists workflows_app_spec_idx on public.workflows(app_spec_id) where app_spec_id is not null;
create index if not exists workflows_created_by_idx on public.workflows(created_by);
create index if not exists approvals_workflow_idx on public.approvals(workflow_id) where workflow_id is not null;
create index if not exists approvals_requested_by_idx on public.approvals(requested_by);
create index if not exists approvals_decided_by_idx on public.approvals(decided_by) where decided_by is not null;
create index if not exists deployments_environment_idx on public.deployments(environment_id);
create index if not exists deployments_workflow_idx on public.deployments(workflow_id) where workflow_id is not null;
create index if not exists deployments_created_by_idx on public.deployments(created_by);
create index if not exists deployments_approved_by_idx on public.deployments(approved_by) where approved_by is not null;

drop policy if exists environments_manage_admin on public.environments;
create policy environments_insert_builder on public.environments for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']));
create policy environments_update_builder on public.environments for update to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']));
create policy environments_delete_admin on public.environments for delete to authenticated using (private.has_project_role(project_id,array['owner','admin']));

drop policy if exists jobs_manage_builder on public.jobs;
create policy jobs_insert_builder on public.jobs for insert to authenticated with check (exists (select 1 from public.workflows w where w.id=workflow_id and private.has_project_role(w.project_id,array['owner','admin','builder'])));
create policy jobs_update_builder on public.jobs for update to authenticated using (exists (select 1 from public.workflows w where w.id=workflow_id and private.has_project_role(w.project_id,array['owner','admin','builder']))) with check (exists (select 1 from public.workflows w where w.id=workflow_id and private.has_project_role(w.project_id,array['owner','admin','builder'])));
create policy jobs_delete_admin on public.jobs for delete to authenticated using (exists (select 1 from public.workflows w where w.id=workflow_id and private.has_project_role(w.project_id,array['owner','admin'])));;
