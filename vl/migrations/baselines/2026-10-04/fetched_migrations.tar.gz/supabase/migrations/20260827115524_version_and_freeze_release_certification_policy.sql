alter table public.builder_registry add column if not exists builder_version integer not null default 1 check (builder_version > 0);

alter table private.builder_release_gate_profiles add column if not exists policy_version integer not null default 1 check (policy_version > 0);
alter table private.builder_release_gate_profiles add column if not exists policy_sha256 text;

create or replace function private.refresh_builder_gate_profile_version()
returns trigger
language plpgsql
set search_path to 'private','public','extensions','pg_temp'
as $$
begin
  if tg_op='INSERT' then
    new.policy_version := coalesce(new.policy_version,1);
  elsif new.required_gates is distinct from old.required_gates then
    new.policy_version := old.policy_version + 1;
  else
    new.policy_version := old.policy_version;
  end if;
  new.policy_sha256 := encode(extensions.digest(convert_to(new.required_gates::text,'UTF8'),'sha256'),'hex');
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists trg_refresh_builder_gate_profile_version on private.builder_release_gate_profiles;
create trigger trg_refresh_builder_gate_profile_version
before insert or update on private.builder_release_gate_profiles
for each row execute function private.refresh_builder_gate_profile_version();

update private.builder_release_gate_profiles
set policy_sha256=encode(extensions.digest(convert_to(required_gates::text,'UTF8'),'sha256'),'hex')
where policy_sha256 is null;

alter table private.builder_release_gate_profiles alter column policy_sha256 set not null;
alter table private.builder_release_gate_profiles add constraint builder_release_gate_profiles_policy_sha256_chk check (policy_sha256 ~ '^[0-9a-f]{64}$');

alter table public.deployments add column if not exists required_gates_snapshot jsonb;
alter table public.deployments add column if not exists builder_key_snapshot text;
alter table public.deployments add column if not exists builder_version_snapshot integer;
alter table public.deployments add column if not exists gate_policy_version_snapshot integer;
alter table public.deployments add column if not exists gate_policy_sha256 text;
alter table public.deployments add column if not exists app_spec_sha256 text;
alter table public.deployments add column if not exists source_commit_sha text;

with src as (
  select d.id,
         coalesce(d.certificate->'required_gates', private.get_required_release_gates(fr.id), '[]'::jsonb) as gates,
         coalesce(d.certificate->>'builder_key',fr.result#>>'{runner,builder_key}',private.resolve_factory_builder(fr.id)) as builder_key,
         a.id as app_spec_id,
         case when a.id is null then null else jsonb_build_object(
           'id',a.id,'version',a.version,'title',a.title,'objective',a.objective,'spec',a.spec,
           'software_kind',a.software_kind,'target_platforms',to_jsonb(a.target_platforms)
         ) end as app_spec_doc,
         coalesce(fr.result#>>'{runner,source_commit_sha}',fr.result#>>'{runner,commit_sha}',fr.result#>>'{runner,head_sha}',fr.result->>'source_commit_sha',fr.result->>'commit_sha') as source_commit_sha
  from public.deployments d
  join public.factory_runs fr on fr.id=d.factory_run_id
  left join public.app_specs a on a.id=fr.app_spec_id
), enriched as (
  select src.*, br.builder_version, p.policy_version,
         encode(extensions.digest(convert_to(src.gates::text,'UTF8'),'sha256'),'hex') as gates_sha,
         case when src.app_spec_doc is null then null else encode(extensions.digest(convert_to(src.app_spec_doc::text,'UTF8'),'sha256'),'hex') end as spec_sha
  from src
  left join public.builder_registry br on br.builder_key=src.builder_key
  left join private.builder_release_gate_profiles p on p.builder_key=src.builder_key
)
update public.deployments d
set required_gates_snapshot=e.gates,
    builder_key_snapshot=e.builder_key,
    builder_version_snapshot=coalesce(e.builder_version,1),
    gate_policy_version_snapshot=coalesce(e.policy_version,1),
    gate_policy_sha256=e.gates_sha,
    app_spec_sha256=e.spec_sha,
    source_commit_sha=e.source_commit_sha,
    certificate=coalesce(d.certificate,'{}'::jsonb)||jsonb_build_object(
      'certification_snapshot_version',1,
      'builder_key',e.builder_key,
      'builder_version',coalesce(e.builder_version,1),
      'gate_policy_version',coalesce(e.policy_version,1),
      'gate_policy_sha256',e.gates_sha,
      'app_spec_sha256',e.spec_sha,
      'source_commit_sha',e.source_commit_sha,
      'snapshot_backfilled',true
    )
from enriched e
where d.id=e.id;

alter table public.deployments add constraint deployments_gate_policy_sha256_chk check (gate_policy_sha256 is null or gate_policy_sha256 ~ '^[0-9a-f]{64}$');
alter table public.deployments add constraint deployments_app_spec_sha256_chk check (app_spec_sha256 is null or app_spec_sha256 ~ '^[0-9a-f]{64}$');

create or replace function private.get_deployment_required_gates(p_deployment_id uuid)
returns jsonb
language sql
stable
set search_path to 'private','public','pg_temp'
as $$
  select coalesce(d.required_gates_snapshot,'[]'::jsonb)
  from public.deployments d
  where d.id=p_deployment_id
$$;

create or replace function private.enforce_deployment_snapshot_immutability()
returns trigger
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
begin
  if tg_op='UPDATE' and old.gate_policy_sha256 is not null then
    if new.factory_run_id is distinct from old.factory_run_id
       or new.required_gates_snapshot is distinct from old.required_gates_snapshot
       or new.builder_key_snapshot is distinct from old.builder_key_snapshot
       or new.builder_version_snapshot is distinct from old.builder_version_snapshot
       or new.gate_policy_version_snapshot is distinct from old.gate_policy_version_snapshot
       or new.gate_policy_sha256 is distinct from old.gate_policy_sha256
       or new.app_spec_sha256 is distinct from old.app_spec_sha256
       or new.source_commit_sha is distinct from old.source_commit_sha then
      raise exception 'deployment certification snapshot is immutable';
    end if;
  end if;
  if new.status in ('certified','approved','deploying','deployed') then
    if new.factory_run_id is null or new.required_gates_snapshot is null
       or new.builder_key_snapshot is null or new.builder_version_snapshot is null
       or new.gate_policy_version_snapshot is null or new.gate_policy_sha256 is null then
      raise exception 'certified deployment requires immutable certification snapshot';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_enforce_deployment_snapshot_immutability on public.deployments;
create trigger trg_enforce_deployment_snapshot_immutability
before insert or update on public.deployments
for each row execute function private.enforce_deployment_snapshot_immutability();;
