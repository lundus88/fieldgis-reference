create or replace function public.complete_vrs_runner_job(
  p_job_id uuid,
  p_lease_token uuid,
  p_success boolean,
  p_result jsonb default '{}'::jsonb,
  p_error_text text default null
)
returns jsonb
language plpgsql
security invoker
set search_path to 'private','public','pg_temp'
as $$
declare
  j private.runner_jobs%rowtype;
  v_run_state text;
  v_artifact_name text;
  v_storage_path text;
  v_sha text;
begin
  select * into j from private.runner_jobs where id=p_job_id for update;
  if not found then raise exception 'runner job not found'; end if;
  if j.state <> 'leased' or j.lease_token is distinct from p_lease_token then raise exception 'invalid runner lease'; end if;
  if j.lease_expires_at < now() then raise exception 'runner lease expired'; end if;

  if p_success then
    update private.runner_jobs
      set state='succeeded',result=coalesce(p_result,'{}'::jsonb),error_text=null,finished_at=now(),updated_at=now()
      where id=j.id;

    v_artifact_name := coalesce(nullif(p_result->>'artifact_name',''), j.builder_key || '-build');
    v_sha := nullif(p_result->>'artifact_sha256','');
    v_storage_path := case when nullif(p_result->>'github_run_id','') is not null
      then 'github-actions://lundus88/fieldgis-reference/runs/' || (p_result->>'github_run_id') || '/artifacts/' || v_artifact_name
      else null end;

    insert into public.factory_artifacts(factory_run_id,project_id,artifact_type,name,storage_path,sha256,metadata)
    values(j.factory_run_id,j.project_id,'bundle',v_artifact_name,v_storage_path,v_sha,
      jsonb_build_object('runner','github-actions-oidc','builder_key',j.builder_key,'qa_result','PASS','github_run_id',p_result->>'github_run_id'))
    on conflict(factory_run_id,name) do update
      set storage_path=excluded.storage_path,sha256=excluded.sha256,metadata=excluded.metadata;

    update public.factory_runs
      set state='awaiting_approval',
          result=coalesce(result,'{}'::jsonb)||jsonb_build_object('runner',coalesce(p_result,'{}'::jsonb),'runner_status','PASS'),
          error_text=null
      where id=j.factory_run_id and target_environment<>'production' and production_locked=true;

    update public.workflows w
      set state='waiting_approval',output=coalesce(output,'{}'::jsonb)||jsonb_build_object('runner_status','PASS','runner',coalesce(p_result,'{}'::jsonb))
      from public.factory_runs r where r.id=j.factory_run_id and w.id=r.workflow_id;
    v_run_state := 'awaiting_approval';
  else
    if j.attempts < j.max_attempts then
      update private.runner_jobs
        set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,updated_at=now()
        where id=j.id;
      update public.factory_runs set state='building',error_text=p_error_text where id=j.factory_run_id and target_environment<>'production' and production_locked=true;
      v_run_state := 'building';
    else
      update private.runner_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,finished_at=now(),updated_at=now() where id=j.id;
      update public.factory_runs set state='failed',error_text=p_error_text,finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',finished_at=now(),output=coalesce(output,'{}'::jsonb)||jsonb_build_object('runner_status','FAIL','error',p_error_text)
        from public.factory_runs r where r.id=j.factory_run_id and w.id=r.workflow_id;
      v_run_state := 'failed';
    end if;
  end if;

  return jsonb_build_object('status','recorded','job_id',j.id,'factory_run_id',j.factory_run_id,'factory_run_state',v_run_state);
end;
$$;
revoke all on function public.complete_vrs_runner_job(uuid,uuid,boolean,jsonb,text) from public,anon,authenticated;
grant execute on function public.complete_vrs_runner_job(uuid,uuid,boolean,jsonb,text) to service_role,postgres;;
