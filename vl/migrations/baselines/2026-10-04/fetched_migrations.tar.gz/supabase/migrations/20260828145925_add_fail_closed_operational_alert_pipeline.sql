alter table private.operational_incidents
  add column if not exists alert_state text not null default 'pending' check (alert_state in ('pending','leased','sent','failed')),
  add column if not exists alert_attempts int not null default 0 check (alert_attempts>=0),
  add column if not exists alert_lease_token uuid,
  add column if not exists alert_leased_at timestamptz,
  add column if not exists alert_sent_at timestamptz,
  add column if not exists alert_error_text text;

create index if not exists operational_incidents_alert_queue_idx on private.operational_incidents(alert_state,severity,started_at) where status<>'resolved';

create or replace function private.notification_production_readiness()
returns jsonb
language sql
security definer
set search_path=private,public,pg_temp
as $$
select jsonb_build_object(
  'adapter_key',r.adapter_key,
  'adapter_status',r.status,
  'production_send_allowed',coalesce((r.capabilities->>'production_send_allowed')::boolean,false) and coalesce((r.configuration->>'production_send_allowed')::boolean,false),
  'sandbox_e2e_verified_at',r.configuration->>'sandbox_e2e_verified_at',
  'sandbox_reconciliation_verified_at',r.configuration->>'sandbox_reconciliation_verified_at'
)
from private.capability_adapter_registry r where r.adapter_key='resend-email-v1';
$$;
revoke all on function private.notification_production_readiness() from public,anon,authenticated;
grant execute on function private.notification_production_readiness() to service_role;

create or replace function public.get_vrs_notification_production_readiness()
returns jsonb
language sql
security definer
set search_path=private,public,auth,pg_temp
as $$ select private.notification_production_readiness(); $$;
revoke all on function public.get_vrs_notification_production_readiness() from public,anon,authenticated;
grant execute on function public.get_vrs_notification_production_readiness() to service_role;

create or replace function private.claim_operational_alert_job(p_runner_identity jsonb)
returns jsonb
language plpgsql
security definer
set search_path=private,public,pg_temp
as $$
declare v private.operational_incidents%rowtype; tok uuid:=gen_random_uuid(); ready jsonb;
begin
  ready:=private.notification_production_readiness();
  if coalesce((ready->>'production_send_allowed')::boolean,false) is not true or coalesce(ready->>'adapter_status','')<>'active' then
    return jsonb_build_object('status','blocked','reason','notification production adapter is not active/allowed','readiness',ready);
  end if;
  select * into v from private.operational_incidents
   where status<>'resolved' and severity in ('sev1','sev2')
     and alert_state in ('pending','failed') and alert_attempts<3
   order by case severity when 'sev1' then 1 else 2 end, started_at
   for update skip locked limit 1;
  if not found then return jsonb_build_object('status','idle'); end if;
  update private.operational_incidents set alert_state='leased',alert_attempts=alert_attempts+1,alert_lease_token=tok,alert_leased_at=now(),alert_error_text=null where id=v.id;
  return jsonb_build_object('status','leased','incident_id',v.id,'incident_key',v.incident_key,'severity',v.severity,'summary',v.summary,'started_at',v.started_at,'lease_token',tok,'attempt',v.alert_attempts+1,'runner_identity',p_runner_identity);
end $$;
revoke all on function private.claim_operational_alert_job(jsonb) from public,anon,authenticated;
grant execute on function private.claim_operational_alert_job(jsonb) to service_role;

create or replace function public.claim_vrs_operational_alert_job(p_runner_identity jsonb)
returns jsonb language sql security definer set search_path=private,public,pg_temp as $$select private.claim_operational_alert_job(p_runner_identity);$$;
revoke all on function public.claim_vrs_operational_alert_job(jsonb) from public,anon,authenticated;
grant execute on function public.claim_vrs_operational_alert_job(jsonb) to service_role;

create or replace function private.complete_operational_alert_job(p_incident_id uuid,p_lease_token uuid,p_success boolean,p_provider_message_id text default null,p_error_text text default null)
returns jsonb
language plpgsql security definer set search_path=private,public,pg_temp
as $$
declare n int;
begin
  update private.operational_incidents set
    alert_state=case when p_success then 'sent' else 'failed' end,
    alert_sent_at=case when p_success then now() else alert_sent_at end,
    alert_error_text=case when p_success then null else left(coalesce(p_error_text,'unknown error'),2000) end,
    alert_lease_token=null,alert_leased_at=null,
    evidence=evidence || jsonb_build_object('alert_provider_message_id',p_provider_message_id,'alert_completed_at',now())
  where id=p_incident_id and alert_state='leased' and alert_lease_token=p_lease_token;
  get diagnostics n=row_count;
  if n<>1 then raise exception 'invalid or stale alert lease'; end if;
  return jsonb_build_object('ok',true,'incident_id',p_incident_id,'state',case when p_success then 'sent' else 'failed' end);
end $$;
revoke all on function private.complete_operational_alert_job(uuid,uuid,boolean,text,text) from public,anon,authenticated;
grant execute on function private.complete_operational_alert_job(uuid,uuid,boolean,text,text) to service_role;

create or replace function public.complete_vrs_operational_alert_job(p_incident_id uuid,p_lease_token uuid,p_success boolean,p_provider_message_id text default null,p_error_text text default null)
returns jsonb language sql security definer set search_path=private,public,pg_temp as $$select private.complete_operational_alert_job(p_incident_id,p_lease_token,p_success,p_provider_message_id,p_error_text);$$;
revoke all on function public.complete_vrs_operational_alert_job(uuid,uuid,boolean,text,text) from public,anon,authenticated;
grant execute on function public.complete_vrs_operational_alert_job(uuid,uuid,boolean,text,text) to service_role;;
