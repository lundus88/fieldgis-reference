create table if not exists public.build_failure_events (
  id uuid primary key default gen_random_uuid(),
  factory_run_id uuid not null references public.factory_runs(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  build_step_id uuid references public.build_steps(id) on delete set null,
  builder_key text,
  failure_class text not null,
  signature text not null,
  error_text text not null,
  source text not null default 'worker',
  retryable boolean not null default false,
  repair_recipe_key text,
  repair_applied boolean not null default false,
  repair_result jsonb not null default '{}'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists build_failure_events_run_idx on public.build_failure_events(factory_run_id, created_at desc);
create index if not exists build_failure_events_signature_idx on public.build_failure_events(signature, created_at desc);

create table if not exists public.repair_recipe_registry (
  id uuid primary key default gen_random_uuid(),
  recipe_key text not null unique,
  failure_class text not null,
  signature_pattern text not null,
  builder_key text,
  action_type text not null,
  action_spec jsonb not null default '{}'::jsonb,
  risk_level text not null default 'low' check (risk_level in ('low','medium','high')),
  auto_apply boolean not null default false,
  max_auto_attempts integer not null default 1 check (max_auto_attempts between 0 and 5),
  status text not null default 'active' check (status in ('active','disabled','experimental')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists repair_recipe_registry_match_idx on public.repair_recipe_registry(failure_class, builder_key, status);

create table if not exists public.builder_certification_evidence (
  id uuid primary key default gen_random_uuid(),
  builder_key text not null references public.builder_registry(builder_key) on delete cascade,
  factory_run_id uuid references public.factory_runs(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  evidence_type text not null,
  evidence_status text not null check (evidence_status in ('pass','fail','pending')),
  evidence jsonb not null default '{}'::jsonb,
  source_uri text,
  created_at timestamptz not null default now()
);
create index if not exists builder_cert_evidence_idx on public.builder_certification_evidence(builder_key, created_at desc);

alter table public.build_failure_events enable row level security;
alter table public.repair_recipe_registry enable row level security;
alter table public.builder_certification_evidence enable row level security;

drop policy if exists build_failure_events_member_read on public.build_failure_events;
create policy build_failure_events_member_read on public.build_failure_events for select to authenticated using (
  exists(select 1 from public.project_members pm where pm.project_id=build_failure_events.project_id and pm.user_id=(select auth.uid()))
);
drop policy if exists build_failure_events_member_insert on public.build_failure_events;
create policy build_failure_events_member_insert on public.build_failure_events for insert to authenticated with check (
  exists(select 1 from public.project_members pm where pm.project_id=build_failure_events.project_id and pm.user_id=(select auth.uid()))
);
drop policy if exists build_failure_events_member_update on public.build_failure_events;
create policy build_failure_events_member_update on public.build_failure_events for update to authenticated using (
  exists(select 1 from public.project_members pm where pm.project_id=build_failure_events.project_id and pm.user_id=(select auth.uid()))
) with check (
  exists(select 1 from public.project_members pm where pm.project_id=build_failure_events.project_id and pm.user_id=(select auth.uid()))
);

drop policy if exists repair_recipe_registry_read on public.repair_recipe_registry;
create policy repair_recipe_registry_read on public.repair_recipe_registry for select to authenticated using (true);

drop policy if exists builder_cert_evidence_read on public.builder_certification_evidence;
create policy builder_cert_evidence_read on public.builder_certification_evidence for select to authenticated using (
  project_id is null or exists(select 1 from public.project_members pm where pm.project_id=builder_certification_evidence.project_id and pm.user_id=(select auth.uid()))
);
drop policy if exists builder_cert_evidence_insert on public.builder_certification_evidence;
create policy builder_cert_evidence_insert on public.builder_certification_evidence for insert to authenticated with check (
  project_id is not null and exists(select 1 from public.project_members pm where pm.project_id=builder_certification_evidence.project_id and pm.user_id=(select auth.uid()))
);

insert into public.repair_recipe_registry(recipe_key,failure_class,signature_pattern,builder_key,action_type,action_spec,risk_level,auto_apply,max_auto_attempts,status)
values
('flutter_default_widget_test_overwrite','test_compile','The name ''MyApp'' isn''t a class','mobile-flutter-v1','rewrite_generated_test',jsonb_build_object('test_class','FieldGisApp','write_after_flutter_create',true),'low',true,1,'active'),
('flutter_info_lint_nonfatal','static_analysis','unnecessary_underscores','mobile-flutter-v1','lint_repair',jsonb_build_object('rule','replace_extra_underscore_parameters','allow_info_nonfatal',true),'low',true,1,'active'),
('github_setup_java_v4_deprecated','ci_maintenance','setup-java v4 is deprecated','mobile-flutter-v1','workflow_upgrade',jsonb_build_object('from','actions/setup-java@v4','to','actions/setup-java@v5'),'low',true,1,'active')
on conflict (recipe_key) do update set action_spec=excluded.action_spec, updated_at=now(), status=excluded.status;;
