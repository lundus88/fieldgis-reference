create table if not exists public.builder_certification_policies (
  id uuid primary key default gen_random_uuid(),
  builder_key text not null unique references public.builder_registry(builder_key) on delete cascade,
  required_evidence jsonb not null default '[]'::jsonb,
  minimum_score numeric not null default 1.0 check (minimum_score >= 0 and minimum_score <= 1),
  minimum_distinct_runs integer not null default 1 check (minimum_distinct_runs >= 1),
  allow_auto_activate boolean not null default true,
  status text not null default 'active' check (status in ('active','paused')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.builder_certification_results (
  id uuid primary key default gen_random_uuid(),
  builder_key text not null references public.builder_registry(builder_key) on delete cascade,
  decision text not null check (decision in ('not_ready','candidate','certified')),
  score numeric not null default 0 check (score >= 0 and score <= 1),
  passed_evidence text[] not null default '{}',
  missing_evidence text[] not null default '{}',
  distinct_run_count integer not null default 0,
  evaluated_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists builder_certification_results_builder_time_idx
  on public.builder_certification_results(builder_key,evaluated_at desc);

alter table public.builder_certification_policies enable row level security;
alter table public.builder_certification_results enable row level security;

create policy builder_certification_policies_read on public.builder_certification_policies
for select to authenticated using (true);

create policy builder_certification_results_read on public.builder_certification_results
for select to authenticated using (true);

insert into public.builder_certification_policies(builder_key,required_evidence,minimum_score,minimum_distinct_runs,allow_auto_activate)
values
('mobile-flutter-v1', jsonb_build_array('static_analysis_pass','test_pass','apk_build_pass','android_device_e2e_pass','gps_capture_pass'), 1.0, 1, true),
('gis-web-v1', jsonb_build_array('static_analysis_pass','map_runtime_pass','gps_marker_pass','export_kml_pass'), 1.0, 1, true)
on conflict (builder_key) do update set
  required_evidence=excluded.required_evidence,
  minimum_score=excluded.minimum_score,
  minimum_distinct_runs=excluded.minimum_distinct_runs,
  allow_auto_activate=excluded.allow_auto_activate,
  updated_at=now();

create or replace function public.evaluate_builder_certification(p_builder_key text, p_activate boolean default false)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  pol public.builder_certification_policies%rowtype;
  req text[];
  passed text[];
  missing text[];
  req_count int;
  pass_count int;
  run_count int;
  v_score numeric;
  v_decision text;
  v_status text;
begin
  select * into pol from public.builder_certification_policies where builder_key=p_builder_key and status='active';
  if not found then raise exception 'No active certification policy for builder %', p_builder_key; end if;

  select coalesce(array_agg(value order by value),'{}'::text[])
  into req
  from jsonb_array_elements_text(pol.required_evidence);

  select coalesce(array_agg(distinct evidence_type order by evidence_type),'{}'::text[])
  into passed
  from public.builder_certification_evidence
  where builder_key=p_builder_key and evidence_status='pass' and evidence_type = any(req);

  select coalesce(array_agg(x order by x),'{}'::text[])
  into missing
  from unnest(req) x
  where not (x = any(passed));

  req_count := cardinality(req);
  pass_count := cardinality(passed);

  select count(distinct factory_run_id)::int into run_count
  from public.builder_certification_evidence
  where builder_key=p_builder_key and evidence_status='pass' and factory_run_id is not null and evidence_type = any(req);

  v_score := case when req_count=0 then 0 else pass_count::numeric/req_count::numeric end;

  if cardinality(missing)=0 and run_count >= pol.minimum_distinct_runs and v_score >= pol.minimum_score then
    v_decision := 'certified';
  elsif pass_count > 0 then
    v_decision := 'candidate';
  else
    v_decision := 'not_ready';
  end if;

  insert into public.builder_certification_results(builder_key,decision,score,passed_evidence,missing_evidence,distinct_run_count,metadata)
  values(p_builder_key,v_decision,v_score,passed,missing,run_count,jsonb_build_object('policy_id',pol.id,'activation_requested',p_activate));

  if p_activate and v_decision='certified' and pol.allow_auto_activate then
    update public.builder_registry set status='active',updated_at=now() where builder_key=p_builder_key and status <> 'active';
  end if;

  select status into v_status from public.builder_registry where builder_key=p_builder_key;

  return jsonb_build_object(
    'builder_key',p_builder_key,
    'decision',v_decision,
    'score',v_score,
    'passed_evidence',passed,
    'missing_evidence',missing,
    'distinct_run_count',run_count,
    'builder_status',v_status,
    'activated', (p_activate and v_decision='certified' and pol.allow_auto_activate)
  );
end;
$$;

revoke all on function public.evaluate_builder_certification(text,boolean) from public;
grant execute on function public.evaluate_builder_certification(text,boolean) to authenticated;
;
