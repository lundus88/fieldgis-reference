create table public.environments (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  name text not null,
  kind text not null check (kind in ('development','staging','production')),
  status text not null default 'ready' check (status in ('ready','busy','degraded','paused')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(project_id,name)
);

create table public.workflows (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  app_spec_id uuid references public.app_specs(id) on delete set null,
  workflow_type text not null,
  state text not null default 'queued' check (state in ('queued','running','waiting_approval','succeeded','failed','cancelled')),
  input jsonb not null default '{}'::jsonb,
  output jsonb not null default '{}'::jsonb,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  workflow_id uuid not null references public.workflows(id) on delete cascade,
  job_type text not null,
  state text not null default 'queued' check (state in ('queued','running','succeeded','failed','cancelled')),
  attempt integer not null default 0,
  payload jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  error_text text,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz
);

create table public.approvals (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  workflow_id uuid references public.workflows(id) on delete cascade,
  approval_type text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected','expired')),
  requested_by uuid not null references auth.users(id),
  decided_by uuid references auth.users(id),
  rationale text,
  requested_at timestamptz not null default now(),
  decided_at timestamptz
);

create table public.deployments (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  environment_id uuid not null references public.environments(id) on delete restrict,
  workflow_id uuid references public.workflows(id) on delete set null,
  release_version text not null,
  status text not null default 'planned' check (status in ('planned','certified','approved','deploying','deployed','failed','rolled_back')),
  artifact_sha256 text,
  certificate jsonb not null default '{}'::jsonb,
  created_by uuid not null references auth.users(id),
  approved_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  deployed_at timestamptz
);

create index environments_project_idx on public.environments(project_id,kind);
create index workflows_project_state_idx on public.workflows(project_id,state,created_at desc);
create index jobs_workflow_state_idx on public.jobs(workflow_id,state);
create index approvals_project_status_idx on public.approvals(project_id,status,requested_at desc);
create index deployments_project_idx on public.deployments(project_id,created_at desc);

alter table public.environments enable row level security;
alter table public.workflows enable row level security;
alter table public.jobs enable row level security;
alter table public.approvals enable row level security;
alter table public.deployments enable row level security;

create policy environments_select_member on public.environments for select to authenticated using (private.is_project_member(project_id));
create policy environments_manage_admin on public.environments for all to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']));

create policy workflows_select_member on public.workflows for select to authenticated using (private.is_project_member(project_id));
create policy workflows_insert_builder on public.workflows for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']) and created_by=(select auth.uid()));
create policy workflows_update_builder on public.workflows for update to authenticated using (private.has_project_role(project_id,array['owner','admin','builder'])) with check (private.has_project_role(project_id,array['owner','admin','builder']));

create policy jobs_select_member on public.jobs for select to authenticated using (exists (select 1 from public.workflows w where w.id=workflow_id and private.is_project_member(w.project_id)));
create policy jobs_manage_builder on public.jobs for all to authenticated using (exists (select 1 from public.workflows w where w.id=workflow_id and private.has_project_role(w.project_id,array['owner','admin','builder']))) with check (exists (select 1 from public.workflows w where w.id=workflow_id and private.has_project_role(w.project_id,array['owner','admin','builder'])));

create policy approvals_select_member on public.approvals for select to authenticated using (private.is_project_member(project_id));
create policy approvals_insert_builder on public.approvals for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']) and requested_by=(select auth.uid()));
create policy approvals_update_reviewer on public.approvals for update to authenticated using (private.has_project_role(project_id,array['owner','admin','reviewer'])) with check (private.has_project_role(project_id,array['owner','admin','reviewer']));

create policy deployments_select_member on public.deployments for select to authenticated using (private.is_project_member(project_id));
create policy deployments_insert_builder on public.deployments for insert to authenticated with check (private.has_project_role(project_id,array['owner','admin','builder']) and created_by=(select auth.uid()));
create policy deployments_update_reviewer on public.deployments for update to authenticated using (private.has_project_role(project_id,array['owner','admin','reviewer'])) with check (private.has_project_role(project_id,array['owner','admin','reviewer']));

grant select,insert,update,delete on public.environments to authenticated;
grant select,insert,update on public.workflows to authenticated;
grant select,insert,update,delete on public.jobs to authenticated;
grant select,insert,update on public.approvals to authenticated;
grant select,insert,update on public.deployments to authenticated;;
