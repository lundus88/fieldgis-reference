create or replace function public.ingest_ci_evidence(
  p_project_id uuid,
  p_factory_run_id uuid,
  p_builder_key text,
  p_repository text,
  p_external_run_id text,
  p_external_job_id text,
  p_head_sha text,
  p_run_status text,
  p_run_conclusion text,
  p_step_results jsonb,
  p_artifact_results jsonb default '{}'::jsonb,
  p_raw_summary jsonb default '{}'::jsonb
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_static text;
  v_test text;
  v_apk text;
  v_result jsonb;
begin
  if not exists (select 1 from public.project_members where project_id=p_project_id and user_id=auth.uid()) then
    raise exception 'forbidden';
  end if;

  insert into public.ci_evidence_ingestions(project_id,factory_run_id,builder_key,repository,external_run_id,external_job_id,head_sha,run_status,run_conclusion,step_results,artifact_results,raw_summary)
  values(p_project_id,p_factory_run_id,p_builder_key,p_repository,p_external_run_id,p_external_job_id,p_head_sha,p_run_status,p_run_conclusion,coalesce(p_step_results,'{}'::jsonb),coalesce(p_artifact_results,'{}'::jsonb),coalesce(p_raw_summary,'{}'::jsonb))
  on conflict(provider,repository,external_run_id,builder_key) do update set
    external_job_id=excluded.external_job_id,
    head_sha=excluded.head_sha,
    run_status=excluded.run_status,
    run_conclusion=excluded.run_conclusion,
    step_results=excluded.step_results,
    artifact_results=excluded.artifact_results,
    raw_summary=excluded.raw_summary,
    ingested_at=now();

  v_static := coalesce(p_step_results->>'Analyze','');
  v_test := coalesce(p_step_results->>'Test','');
  v_apk := coalesce(p_step_results->>'Build debug APK','');

  if v_static='success' and not exists (
    select 1 from public.builder_certification_evidence where builder_key=p_builder_key and evidence_type='static_analysis_pass' and source_uri=format('https://github.com/%s/actions/runs/%s',p_repository,p_external_run_id)
  ) then
    insert into public.builder_certification_evidence(builder_key,factory_run_id,project_id,evidence_type,evidence_status,evidence,source_uri)
    values(p_builder_key,p_factory_run_id,p_project_id,'static_analysis_pass','pass',jsonb_build_object('provider','github_actions','run_id',p_external_run_id,'head_sha',p_head_sha),format('https://github.com/%s/actions/runs/%s',p_repository,p_external_run_id));
  end if;

  if v_test='success' and not exists (
    select 1 from public.builder_certification_evidence where builder_key=p_builder_key and evidence_type='test_pass' and source_uri=format('https://github.com/%s/actions/runs/%s',p_repository,p_external_run_id)
  ) then
    insert into public.builder_certification_evidence(builder_key,factory_run_id,project_id,evidence_type,evidence_status,evidence,source_uri)
    values(p_builder_key,p_factory_run_id,p_project_id,'test_pass','pass',jsonb_build_object('provider','github_actions','run_id',p_external_run_id,'head_sha',p_head_sha),format('https://github.com/%s/actions/runs/%s',p_repository,p_external_run_id));
  end if;

  if v_apk='success' and coalesce(p_artifact_results->>'fieldgis-reference-debug-apk','')='present' and not exists (
    select 1 from public.builder_certification_evidence where builder_key=p_builder_key and evidence_type='apk_build_pass' and source_uri=format('https://github.com/%s/actions/runs/%s',p_repository,p_external_run_id)
  ) then
    insert into public.builder_certification_evidence(builder_key,factory_run_id,project_id,evidence_type,evidence_status,evidence,source_uri)
    values(p_builder_key,p_factory_run_id,p_project_id,'apk_build_pass','pass',jsonb_build_object('provider','github_actions','run_id',p_external_run_id,'head_sha',p_head_sha,'artifact','fieldgis-reference-debug-apk'),format('https://github.com/%s/actions/runs/%s',p_repository,p_external_run_id));
  end if;

  select public.evaluate_builder_certification(p_builder_key,false) into v_result;
  return jsonb_build_object('ingested',true,'certification',v_result);
end;
$$;;
