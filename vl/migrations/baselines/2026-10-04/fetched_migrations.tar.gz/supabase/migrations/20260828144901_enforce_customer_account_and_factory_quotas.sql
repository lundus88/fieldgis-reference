alter table public.customer_accounts
  add constraint customer_accounts_plan_key_fkey foreign key (plan_key) references public.plan_catalog(plan_key);

create or replace function private.guard_customer_account_mutation()
returns trigger
language plpgsql
security definer
set search_path=public,private,auth,pg_temp
as $$
declare
  v_role text := coalesce(current_setting('request.jwt.claim.role',true),'');
begin
  if v_role='authenticated' then
    if tg_op='INSERT' then
      if new.owner_user_id is distinct from auth.uid() then raise exception 'owner mismatch' using errcode='42501'; end if;
      if new.plan_key <> 'launch_pilot' then raise exception 'plan not self-selectable' using errcode='42501'; end if;
      if new.status not in ('pending','active') then raise exception 'invalid initial account status' using errcode='42501'; end if;
      if new.status='active' and (new.terms_accepted_at is null or new.onboarding_state<>'ready') then raise exception 'active account requires accepted terms and ready onboarding' using errcode='42501'; end if;
    elsif tg_op='UPDATE' then
      if new.owner_user_id is distinct from old.owner_user_id or new.plan_key is distinct from old.plan_key or new.status is distinct from old.status then
        raise exception 'sensitive account fields are operator-controlled' using errcode='42501';
      end if;
    end if;
  end if;
  new.updated_at:=now();
  return new;
end $$;
revoke all on function private.guard_customer_account_mutation() from public,anon,authenticated;

drop trigger if exists trg_guard_customer_account_mutation on public.customer_accounts;
create trigger trg_guard_customer_account_mutation before insert or update on public.customer_accounts for each row execute function private.guard_customer_account_mutation();

create or replace function private.enforce_public_factory_quota()
returns trigger
language plpgsql
security definer
set search_path=public,private,auth,pg_temp
as $$
declare
  v_account public.customer_accounts%rowtype;
  v_daily_limit int;
  v_concurrent_limit int;
  v_daily_used int;
  v_active int;
begin
  select * into v_account from public.customer_accounts where owner_user_id=new.requested_by;
  if not found then return new; end if;

  if v_account.status<>'active' or v_account.onboarding_state<>'ready' or v_account.terms_accepted_at is null then
    raise exception 'customer account is not launch-ready' using errcode='42501';
  end if;

  select coalesce((limits->>'factory_runs_per_day')::int,0), coalesce((limits->>'concurrent_runs')::int,0)
    into v_daily_limit,v_concurrent_limit from public.plan_catalog where plan_key=v_account.plan_key and is_public=true;
  if v_daily_limit<=0 or v_concurrent_limit<=0 then raise exception 'plan quota is not configured' using errcode='42501'; end if;

  select count(*) into v_daily_used from public.factory_runs
   where requested_by=new.requested_by and created_at>=date_trunc('day',now() at time zone 'UTC') at time zone 'UTC';
  if v_daily_used>=v_daily_limit then raise exception 'daily factory run quota exceeded' using errcode='P0001'; end if;

  select count(*) into v_active from public.factory_runs
   where requested_by=new.requested_by and finished_at is null and state<>'failed';
  if v_active>=v_concurrent_limit then raise exception 'concurrent factory run quota exceeded' using errcode='P0001'; end if;

  insert into private.usage_counters(customer_account_id,metric_key,window_start,window_end,used_count,limit_count)
  values(v_account.id,'factory_runs',date_trunc('day',now() at time zone 'UTC') at time zone 'UTC',(date_trunc('day',now() at time zone 'UTC')+interval '1 day') at time zone 'UTC',v_daily_used+1,v_daily_limit)
  on conflict(customer_account_id,metric_key,window_start,window_end) do update set used_count=excluded.used_count,limit_count=excluded.limit_count,updated_at=now();

  return new;
end $$;
revoke all on function private.enforce_public_factory_quota() from public,anon,authenticated;

drop trigger if exists trg_enforce_public_factory_quota on public.factory_runs;
create trigger trg_enforce_public_factory_quota before insert on public.factory_runs for each row execute function private.enforce_public_factory_quota();

update private.launch_readiness_checks set status='pass',evidence='{"source":"db_trigger","daily_limit":3,"concurrent_limit":1,"bypass":"none_for_customer_accounts"}'::jsonb,checked_at=now() where check_key='usage_rate_limits';;
