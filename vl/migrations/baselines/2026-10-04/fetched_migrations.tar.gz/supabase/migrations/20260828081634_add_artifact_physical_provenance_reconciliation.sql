create or replace function public.reconcile_factory_artifact_physical_provenance(
  p_factory_run_id uuid,
  p_github_run_id text,
  p_github_artifact_id text,
  p_github_artifact_digest text,
  p_github_head_sha text,
  p_github_artifact_expires_at timestamptz,
  p_artifact_name text
) returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $$
declare
  v_art public.factory_artifacts%rowtype;
  v_run public.factory_runs%rowtype;
  v_existing jsonb;
begin
  if p_factory_run_id is null then raise exception 'factory_run_id required'; end if;
  if coalesce(trim(p_github_run_id),'') !~ '^[0-9]+$' then raise exception 'valid github_run_id required'; end if;
  if coalesce(trim(p_github_artifact_id),'') !~ '^[0-9]+$' then raise exception 'valid github_artifact_id required'; end if;
  if coalesce(trim(p_github_artifact_digest),'') !~ '^sha256:[0-9a-fA-F]{64}$' then raise exception 'valid GitHub artifact digest required'; end if;
  if coalesce(trim(p_github_head_sha),'') !~ '^[0-9a-fA-F]{40}$' then raise exception 'valid GitHub head SHA required'; end if;
  if p_github_artifact_expires_at is null or p_github_artifact_expires_at <= now() then raise exception 'non-expired GitHub artifact required'; end if;
  if coalesce(trim(p_artifact_name),'')='' then raise exception 'artifact name required'; end if;

  select * into v_run from public.factory_runs where id=p_factory_run_id for update;
  if not found then raise exception 'factory run not found'; end if;

  select * into v_art from public.factory_artifacts
   where factory_run_id=p_factory_run_id and artifact_type='bundle' and name=p_artifact_name
   order by created_at desc limit 1 for update;
  if not found then raise exception 'factory bundle artifact not found'; end if;

  if coalesce(v_art.metadata->>'github_run_id','')<>p_github_run_id then
    raise exception 'GitHub run binding mismatch';
  end if;

  if coalesce(v_run.result#>>'{runner,github_sha}','')<>'' and lower(v_run.result#>>'{runner,github_sha}')<>lower(p_github_head_sha) then
    raise exception 'GitHub head SHA does not match runner source commit';
  end if;

  v_existing:=coalesce(v_art.metadata,'{}'::jsonb);
  if nullif(v_existing->>'github_artifact_id','') is not null then
    if v_existing->>'github_artifact_id'<>p_github_artifact_id
       or lower(v_existing->>'github_artifact_digest')<>lower(p_github_artifact_digest)
       or lower(v_existing->>'github_head_sha')<>lower(p_github_head_sha) then
      raise exception 'physical artifact provenance is already bound and immutable';
    end if;
    return jsonb_build_object('decision','already_reconciled','artifact_id',v_art.id,'factory_run_id',p_factory_run_id,'idempotent',true);
  end if;

  update public.factory_artifacts
  set metadata=v_existing||jsonb_build_object(
    'github_artifact_id',p_github_artifact_id,
    'github_artifact_digest',lower(p_github_artifact_digest),
    'github_head_sha',lower(p_github_head_sha),
    'github_artifact_expires_at',p_github_artifact_expires_at,
    'physical_provenance_reconciled_at',now(),
    'physical_provenance_source','github-actions-api'
  ) where id=v_art.id;

  insert into private.factory_execution_events(factory_run_id,project_id,event_type,from_state,to_state,payload)
  values(v_run.id,v_run.project_id,'artifact_physical_provenance_reconciled',v_run.state,v_run.state,
    jsonb_build_object('artifact_id',v_art.id,'github_artifact_id',p_github_artifact_id,'github_artifact_digest',lower(p_github_artifact_digest),'github_head_sha',lower(p_github_head_sha),'expires_at',p_github_artifact_expires_at));

  return jsonb_build_object('decision','reconciled','artifact_id',v_art.id,'factory_run_id',p_factory_run_id,'github_artifact_id',p_github_artifact_id,'idempotent',false);
end
$$;

revoke all on function public.reconcile_factory_artifact_physical_provenance(uuid,text,text,text,text,timestamptz,text) from public, anon, authenticated;
grant execute on function public.reconcile_factory_artifact_physical_provenance(uuid,text,text,text,text,timestamptz,text) to service_role;;
