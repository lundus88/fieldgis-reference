create table if not exists private.runner_jobs (
  id uuid primary key default gen_random_uuid(),
  factory_run_id uuid not null unique references public.factory_runs(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  builder_key text not null,
  state text not null default 'queued' check (state in ('queued','leased','succeeded','failed','cancelled')),
  attempts integer not null default 0,
  max_attempts integer not null default 3,
  lease_token uuid,
  leased_at timestamptz,
  lease_expires_at timestamptz,
  runner_identity jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  error_text text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  finished_at timestamptz
);

revoke all on private.runner_jobs from public, anon, authenticated;
grant select, insert, update on private.runner_jobs to service_role;

create or replace function private.resolve_factory_builder(p_factory_run_id uuid)
returns text
language plpgsql
security invoker
set search_path to 'private','public','pg_temp'
as $$
declare
  v_builder text;
  v_input jsonb;
  v_plan jsonb;
begin
  select input, plan into v_input, v_plan from public.factory_runs where id=p_factory_run_id;
  if not found then return null; end if;

  v_builder := nullif(v_input->>'builder_key','');
  if v_builder is null then
    if exists(select 1 from public.build_steps where factory_run_id=p_factory_run_id and step_key ilike '%mobile-flutter%')
       or coalesce(v_plan::text,'') ilike '%mobile-flutter%' then
      v_builder := 'mobile-flutter-v1';
    elsif exists(select 1 from public.build_steps where factory_run_id=p_factory_run_id and step_key ilike '%gis-web%')
       or (coalesce(v_plan::text,'') ilike '%gis%' and coalesce(v_plan::text,'') ilike '%web%') then
      v_builder := 'gis-web-v1';
    end if;
  end if;

  if v_builder is not null and not exists(
    select 1 from public.builder_registry where builder_key=v_builder and status='active'
  ) then
    return null;
  end if;
  return v_builder;
end;
$$;

revoke all on function private.resolve_factory_builder(uuid) from public;
grant execute on function private.resolve_factory_builder(uuid) to service_role, postgres;

create or replace function private.enqueue_factory_runner_job()
returns trigger
language plpgsql
security invoker
set search_path to 'private','public','pg_temp'
as $$
declare
  v_builder text;
begin
  if new.run_type <> 'build' then return new; end if;
  if new.target_environment='production' or new.production_locked is distinct from true then return new; end if;
  if new.state not in ('queued','planning','building','validating') then return new; end if;
  v_builder := private.resolve_factory_builder(new.id);
  if v_builder is null then return new; end if;
  insert into private.runner_jobs(factory_run_id,project_id,builder_key)
  values(new.id,new.project_id,v_builder)
  on conflict(factory_run_id) do nothing;
  return new;
end;
$$;

revoke all on function private.enqueue_factory_runner_job() from public;

drop trigger if exists trg_enqueue_factory_runner_job on public.factory_runs;
create trigger trg_enqueue_factory_runner_job
after insert or update of state,input,plan on public.factory_runs
for each row execute function private.enqueue_factory_runner_job();

create or replace function public.claim_vrs_runner_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security invoker
set search_path to 'private','public','pg_temp'
as $$
declare
  j private.runner_jobs%rowtype;
  v_lease uuid := gen_random_uuid();
  v_spec jsonb;
  v_artifacts jsonb;
  v_run public.factory_runs%rowtype;
begin
  select * into j
  from private.runner_jobs
  where (
    state='queued'
    or (state='leased' and lease_expires_at < now())
  ) and attempts < max_attempts
  order by created_at
  for update skip locked
  limit 1;

  if not found then return jsonb_build_object('status','idle'); end if;

  update private.runner_jobs
  set state='leased', attempts=attempts+1, lease_token=v_lease,
      leased_at=now(), lease_expires_at=now()+interval '20 minutes',
      runner_identity=coalesce(p_runner_identity,'{}'::jsonb), updated_at=now()
  where id=j.id
  returning * into j;

  select * into v_run from public.factory_runs where id=j.factory_run_id;
  if v_run.target_environment='production' or v_run.production_locked is distinct from true then
    update private.runner_jobs set state='failed', error_text='production execution forbidden', finished_at=now(), updated_at=now() where id=j.id;
    return jsonb_build_object('status','rejected','reason','production_execution_forbidden');
  end if;

  select jsonb_build_object(
    'id',a.id,'title',a.title,'objective',a.objective,'spec',a.spec,
    'software_kind',a.software_kind,'target_platforms',a.target_platforms,'status',a.status
  ) into v_spec from public.app_specs a where a.id=v_run.app_spec_id;

  select coalesce(jsonb_agg(jsonb_build_object(
    'path',g.path,'content',g.content,'sha256',g.sha256,'artifact_kind',g.artifact_kind,'metadata',g.metadata
  ) order by g.path),'[]'::jsonb)
  into v_artifacts
  from public.generated_artifacts g where g.factory_run_id=j.factory_run_id;

  return jsonb_build_object(
    'status','leased','job_id',j.id,'lease_token',v_lease,'factory_run_id',j.factory_run_id,
    'builder_key',j.builder_key,'attempt',j.attempts,'max_attempts',j.max_attempts,
    'app_spec',v_spec,'generated_artifacts',v_artifacts,
    'target_environment',v_run.target_environment,'production_locked',v_run.production_locked
  );
end;
$$;

revoke all on function public.claim_vrs_runner_job(jsonb) from public, anon, authenticated;
grant execute on function public.claim_vrs_runner_job(jsonb) to service_role, postgres;

create or replace function public.complete_vrs_runner_job(
  p_job_id uuid,
  p_lease_token uuid,
  p_success boolean,
  p_result jsonb default '{}'::jsonb,
  p_error_text text default null
)
returns jsonb
language plpgsql
security invoker
set search_path to 'private','public','pg_temp'
as $$
declare
  j private.runner_jobs%rowtype;
  v_run_state text;
begin
  select * into j from private.runner_jobs where id=p_job_id for update;
  if not found then raise exception 'runner job not found'; end if;
  if j.state <> 'leased' or j.lease_token is distinct from p_lease_token then raise exception 'invalid runner lease'; end if;
  if j.lease_expires_at < now() then raise exception 'runner lease expired'; end if;

  if p_success then
    update private.runner_jobs set state='succeeded',result=coalesce(p_result,'{}'::jsonb),error_text=null,finished_at=now(),updated_at=now() where id=j.id;
    update public.factory_runs
      set state='awaiting_approval',
          result=coalesce(result,'{}'::jsonb)||jsonb_build_object('runner',coalesce(p_result,'{}'::jsonb),'runner_status','PASS'),
          error_text=null
      where id=j.factory_run_id and target_environment<>'production' and production_locked=true;
    update public.workflows w set state='waiting_approval',output=coalesce(output,'{}'::jsonb)||jsonb_build_object('runner_status','PASS')
      from public.factory_runs r where r.id=j.factory_run_id and w.id=r.workflow_id;
    v_run_state := 'awaiting_approval';
  else
    if j.attempts < j.max_attempts then
      update private.runner_jobs set state='queued',lease_token=null,leased_at=null,lease_expires_at=null,result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,updated_at=now() where id=j.id;
      update public.factory_runs set state='building',error_text=p_error_text where id=j.factory_run_id and target_environment<>'production' and production_locked=true;
      v_run_state := 'building';
    else
      update private.runner_jobs set state='failed',result=coalesce(p_result,'{}'::jsonb),error_text=p_error_text,finished_at=now(),updated_at=now() where id=j.id;
      update public.factory_runs set state='failed',error_text=p_error_text,finished_at=now() where id=j.factory_run_id;
      update public.workflows w set state='failed',finished_at=now(),output=coalesce(output,'{}'::jsonb)||jsonb_build_object('runner_status','FAIL','error',p_error_text)
        from public.factory_runs r where r.id=j.factory_run_id and w.id=r.workflow_id;
      v_run_state := 'failed';
    end if;
  end if;

  return jsonb_build_object('status','recorded','job_id',j.id,'factory_run_id',j.factory_run_id,'factory_run_state',v_run_state);
end;
$$;

revoke all on function public.complete_vrs_runner_job(uuid,uuid,boolean,jsonb,text) from public, anon, authenticated;
grant execute on function public.complete_vrs_runner_job(uuid,uuid,boolean,jsonb,text) to service_role, postgres;;
