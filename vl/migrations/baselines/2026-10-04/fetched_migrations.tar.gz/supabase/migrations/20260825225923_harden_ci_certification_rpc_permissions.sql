revoke execute on function public.evaluate_builder_certification(text, boolean) from public, anon, authenticated;
grant execute on function public.evaluate_builder_certification(text, boolean) to service_role;

revoke execute on function public.ingest_ci_evidence(uuid, uuid, text, text, text, text, text, text, text, jsonb, jsonb, jsonb) from public, anon;
revoke execute on function public.learn_from_ci_repair(uuid, boolean, jsonb) from public, anon;
revoke execute on function public.mark_ci_repair_applied(uuid, jsonb) from public, anon;
revoke execute on function public.mark_ci_repair_retry(uuid, text) from public, anon;
revoke execute on function public.propose_ci_repair(uuid, uuid, text, text, text, text, text, text) from public, anon;
revoke execute on function public.verify_ci_repair(uuid, boolean, jsonb) from public, anon;;
