create or replace function private.approve_and_launch_app_spec(p_app_spec_id uuid, p_approver_id uuid)
returns jsonb
language plpgsql
set search_path to 'private','public','pg_temp'
as $$
declare
  v_spec public.app_specs%rowtype;
  v_builder_key text;
  v_builder_status text;
  v_workflow_id uuid;
  v_factory_run_id uuid;
  v_role text;
  v_run_type text := 'build';
  v_workflow_type text := 'factory_build';
  v_base_run_id uuid;
  v_upgrade_seed jsonb;
begin
  select * into v_spec from public.app_specs where id=p_app_spec_id for update;
  if not found then raise exception 'App Spec not found'; end if;
  select pm.role into v_role from public.project_members pm where pm.project_id=v_spec.project_id and pm.user_id=p_approver_id;
  if v_role not in ('owner','admin') then raise exception 'Only project owner/admin may approve and launch App Spec'; end if;
  if v_spec.status not in ('draft','approved') then raise exception 'App Spec status % cannot be launched',v_spec.status; end if;

  v_builder_key:=v_spec.spec #>> '{selected_builder,builder_key}';
  if v_builder_key is null or btrim(v_builder_key)='' then raise exception 'App Spec has no selected builder'; end if;
  select br.status into v_builder_status from public.builder_registry br where br.builder_key=v_builder_key;
  if v_builder_status is distinct from 'active' then raise exception 'Selected builder % is not active',v_builder_key; end if;

  if v_spec.parent_app_spec_id is not null then
    v_run_type:='upgrade'; v_workflow_type:='factory_upgrade';
    select fr.id into v_base_run_id from public.factory_runs fr
    where fr.app_spec_id=v_spec.parent_app_spec_id and fr.state in ('awaiting_approval','certified')
      and coalesce(fr.result->>'runner_status','')='PASS'
    order by fr.created_at desc limit 1;
    if v_base_run_id is null then raise exception 'upgrade requires a successful base factory run for parent App Spec'; end if;
  end if;

  if v_spec.status<>'approved' then update public.app_specs set status='approved',approved_by=p_approver_id,approved_at=now() where id=p_app_spec_id; end if;

  insert into public.workflows(project_id,app_spec_id,workflow_type,state,input,output,created_by)
  values(v_spec.project_id,p_app_spec_id,v_workflow_type,'queued',jsonb_build_object('builder_key',v_builder_key,'source','approved_app_spec','run_type',v_run_type,'base_factory_run_id',v_base_run_id),'{}'::jsonb,p_approver_id)
  returning id into v_workflow_id;

  insert into public.factory_runs(project_id,app_spec_id,workflow_id,requested_by,run_type,state,target_environment,production_locked,input,plan,result,target_platforms,base_factory_run_id)
  values(v_spec.project_id,p_app_spec_id,v_workflow_id,p_approver_id,v_run_type,'queued','staging',true,
    jsonb_build_object('builder_key',v_builder_key,'app_spec_id',p_app_spec_id,'base_factory_run_id',v_base_run_id,'change_request',v_spec.change_request),
    jsonb_build_object('selected_builder',v_builder_key,'target_platforms',v_spec.target_platforms,'approval_required_for_production',true,'run_type',v_run_type,'base_factory_run_id',v_base_run_id),
    '{}'::jsonb,v_spec.target_platforms,v_base_run_id)
  returning id into v_factory_run_id;

  if v_run_type='upgrade' then
    v_upgrade_seed:=private.seed_upgrade_source_from_base(v_factory_run_id,v_base_run_id,v_spec.change_request);
  end if;

  insert into private.app_launch_audit(app_spec_id,project_id,approver_id,builder_key,workflow_id,factory_run_id,decision,details)
  values(p_app_spec_id,v_spec.project_id,p_approver_id,v_builder_key,v_workflow_id,v_factory_run_id,'launched',jsonb_build_object('environment','staging','production_locked',true,'run_type',v_run_type,'base_factory_run_id',v_base_run_id,'upgrade_seed',v_upgrade_seed));

  return jsonb_build_object('decision','launched','app_spec_id',p_app_spec_id,'builder_key',v_builder_key,'workflow_id',v_workflow_id,'factory_run_id',v_factory_run_id,'run_type',v_run_type,'base_factory_run_id',v_base_run_id,'target_environment','staging','production_locked',true,'upgrade_seed',v_upgrade_seed);
end;
$$;;
