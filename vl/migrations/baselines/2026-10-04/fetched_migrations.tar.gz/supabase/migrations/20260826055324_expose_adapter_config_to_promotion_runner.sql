create or replace function public.claim_vrs_production_promotion_job(p_runner_identity jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'private','public','pg_temp'
as $function$
declare
 j private.production_promotion_jobs%rowtype;
 v_dep public.deployments%rowtype;
 v_art public.factory_artifacts%rowtype;
 v_lease uuid:=gen_random_uuid();
 v_adapter_status text;
 v_adapter_configuration jsonb;
 v_required_credentials jsonb;
begin
 select pj.* into j
 from private.production_promotion_jobs pj
 join private.production_adapter_registry ar on ar.adapter_key=pj.target_adapter and ar.status='active' and ar.configured=true
 where (pj.state='queued' or (pj.state='leased' and pj.lease_expires_at<now())) and pj.attempts<pj.max_attempts
 order by pj.created_at for update of pj skip locked limit 1;
 if not found then return jsonb_build_object('status','idle'); end if;

 select * into v_dep from public.deployments where id=j.deployment_id;
 if v_dep.status<>'approved' or v_dep.approved_by is null then return jsonb_build_object('status','rejected','reason','deployment_not_approved'); end if;

 select * into v_art from public.factory_artifacts
 where factory_run_id=j.factory_run_id and artifact_type='bundle' and lower(sha256)=lower(j.artifact_sha256)
 order by created_at desc limit 1;
 if not found then return jsonb_build_object('status','rejected','reason','immutable_source_artifact_not_found'); end if;

 select status,configuration,required_credentials
 into v_adapter_status,v_adapter_configuration,v_required_credentials
 from private.production_adapter_registry where adapter_key=j.target_adapter;
 if v_adapter_status<>'active' then return jsonb_build_object('status','rejected','reason','adapter_not_active'); end if;

 update private.production_promotion_jobs
 set state='leased',attempts=attempts+1,lease_token=v_lease,leased_at=now(),lease_expires_at=now()+interval '20 minutes',updated_at=now()
 where id=j.id returning * into j;

 update public.deployments
 set status='deploying',certificate=certificate||jsonb_build_object('promotion_started_at',now(),'promotion_adapter',j.target_adapter)
 where id=j.deployment_id;

 return jsonb_build_object(
   'status','leased','job_id',j.id,'lease_token',v_lease,'deployment_id',j.deployment_id,
   'factory_run_id',j.factory_run_id,'builder_key',j.builder_key,'target_adapter',j.target_adapter,
   'expected_sha256',j.artifact_sha256,'source_artifact_name',v_art.name,'source_storage_path',v_art.storage_path,
   'source_github_run_id',v_art.metadata->>'github_run_id','attempt',j.attempts,'max_attempts',j.max_attempts,
   'adapter_configuration',coalesce(v_adapter_configuration,'{}'::jsonb),
   'required_credentials',coalesce(v_required_credentials,'[]'::jsonb)
 );
end $function$;;
