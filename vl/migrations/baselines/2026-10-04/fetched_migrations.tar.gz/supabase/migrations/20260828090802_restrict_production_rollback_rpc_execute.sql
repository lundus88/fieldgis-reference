revoke execute on function public.claim_vrs_production_rollback_job(jsonb) from public, anon, authenticated;
revoke execute on function public.complete_vrs_production_rollback_job(uuid,uuid,boolean,jsonb,text) from public, anon, authenticated;
grant execute on function public.claim_vrs_production_rollback_job(jsonb) to service_role;
grant execute on function public.complete_vrs_production_rollback_job(uuid,uuid,boolean,jsonb,text) to service_role;;
