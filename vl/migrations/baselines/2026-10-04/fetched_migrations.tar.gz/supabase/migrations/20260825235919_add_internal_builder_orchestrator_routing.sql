create table if not exists private.builder_route_decisions (
  id uuid primary key default gen_random_uuid(),
  requested_builder_type text,
  requested_target text,
  required_capabilities text[] not null default '{}'::text[],
  selected_builder_key text,
  candidate_count integer not null default 0,
  decision jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

revoke all on private.builder_route_decisions from public, anon, authenticated;
grant select, insert on private.builder_route_decisions to service_role;

create or replace function private.route_builder(
  p_builder_type text default null,
  p_target text default null,
  p_required_capabilities text[] default '{}'::text[]
) returns jsonb
language plpgsql
security invoker
set search_path = private, public, pg_temp
as $$
declare
  v_selected record;
  v_candidates jsonb;
  v_candidate_count integer := 0;
  v_result jsonb;
begin
  if p_builder_type is not null and p_builder_type not in ('web','pwa','mobile','desktop','gis','ai','api') then
    raise exception 'Unsupported builder type: %', p_builder_type;
  end if;

  if exists (
    select 1 from unnest(coalesce(p_required_capabilities,'{}'::text[])) c
    where c !~ '^[a-z0-9_]+$'
  ) then
    raise exception 'Invalid capability key';
  end if;

  with eligible as (
    select
      br.builder_key,
      br.builder_type,
      br.runtime,
      br.targets,
      br.capabilities,
      (
        case when p_builder_type is not null and br.builder_type = p_builder_type then 100 else 0 end
        + case when p_target is not null and p_target = any(br.targets) then 20 else 0 end
        + 10 * (
          select count(*)::int
          from unnest(coalesce(p_required_capabilities,'{}'::text[])) c
          where coalesce((br.capabilities ->> c)::boolean,false)
        )
      ) as score
    from public.builder_registry br
    where br.status = 'active'
      and (p_builder_type is null or br.builder_type = p_builder_type)
      and (p_target is null or p_target = any(br.targets))
      and not exists (
        select 1
        from unnest(coalesce(p_required_capabilities,'{}'::text[])) c
        where not coalesce((br.capabilities ->> c)::boolean,false)
      )
  ), ranked as (
    select *, row_number() over(order by score desc, builder_key asc) as rn
    from eligible
  )
  select
    (select jsonb_agg(jsonb_build_object(
      'builder_key', builder_key,
      'builder_type', builder_type,
      'runtime', runtime,
      'targets', targets,
      'capabilities', capabilities,
      'score', score
    ) order by score desc, builder_key asc) from ranked),
    (select count(*)::int from ranked)
  into v_candidates, v_candidate_count;

  select br.builder_key, br.builder_type, br.runtime, br.targets, br.capabilities
  into v_selected
  from public.builder_registry br
  where br.builder_key = (
    select x->>'builder_key'
    from jsonb_array_elements(coalesce(v_candidates,'[]'::jsonb)) x
    limit 1
  );

  if v_selected.builder_key is null then
    v_result := jsonb_build_object(
      'decision','no_match',
      'selected_builder',null,
      'candidate_count',v_candidate_count,
      'candidates',coalesce(v_candidates,'[]'::jsonb),
      'requested',jsonb_build_object(
        'builder_type',p_builder_type,
        'target',p_target,
        'required_capabilities',coalesce(p_required_capabilities,'{}'::text[])
      )
    );
  else
    v_result := jsonb_build_object(
      'decision','selected',
      'selected_builder',jsonb_build_object(
        'builder_key',v_selected.builder_key,
        'builder_type',v_selected.builder_type,
        'runtime',v_selected.runtime,
        'targets',v_selected.targets,
        'capabilities',v_selected.capabilities
      ),
      'candidate_count',v_candidate_count,
      'candidates',coalesce(v_candidates,'[]'::jsonb),
      'requested',jsonb_build_object(
        'builder_type',p_builder_type,
        'target',p_target,
        'required_capabilities',coalesce(p_required_capabilities,'{}'::text[])
      )
    );
  end if;

  insert into private.builder_route_decisions(
    requested_builder_type,requested_target,required_capabilities,
    selected_builder_key,candidate_count,decision
  ) values (
    p_builder_type,p_target,coalesce(p_required_capabilities,'{}'::text[]),
    v_selected.builder_key,v_candidate_count,v_result
  );

  return v_result;
end;
$$;

revoke all on function private.route_builder(text,text,text[]) from public, anon, authenticated;
grant execute on function private.route_builder(text,text,text[]) to service_role;
;
